package br.com.livraria.core.dao.cliente;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Statement;

import br.com.livraria.core.dao.livro.AbstractDAO;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.cliente.TipoLogradouro;

public class TipoLogradouroDAO extends AbstractDAO {

	/**
	 *  <3 <3 <3
	 *  <3 <3
	 *  <3
	 */
	public void salvar(EntidadeDominio entidade) {
		openConnection();
		PreparedStatement pst = null;
		TipoLogradouro tipoLogradouro = (TipoLogradouro) entidade;

		try {
			connection.setAutoCommit(false);
			StringBuilder sql = new StringBuilder();
			sql.append("INSERT INTO tipo_logradouro ");
			sql.append("(tipo_logradouro)");
			sql.append(" VALUES (?)");

			pst = connection.prepareStatement(sql.toString(), Statement.RETURN_GENERATED_KEYS);
			pst.setString(1, tipoLogradouro.getTipoLogradouro());
		
			pst.executeUpdate();

			ResultSet rs = pst.getGeneratedKeys();

			int id = 0;
			if (rs.next())
				id = rs.getInt(1);

			entidade.setId(id);
			
		} catch (Exception e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {

				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				if(controleTransacao){
					connection.commit();
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	public void alterar(EntidadeDominio entidade) {
		openConnection();
		PreparedStatement pst = null;
		TipoLogradouro tipoLogradouro = (TipoLogradouro) entidade;

		try {
			connection.setAutoCommit(false);
			StringBuilder sql = new StringBuilder();
			sql.append("UPDATE tipo_logradouro set ");
			sql.append("tipo_logradouro=?");
			sql.append(" WHERE id_tipo_logradouro=? ");

			pst = connection.prepareStatement(sql.toString(), Statement.RETURN_GENERATED_KEYS);
			pst.setString(1, tipoLogradouro.getTipoLogradouro());
			pst.setInt(2, tipoLogradouro.getId());
			pst.executeUpdate();

		
			
		} catch (Exception e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {

				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				if(controleTransacao){
					connection.commit();
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}	
	    public List<EntidadeDominio> listar(EntidadeDominio entidade) {
		PreparedStatement pst = null;

		TipoLogradouro tipoLogradouro = (TipoLogradouro) entidade;
		String sql = "select * from tipo_logradouro";

		if (tipoLogradouro.getId() != null)
			sql = "select * from tipo_logradouro where id_tipo_logradouro = ?";
		
		try {
			openConnection();
			pst = connection.prepareStatement(sql);
			if (sql.equals("select * from tipo_logradouro where id_tipo_logradouro = ?"))
				pst.setInt(1, tipoLogradouro.getId());
			
			ResultSet rs = pst.executeQuery();
			List<EntidadeDominio> tipoLogradouros = new ArrayList<EntidadeDominio>();

			while (rs.next()) {
				TipoLogradouro t = new TipoLogradouro();
				t.setId(rs.getInt("id_tipo_logradouro"));
				t.setTipoLogradouro(rs.getString("tipo_logradouro"));
				tipoLogradouros.add(t);
			}
			return tipoLogradouros;

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				if(controleTransacao) {
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return null;	    
	    }	    
}


