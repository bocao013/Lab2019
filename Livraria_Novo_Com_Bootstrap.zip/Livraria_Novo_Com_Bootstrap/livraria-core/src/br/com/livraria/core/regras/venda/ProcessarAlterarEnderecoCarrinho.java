package br.com.livraria.core.regras.venda;

import br.com.livraria.core.IStrategy;
import br.com.livraria.core.dao.cliente.EnderecoDAO;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.cliente.Endereco;
import br.com.livraria.dominio.venda.AlterarEnderecoCarrinho;
import br.com.livraria.dominio.venda.Pedido;

public class ProcessarAlterarEnderecoCarrinho implements IStrategy {

	@Override
	public String processar(EntidadeDominio entidade) {
		AlterarEnderecoCarrinho alterarEnderecoCarrinho = (AlterarEnderecoCarrinho) entidade;
		Pedido carrinho = alterarEnderecoCarrinho.getCarrinho();
		EnderecoDAO enderecoDao = new EnderecoDAO();
		
		carrinho.setEndereco((Endereco) enderecoDao.listar(carrinho.getEndereco()).get(0));
		alterarEnderecoCarrinho.setCarrinho(carrinho);
		entidade = alterarEnderecoCarrinho;
		
		return null;
	}

}
