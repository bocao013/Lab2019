package br.com.livraria.core.regras.venda;

import br.com.livraria.core.IStrategy;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.venda.PagamentoCartaoCredito;
import br.com.livraria.dominio.venda.RemoverCartaoPagamento;

public class ProcessarRemoverCartaoPagamento implements IStrategy {

	@Override
	public String processar(EntidadeDominio entidade) {
		RemoverCartaoPagamento removerCartaoPamento = (RemoverCartaoPagamento) entidade;
		PagamentoCartaoCredito pagamentoParaRemover = null;
		for(PagamentoCartaoCredito pagamentoCartaoCredito : removerCartaoPamento.getCarrinho().getPagamento().getPagamentosCartao()) {
			if(pagamentoCartaoCredito.getCartaoCredito().getId().equals(removerCartaoPamento.getIdCartaoRemover())) {
				pagamentoParaRemover = pagamentoCartaoCredito;
				break;
			}
		}
		removerCartaoPamento.getCarrinho().getPagamento().getPagamentosCartao().remove(pagamentoParaRemover);
		entidade = removerCartaoPamento; 
		return null;
	}

}
