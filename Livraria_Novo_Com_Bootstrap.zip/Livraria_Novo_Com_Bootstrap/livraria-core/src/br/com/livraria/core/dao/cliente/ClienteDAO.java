package br.com.livraria.core.dao.cliente;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.mysql.jdbc.Statement;

import br.com.livraria.core.dao.livro.AbstractDAO;
import br.com.livraria.core.dao.venda.CupomTrocaDAO;
import br.com.livraria.core.dao.venda.PedidoDAO;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.cliente.CartaoCredito;
import br.com.livraria.dominio.cliente.Cliente;
import br.com.livraria.dominio.cliente.Endereco;
import br.com.livraria.dominio.cliente.Telefone;
import br.com.livraria.dominio.venda.CupomTroca;
import br.com.livraria.dominio.venda.Pedido;

public class ClienteDAO extends AbstractDAO {

	/**
	 *  <3 <3 <3
	 *  <3 <3
	 *  <3
	 */
	private Boolean subConsulta = false;
	
	public Boolean getSubConsulta() {
		return subConsulta;
	}

	public void setSubConsulta(Boolean subConsulta) {
		this.subConsulta = subConsulta;
	}

	public void salvar(EntidadeDominio entidade) {
		openConnection();
		PreparedStatement pst = null;
		Cliente cliente = (Cliente) entidade;

		try {
			connection.setAutoCommit(false);
			
			TelefoneDAO telefoneDao = new TelefoneDAO();
			
			
			telefoneDao.connection = connection;
			telefoneDao.controleTransacao = false;
			telefoneDao.salvar(cliente.getTelefone());
			
			StringBuilder sb = new StringBuilder();
			sb.append("INSERT INTO cliente ");
			sb.append("(genero, nome, dt_nascimento, email, cpf, senha, codigo, ranking, ativo, id_telefone)");
			sb.append(" VALUES (?,?,?,?,?,?,?,?,?,?)");

			Timestamp ts = new Timestamp(cliente.getDtNascimento().getTime());
			
			pst = connection.prepareStatement(sb.toString(), Statement.RETURN_GENERATED_KEYS);
			pst.setString(1, cliente.getGenero());
			pst.setString(2, cliente.getNome());
			pst.setTimestamp(3, ts);
			pst.setString(4, cliente.getEmail());
			pst.setString(5, cliente.getCpf());
			pst.setString(6, cliente.getSenha());
			pst.setString(7, cliente.getCodigo());
			pst.setInt(8, cliente.getRanking());
			pst.setBoolean(9, cliente.getAtivo());
			pst.setInt(10, cliente.getTelefone().getId());
			pst.executeUpdate();

			ResultSet rs = pst.getGeneratedKeys();

			int id = 0;
			if (rs.next())
				id = rs.getInt(1);
			
			cliente.setId(id);
			
			EnderecoDAO enderecoDao = new EnderecoDAO();
			
			enderecoDao.connection = connection;
			enderecoDao.controleTransacao = false;
			
			for(Endereco endereco:cliente.getEnderecos()){
				endereco.setCliente(cliente);
				enderecoDao.salvar(endereco);
			}
			
			CartaoCreditoDAO cartaoCreditoDao = new CartaoCreditoDAO();
			
			cartaoCreditoDao.connection = connection;
			cartaoCreditoDao.controleTransacao = false;
			
			for(CartaoCredito cartaoCredito:cliente.getCartoesCredito()){
				cartaoCredito.setCliente(cliente);
				cartaoCreditoDao.salvar(cartaoCredito);
			}
			connection.commit();
			entidade = cliente;
		} catch (Exception e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {

				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				connection.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	public void alterar(EntidadeDominio entidade) {
		openConnection();
		PreparedStatement pst = null;
		Cliente cliente = (Cliente) entidade;

		try {
			
			connection.setAutoCommit(false);
			
			TelefoneDAO telefoneDao = new TelefoneDAO();
			/*EnderecoDAO enderecoDao = new EnderecoDAO();
			CartaoCreditoDAO cartaoCreditoDao = new CartaoCreditoDAO();*/
			
			
			telefoneDao.connection = connection;
			telefoneDao.controleTransacao = false;
			telefoneDao.alterar(cliente.getTelefone());
			
			StringBuilder sb = new StringBuilder();
			sb.append("UPDATE cliente set ");
			sb.append("genero=?, nome=?, dt_nascimento=?, email=?, cpf=?, senha=?, codigo=?, ranking=?,"
					+ "ativo=?, id_telefone=?");
			sb.append(" WHERE id_cliente=?");

			Timestamp ts = new Timestamp(cliente.getDtNascimento().getTime());
			
			pst = connection.prepareStatement(sb.toString(), Statement.RETURN_GENERATED_KEYS);
			pst.setString(1, cliente.getGenero());
			pst.setString(2, cliente.getNome());
			pst.setTimestamp(3, ts);
			pst.setString(4, cliente.getEmail());
			pst.setString(5, cliente.getCpf());
			pst.setString(6, cliente.getSenha());
			pst.setString(7, cliente.getCodigo());
			pst.setInt(8, cliente.getRanking());
			pst.setBoolean(9, cliente.getAtivo());
			pst.setInt(10, cliente.getTelefone().getId());
			pst.setInt(11, cliente.getId());
			pst.executeUpdate();

			/*String sql = "delete from cliente_endereco where id_cliente = ?";
			PreparedStatement pstEndereco = connection.prepareStatement(sql);
			pstEndereco.setInt(1, cliente.getId());	
			pstEndereco.executeUpdate();
			for(Endereco endereco:cliente.getEnderecos()){
				if(endereco.getId() != null) {
					enderecoDao.alterar(endereco);
				}
				else {
					enderecoDao.salvar(endereco);
				}
				sql = "insert into cliente_endereco (id_cliente, id_endereco) values (?, ?)";
				PreparedStatement pstEnderecoCliente = connection.prepareStatement(sql);
				pstEnderecoCliente.setInt(1, cliente.getId());	
				pstEnderecoCliente.setInt(2, endereco.getId());	
				pstEnderecoCliente.executeUpdate();	
				pstEnderecoCliente.close();
			}
			
			
			for(CartaoCredito cartaoCredito:cliente.getCartoesCredito()){
				if(cartaoCredito.getId() != null) {
					cartaoCreditoDao.alterar(cartaoCredito);
				}
				else {
					cartaoCreditoDao.salvar(cartaoCredito);
				}
			}
			*/
			connection.commit();
			/*pstEndereco.close();*/
			
		} catch (Exception e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {

				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				connection.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}
	
		public List<EntidadeDominio> listar(EntidadeDominio entidade) {
		PreparedStatement pst = null;
		String sql = "select * from cliente";
		Cliente cliente = (Cliente) entidade;
		if(cliente.getId() != null)
			sql = "select * from cliente where id_cliente = ?";
		if(cliente.getEmail() != null)
			sql = "select * from cliente where email = ?";
		if(cliente.getCodigo() != null)
			
			sql = "select distinct cli.id_cliente, cli.genero, cli.nome, cli.dt_nascimento, cli.email, cli.cpf, cli.ranking, cli.ativo,"
					+"cli.id_telefone, cli.codigo, cli.senha from cliente cli "
					+"inner join telefone tel on cli.id_telefone = tel.id_telefone "
					+"where cli.genero like ? or cli.nome like ? or cli.email like ? or "
					+"cli.cpf like ? or cli.ranking like ? or "
					+"cli.ativo like ? or tel.numero like ? ";
		
		try {
			openConnection();
			pst = connection.prepareStatement(sql);
			if(sql.equals("select * from cliente where id_cliente = ?"))
					pst.setInt(1, cliente.getId());
			
			if(sql.equals("select * from cliente where email = ?"))
				pst.setString(1, cliente.getEmail());
			
			if (sql.equals("select distinct cli.id_cliente, cli.genero, cli.nome, cli.dt_nascimento, cli.email, cli.cpf, cli.ranking, cli.ativo,"
					+"cli.id_telefone, cli.codigo, cli.senha from cliente cli "
					+"inner join telefone tel on cli.id_telefone = tel.id_telefone "
					+"where cli.genero like ? or cli.nome like ? or cli.email like ? or "
					+"cli.cpf like ? or cli.ranking like ? or "
					+"cli.ativo like ? or tel.numero like ? ")){
				pst.setString(1, "%"+cliente.getCodigo()+"%");
				pst.setString(2, "%"+cliente.getCodigo()+"%");
				pst.setString(3, "%"+cliente.getCodigo()+"%");
				pst.setString(4, "%"+cliente.getCodigo()+"%");
				pst.setString(5, "%"+cliente.getCodigo()+"%");
				pst.setString(6, "%"+cliente.getCodigo()+"%");
				pst.setString(7, "%"+cliente.getCodigo()+"%");
			}	
			ResultSet rs = pst.executeQuery();
			List<EntidadeDominio> clientes = new ArrayList<EntidadeDominio>();

			while (rs.next()) {
				Cliente c = new Cliente();
				
				c.setId(rs.getInt("id_cliente"));
				c.setGenero(rs.getString("genero"));
				c.setNome(rs.getString("nome"));
				Timestamp ts = rs.getTimestamp("dt_nascimento");
				Date dataNascimento = new Date(ts.getTime());
				c.setDtNascimento(dataNascimento);
				c.setEmail(rs.getString("email"));
				c.setCpf(rs.getString("cpf"));
				c.setCodigo(rs.getString("codigo"));
				c.setRanking(rs.getInt("ranking"));
				c.setAtivo(rs.getBoolean("ativo"));
				c.setSenha(rs.getString("senha"));
				
				// ---------------------------------------------
				
				Integer idTelefone = rs.getInt("id_telefone");
				
				TelefoneDAO telefoneDao = new TelefoneDAO();
				prepararDaoSubconsulta(telefoneDao, connection);
				
				Telefone telefone = new Telefone();
				
				telefone.setId(idTelefone);

				List<EntidadeDominio> telefones = telefoneDao.listar(telefone);
				
				if( ! telefones.isEmpty()){
					c.setTelefone((Telefone)telefones.get(0));
				}
			
				// PESQUISAR TODOS OS ENDERECOS DO CLIENTE
				if(!subConsulta) {
					sql = "select id_endereco from cliente_endereco where id_cliente = ?";
					PreparedStatement pstEndereco = connection.prepareStatement(sql);
					pstEndereco.setInt(1, c.getId());
					ResultSet rsEndereco = pstEndereco.executeQuery();
					List<Endereco> enderecos = new ArrayList<Endereco>();
					while (rsEndereco.next()){
				
						Integer idEndereco = rsEndereco.getInt("id_endereco");
						
						EnderecoDAO enderecoDao = new EnderecoDAO();			
						prepararDaoSubconsulta(enderecoDao, connection);
						
						Endereco endereco = new Endereco();
						
						endereco.setId(idEndereco);
		
						List<EntidadeDominio> enderecoConsulta = enderecoDao.listar(endereco);
						
						if( ! enderecoConsulta.isEmpty()){
							endereco = (Endereco)enderecoConsulta.get(0);
							enderecos.add(endereco);
						}
					}
					c.setEnderecos(enderecos);
				
					// PESQUISAR TODOS OS CART�ES DO CLIENTE
					sql = "select id_cartao_credito from cliente_cartao_credito where id_cliente = ?";
					PreparedStatement pstCartaoCredito = connection.prepareStatement(sql);
					pstCartaoCredito.setInt(1, c.getId());
					ResultSet rsCartaoCredito = pstCartaoCredito.executeQuery();
					List<CartaoCredito> cartaoCreditos = new ArrayList<CartaoCredito>();
					while (rsCartaoCredito.next()){
				
						Integer idCartaoCredito = rsCartaoCredito.getInt("id_cartao_credito");
						
						CartaoCreditoDAO cartaoCreditoDao = new CartaoCreditoDAO();
						prepararDaoSubconsulta(cartaoCreditoDao, connection);
						
						CartaoCredito cartaoCredito = new CartaoCredito();
						
						cartaoCredito.setId(idCartaoCredito);
		
						List<EntidadeDominio> cartaoCreditoConsulta = cartaoCreditoDao.listar(cartaoCredito);
						
						if( ! cartaoCreditoConsulta.isEmpty()){
							cartaoCredito = (CartaoCredito)cartaoCreditoConsulta.get(0);
							cartaoCreditos.add(cartaoCredito);
						}
					}
					c.setCartoesCredito(cartaoCreditos);
					
					
					
					Pedido pedido = new Pedido();
					pedido.setCliente(c);
					
					PedidoDAO pedidoDao = new PedidoDAO();
					List<EntidadeDominio> retornoPedido = pedidoDao.listar(pedido);
					List<Pedido> pedidos = new ArrayList<Pedido>();
					for(EntidadeDominio ed : retornoPedido) {
						pedido = (Pedido) ed;
						pedido.setCliente(c);
						pedidos.add(pedido);
					}
					c.setPedidos(pedidos);
				
					
				}
				
				// --------------------------------------------
				CupomTroca cupomTroca = new CupomTroca();
				cupomTroca.setCliente(c);
				
				CupomTrocaDAO cupomTrocaDao = new CupomTrocaDAO();
				prepararDaoSubconsulta(cupomTrocaDao, connection);
				
				List<EntidadeDominio> retornoCupomTroca = cupomTrocaDao.listar(cupomTroca);
				List<CupomTroca> cuponsTroca = new ArrayList<CupomTroca>();
				for(EntidadeDominio ed : retornoCupomTroca) {
					cupomTroca = (CupomTroca) ed;
					cuponsTroca.add(cupomTroca);
				}
				c.setCuponsTroca(cuponsTroca);
				
				// ---------------------------------------------
				
				clientes.add(c);		
				
				// ---------------------------------------------
			}
			return clientes;

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				if(controleTransacao)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return null;
	}
}
