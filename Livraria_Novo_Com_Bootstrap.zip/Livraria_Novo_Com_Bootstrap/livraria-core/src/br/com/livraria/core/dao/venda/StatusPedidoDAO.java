package br.com.livraria.core.dao.venda;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.livraria.core.dao.livro.AbstractDAO;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.venda.Cupom;
import br.com.livraria.dominio.venda.StatusPedido;

public class StatusPedidoDAO extends AbstractDAO {

	@Override
	public void salvar(EntidadeDominio entidade) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void alterar(EntidadeDominio entidade) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<EntidadeDominio> listar(EntidadeDominio entidade) {
		PreparedStatement pst = null;

		StatusPedido statusPedido = (StatusPedido) entidade;
		String sql = "select * from status_pedido";

		if (statusPedido.getId() != null)
			sql = "select * from status_pedido where id_status_pedido = ?";
		
		try {
			openConnection();
			pst = connection.prepareStatement(sql);
			if (sql.equals("select * from status_pedido where id_status_pedido = ?"))
				pst.setInt(1, statusPedido.getId());
			
			ResultSet rs = pst.executeQuery();
			List<EntidadeDominio> statusPedidos = new ArrayList<EntidadeDominio>();

			while (rs.next()) {
				StatusPedido s = new StatusPedido();
				s.setId(rs.getInt("id_status_pedido"));
				s.setStatus(rs.getString("status"));
	
				statusPedidos.add(s);
			}
			return statusPedidos;

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				if(controleTransacao) {
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return null;	    
	   }
}
