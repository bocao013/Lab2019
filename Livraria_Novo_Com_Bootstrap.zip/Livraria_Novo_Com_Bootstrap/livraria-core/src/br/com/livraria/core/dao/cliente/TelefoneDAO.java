package br.com.livraria.core.dao.cliente;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Statement;

import br.com.livraria.core.dao.livro.AbstractDAO;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.cliente.Telefone;
import br.com.livraria.dominio.cliente.TipoTelefone;

public class TelefoneDAO extends AbstractDAO {

	/**
	 *  <3 <3 <3
	 *  <3 <3
	 *  <3
	 */
	public void salvar(EntidadeDominio entidade) {
		openConnection();
		PreparedStatement pst = null;
		Telefone telefone = (Telefone) entidade;

		try {
			connection.setAutoCommit(false);
			StringBuilder sql = new StringBuilder();
			sql.append("INSERT INTO telefone ");
			sql.append("(ddd, numero, id_tipo_telefone)");
			sql.append(" VALUES (?,?,?)");

			pst = connection.prepareStatement(sql.toString(), Statement.RETURN_GENERATED_KEYS);
			pst.setString(1, telefone.getDdd());
			pst.setString(2, telefone.getNumero());
			pst.setInt(3, telefone.getTipoTelefone().getId());
		
			pst.executeUpdate();

			ResultSet rs = pst.getGeneratedKeys();

			int id = 0;
			if (rs.next())
				id = rs.getInt(1);

			entidade.setId(id);
			
		} catch (Exception e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {

				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				if(controleTransacao){
					connection.commit();
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	public void alterar(EntidadeDominio entidade) {
		openConnection();
		PreparedStatement pst = null;
		Telefone telefone = (Telefone) entidade;

		try {
			connection.setAutoCommit(false);
			StringBuilder sql = new StringBuilder();
			sql.append("UPDATE telefone set ");
			sql.append("ddd=?, numero=?, id_tipo_telefone=?");
			sql.append(" WHERE id_telefone=? ");

			pst = connection.prepareStatement(sql.toString(), Statement.RETURN_GENERATED_KEYS);
			pst.setString(1, telefone.getDdd());
			pst.setString(2, telefone.getNumero());
			pst.setInt(3, telefone.getTipoTelefone().getId());
			pst.setInt(4, telefone.getId());
			
			pst.executeUpdate();

			
			
		} catch (Exception e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {

				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				if(controleTransacao){
					connection.commit();
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}	
	    public List<EntidadeDominio> listar(EntidadeDominio entidade) {
		PreparedStatement pst = null;

		Telefone telefone = (Telefone) entidade;
		String sql = "select * from telefone";

		if (telefone.getId() != null)
			sql = "select * from telefone where id_telefone = ?";
		
		try {
			openConnection();
			pst = connection.prepareStatement(sql);
			if (sql.equals("select * from telefone where id_telefone = ?"))
				pst.setInt(1, telefone.getId());
			
			ResultSet rs = pst.executeQuery();
			List<EntidadeDominio> telefones = new ArrayList<EntidadeDominio>();

			while (rs.next()) {
				Telefone t = new Telefone();
				t.setId(rs.getInt("id_telefone"));
				t.setDdd(rs.getString("ddd"));
				t.setNumero(rs.getString("numero"));
				
				// ------------------------------------------------------------------
				
				Integer idTipoTelefone = rs.getInt("id_tipo_telefone");
				
				TipoTelefoneDAO tipoTelefoneDao = new TipoTelefoneDAO();
				prepararDaoSubconsulta(tipoTelefoneDao, connection);
				TipoTelefone tipoTelefone = new TipoTelefone();
					
				tipoTelefone.setId(idTipoTelefone);

				List<EntidadeDominio> tipoTelefones = tipoTelefoneDao.listar(tipoTelefone);	
				
				if( ! tipoTelefones.isEmpty()){
					t.setTipoTelefone((TipoTelefone)tipoTelefones.get(0));
				}
				
				// ------------------------------------------------------------------
				
				telefones.add(t);
			}
			return telefones;

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				if(controleTransacao) {
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return null;	    
	    }	    
}



