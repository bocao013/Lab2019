package br.com.livraria.core.dao.livro;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Statement;

import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.livro.Dimensoes;

public class DimensoesDAO extends AbstractDAO {

	/**
	 *  <3 <3 <3
	 *  <3 <3
	 *  <3
	 */
	public void salvar(EntidadeDominio entidade) {
		openConnection();
		PreparedStatement pst = null;
		Dimensoes dimensoes = (Dimensoes) entidade;

		try {
			connection.setAutoCommit(false);
			StringBuilder sql = new StringBuilder();
			sql.append("INSERT INTO dimensoes ");
			sql.append("(altura, largura, peso, profundidade)");
			sql.append(" VALUES (?,?,?,?)");

			pst = connection.prepareStatement(sql.toString(), Statement.RETURN_GENERATED_KEYS);
			pst.setDouble(1, dimensoes.getAltura());
			pst.setDouble(2, dimensoes.getLargura());
			pst.setDouble(3, dimensoes.getPeso());
			pst.setDouble(4, dimensoes.getProfundidade());
			
			pst.executeUpdate();

			ResultSet rs = pst.getGeneratedKeys();

			int id = 0;
			if (rs.next())
				id = rs.getInt(1);

			entidade.setId(id);
		
		} catch (Exception e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {

				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				if(controleTransacao){
					connection.commit();
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	public void alterar(EntidadeDominio entidade) {
		openConnection();
		PreparedStatement pst = null;
		Dimensoes dimensoes = (Dimensoes) entidade;

		try {
			connection.setAutoCommit(false);
			StringBuilder sql = new StringBuilder();
			sql.append("UPDATE dimensoes set ");
			sql.append("altura=?, largura=?, peso=?, profundidade=?");
			sql.append(" WHERE id_dimensoes=? ");

			pst = connection.prepareStatement(sql.toString(), Statement.RETURN_GENERATED_KEYS);
			pst.setDouble(1, dimensoes.getAltura());
			pst.setDouble(2, dimensoes.getLargura());
			pst.setDouble(3, dimensoes.getPeso());
			pst.setDouble(4, dimensoes.getProfundidade());
			pst.setInt(5, dimensoes.getId());
			
			pst.executeUpdate();

			
		} catch (Exception e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {

				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				if(controleTransacao){
					connection.commit();
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}	
	    public List<EntidadeDominio> listar(EntidadeDominio entidade) {
		PreparedStatement pst = null;

		Dimensoes dimensoes = (Dimensoes) entidade;
		String sql = "select * from dimensoes";

		if (dimensoes.getId() != null)
			sql = "select * from dimensoes where id_dimensoes = ?";
		
		try {
			openConnection();
			pst = connection.prepareStatement(sql);
			if (sql.equals("select * from dimensoes where id_dimensoes = ?"))
				pst.setInt(1, dimensoes.getId());
			
			ResultSet rs = pst.executeQuery();
			List<EntidadeDominio> dimensoess = new ArrayList<EntidadeDominio>();

			while (rs.next()) {
				Dimensoes d = new Dimensoes();
				d.setId(rs.getInt("id_dimensoes"));
				d.setAltura(rs.getDouble("altura"));
				d.setLargura(rs.getDouble("largura"));
				d.setPeso(rs.getDouble("peso"));
				d.setProfundidade(rs.getDouble("profundidade"));
				dimensoess.add(d);
			}
			return dimensoess;

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				if(controleTransacao)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return null;	    
	    }	    
}

