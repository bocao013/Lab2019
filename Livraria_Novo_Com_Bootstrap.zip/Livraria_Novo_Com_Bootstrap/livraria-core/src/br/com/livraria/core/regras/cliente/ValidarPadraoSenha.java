package br.com.livraria.core.regras.cliente;

import br.com.livraria.core.IStrategy;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.cliente.Cliente;

public class ValidarPadraoSenha implements IStrategy {

	public String processar(EntidadeDominio entidade) {
		Cliente cliente = (Cliente) entidade;
		String numeros = "[0-9]{1,}";
		String minusculas = "[a-z]{1,}";
		String maiusculas = "[A-Z]{1,}";
		String caracteresEspeciais = "!@#$%&";
		String especiais = "["+caracteresEspeciais+"]{1,}";
		
		boolean possuiNumero = false;;
		boolean possuiMinuscula = false;
		boolean possuiMaiuscula = false;
		boolean possuiEspecial = false;
		boolean possuiTamanhoMinimo = false;;
		
		int tamanhoMinimo = 8;
		
		if(cliente.getSenha().length() >= tamanhoMinimo){
			possuiTamanhoMinimo = true;
		}
		
		for(int charIndex = 0; charIndex < cliente.getSenha().length(); charIndex++){
			Character character = cliente.getSenha().charAt(charIndex);
			
			if(character.toString().matches(numeros))	{			
				possuiNumero = true;
			}
			
			if(character.toString().matches(minusculas))	{			
				possuiMinuscula = true;
			}
			
			if(character.toString().matches(maiusculas))	{			
				possuiMaiuscula = true;
			}
			
			if(character.toString().matches(especiais))	{			
				possuiEspecial = true;
			}
			
			
		}
		// se a senha estiver no padr�o correto, retornar sem erro
		if(possuiNumero && possuiMinuscula && possuiMaiuscula && possuiEspecial && possuiTamanhoMinimo)
			return null;
		
		StringBuilder sb = new StringBuilder();
		sb.append("A senha deve possuir:").append("\n");
		
		if(!possuiTamanhoMinimo)
			sb.append("- pelo menos ").append(tamanhoMinimo).append(" caracteres").append("\n");
		
		if(!possuiNumero)
			sb.append("- pelo menos 1 n�mero").append("\n");
		
		if(!possuiMinuscula)
			sb.append("- pelo menos 1 letra min�scula ").append("\n");
		
		if(!possuiMaiuscula)
			sb.append("- pelo menos 1 letra mai�scula").append("\n");
		
		if(!possuiEspecial)
			sb.append("- pelo menos 1 caractere especial(").append(caracteresEspeciais).append(")").append("\n");
		
		return sb.toString();
	}

}
