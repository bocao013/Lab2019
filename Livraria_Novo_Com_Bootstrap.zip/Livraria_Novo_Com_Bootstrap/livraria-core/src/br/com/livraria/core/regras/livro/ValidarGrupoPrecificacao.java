package br.com.livraria.core.regras.livro;

import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.livro.Livro;
import br.com.livraria.core.IStrategy;

public class ValidarGrupoPrecificacao implements IStrategy {

	@Override
	public String processar(EntidadeDominio entidade) {
		Livro livro = (Livro)entidade;
		
		if(livro.getGrupolivro() != null && livro.getGrupolivro().getId() == null)
			return "Selecione um Grupo de Precifica��o!";
			
		return null;
	}

}
