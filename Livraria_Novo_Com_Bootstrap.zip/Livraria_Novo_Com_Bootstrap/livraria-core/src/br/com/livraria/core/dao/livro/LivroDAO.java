package br.com.livraria.core.dao.livro;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Statement;

import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.livro.Categoria;
import br.com.livraria.dominio.livro.Dimensoes;
import br.com.livraria.dominio.livro.Editora;
import br.com.livraria.dominio.livro.GrupoLivro;
import br.com.livraria.dominio.livro.ISBN;
import br.com.livraria.dominio.livro.Livro;
import br.com.livraria.dominio.livro.SubCategoria;

public class LivroDAO extends AbstractDAO {

	/**
	 *  <3 <3 <3
	 *  <3 <3
	 *  <3
	 */
	public void salvar(EntidadeDominio entidade) {
		openConnection();
		PreparedStatement pst = null;
		Livro livro = (Livro) entidade;

		try {
			connection.setAutoCommit(false);
			
			DimensoesDAO dimensoesDao = new DimensoesDAO();
			EditoraDAO editoraDao = new EditoraDAO();
			IsbnDAO isbnDao = new IsbnDAO();
			
			dimensoesDao.connection = connection;
			dimensoesDao.controleTransacao = false;
			dimensoesDao.salvar(livro.getDimensoes());
			
			editoraDao.connection = connection;
			editoraDao.controleTransacao = false;
			editoraDao.salvar(livro.getEditora());
			
			isbnDao.connection = connection;
			isbnDao.controleTransacao = false;
			isbnDao.salvar(livro.getIsbn());
			
			StringBuilder sb = new StringBuilder();
			sb.append("INSERT INTO livro ");
			sb.append("(codigo, autor, titulo, ano, edicao, numero_paginas, sinopse, id_editora,"
					+ "id_dimensoes, id_isbn, id_grupolivro, ativo, preco)");
			sb.append(" VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)");

			pst = connection.prepareStatement(sb.toString(), Statement.RETURN_GENERATED_KEYS);
			pst.setString(1, livro.getCodigo());
			pst.setString(2, livro.getAutor());
			pst.setString(3, livro.getTitulo());
			pst.setString(4, livro.getAno());
			pst.setString(5, livro.getEdicao());
			pst.setString(6, livro.getNumeroPaginas());
			pst.setString(7, livro.getSinopse());
			pst.setInt(8, livro.getEditora().getId());
			pst.setInt(9, livro.getDimensoes().getId());
			pst.setInt(10, livro.getIsbn().getId());
			pst.setInt(11, livro.getGrupolivro().getId());
			pst.setBoolean(12, livro.getAtivo());
			pst.setDouble(13, livro.getPreco());
			pst.executeUpdate();

			ResultSet rs = pst.getGeneratedKeys();

			int id = 0;
			if (rs.next())
				id = rs.getInt(1);

			entidade.setId(id);
			
			String sql = "delete from livro_categoria where id_livro = ?";
			PreparedStatement pstCategoria = connection.prepareStatement(sql);
			pstCategoria.setInt(1, entidade.getId());	
			pstCategoria.executeUpdate();
			for(Categoria categoria:livro.getCategorias()){
				sql = "insert into livro_categoria (id_livro, id_categoria) values (?, ?)";
				PreparedStatement pstCategoriaLivro = connection.prepareStatement(sql);
				pstCategoriaLivro.setInt(1, entidade.getId());	
				pstCategoriaLivro.setInt(2, categoria.getId());	
				pstCategoriaLivro.executeUpdate();	
				pstCategoriaLivro.close();
			}
			
			sql = "delete from livro_subcategoria where id_livro = ?";
			PreparedStatement pstSubCategoria = connection.prepareStatement(sql);
			pstSubCategoria.setInt(1, entidade.getId());	
			pstSubCategoria.executeUpdate();
			for(SubCategoria subCategoria:livro.getSubCategorias()){
				sql = "insert into livro_subcategoria (id_livro, id_subcategoria) values (?, ?)";
				PreparedStatement pstSubCategoriaLivro = connection.prepareStatement(sql);
				pstSubCategoriaLivro.setInt(1, entidade.getId());	
				pstSubCategoriaLivro.setInt(2, subCategoria.getId());	
				pstSubCategoriaLivro.executeUpdate();	
				pstSubCategoriaLivro.close();
			}
			connection.commit();
		} catch (Exception e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {

				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				connection.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	public void alterar(EntidadeDominio entidade) {
		openConnection();
		PreparedStatement pst = null;
		Livro livro = (Livro) entidade;

		try {
			connection.setAutoCommit(false);
			
			DimensoesDAO dimensoesDao = new DimensoesDAO();
			EditoraDAO editoraDao = new EditoraDAO();
			IsbnDAO isbnDao = new IsbnDAO();
			
			dimensoesDao.connection = connection;
			dimensoesDao.controleTransacao = false;
			dimensoesDao.salvar(livro.getDimensoes());
			
			editoraDao.connection = connection;
			editoraDao.controleTransacao = false;
			editoraDao.salvar(livro.getEditora());

			isbnDao.connection = connection;
			isbnDao.controleTransacao = false;
			isbnDao.salvar(livro.getIsbn());
			
			StringBuilder sb = new StringBuilder();
			sb.append("UPDATE livro set ");
			sb.append("codigo=?, autor=?, titulo=?, ano=?, edicao=?, numero_paginas=?, sinopse=?, id_editora=?,"
					+ "id_dimensoes=?, id_isbn=?, id_grupolivro=?, ativo=?, preco=?");
			sb.append(" WHERE id_livro=? ");

			pst = connection.prepareStatement(sb.toString(), Statement.RETURN_GENERATED_KEYS);
			
			pst.setString(1, livro.getCodigo());
			pst.setString(2, livro.getAutor());
			pst.setString(3, livro.getTitulo());
			pst.setString(4, livro.getAno());
			pst.setString(5, livro.getEdicao());
			pst.setString(6, livro.getNumeroPaginas());
			pst.setString(7, livro.getSinopse());
			pst.setInt(8, livro.getEditora().getId());
			pst.setInt(9, livro.getDimensoes().getId());
			pst.setInt(10, livro.getIsbn().getId());
			pst.setInt(11, livro.getGrupolivro().getId());
			pst.setBoolean(12, livro.getAtivo());
			pst.setDouble(13, livro.getPreco());
			pst.setInt(14, livro.getId());
			pst.executeUpdate();

			String sql = "delete from livro_categoria where id_livro = ?";
			PreparedStatement pstCategoria = connection.prepareStatement(sql);
			pstCategoria.setInt(1, livro.getId());	
			pstCategoria.executeUpdate();
			for(Categoria categoria:livro.getCategorias()){
				sql = "insert into livro_categoria (id_livro, id_categoria) values (?, ?)";
				PreparedStatement pstCategoriaLivro = connection.prepareStatement(sql);
				pstCategoriaLivro.setInt(1, livro.getId());	
				pstCategoriaLivro.setInt(2, categoria.getId());	
				pstCategoriaLivro.executeUpdate();	
				pstCategoriaLivro.close();
			}
			
			sql = "delete from livro_subcategoria where id_livro = ?";
			PreparedStatement pstSubCategoria = connection.prepareStatement(sql);
			pstSubCategoria.setInt(1, entidade.getId());	
			pstSubCategoria.executeUpdate();
			for(SubCategoria subCategoria:livro.getSubCategorias()){
				sql = "insert into livro_subcategoria (id_livro, id_subcategoria) values (?, ?)";
				PreparedStatement pstSubCategoriaLivro = connection.prepareStatement(sql);
				pstSubCategoriaLivro.setInt(1, entidade.getId());	
				pstSubCategoriaLivro.setInt(2, subCategoria.getId());	
				pstSubCategoriaLivro.executeUpdate();	
				pstSubCategoriaLivro.close();
			}
			connection.commit();
			pstCategoria.close();
			
		} catch (Exception e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {

				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				connection.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}
	
		public List<EntidadeDominio> listar(EntidadeDominio entidade) {
		PreparedStatement pst = null;
		String sql = "select * from livro";
		Livro livro = (Livro) entidade;
		if(livro.getId() != null)
			sql = "select * from livro where id_livro = ?";
		if(livro.getCodigo() != null)
			
			sql = "select distinct liv.id_livro, liv.codigo, liv.autor, liv.titulo, liv.ano, liv.edicao, liv.numero_paginas, liv.sinopse, liv.id_editora,"
					+"liv.id_dimensoes, liv.id_isbn, liv.id_grupolivro, liv.ativo, liv.preco from livro liv "
					+"inner join editora edi on liv.id_editora = edi.id_editora "
					+"inner join livro_categoria livcat on liv.id_livro = livcat.id_livro "
					+"inner join categoria cat on livcat.id_categoria = cat.id_categoria "
					+"inner join livro_subcategoria livsub on liv.id_livro = livsub.id_livro "
					+"inner join subcategoria sub on livsub.id_subcategoria = sub.id_subcategoria "
					+"inner join dimensoes dim on liv.id_dimensoes = dim.id_dimensoes "
					+"inner join isbn isb on liv.id_isbn = isb.id_isbn "
					+"inner join grupolivro grup on liv.id_grupolivro = grup.id_grupolivro "
					+"where liv.codigo like ? or liv.autor like ? or liv.titulo like ? or liv.ano like ? or "
					+"liv.edicao like ? or liv.numero_paginas like ? or "
					+"liv.sinopse like ? or edi.nome like ? or cat.nome like ? or sub.nome like ? or "
					+"isb.codigo_barras like ? or grup.nome like ? or grup.margem_lucro like ?";
		
		try {
			openConnection();
			pst = connection.prepareStatement(sql);
			if(sql.equals("select * from livro where id_livro = ?"))
					pst.setInt(1, livro.getId());
			
			if (sql.equals("select distinct liv.id_livro, liv.codigo, liv.autor, liv.titulo, liv.ano, liv.edicao, liv.numero_paginas, liv.sinopse, liv.id_editora,"
					+"liv.id_dimensoes, liv.id_isbn, liv.id_grupolivro, liv.ativo, liv.preco from livro liv "
					+"inner join editora edi on liv.id_editora = edi.id_editora "
					+"inner join livro_categoria livcat on liv.id_livro = livcat.id_livro "
					+"inner join categoria cat on livcat.id_categoria = cat.id_categoria "
					+"inner join livro_subcategoria livsub on liv.id_livro = livsub.id_livro "
					+"inner join subcategoria sub on livsub.id_subcategoria = sub.id_subcategoria "
					+"inner join dimensoes dim on liv.id_dimensoes = dim.id_dimensoes "
					+"inner join isbn isb on liv.id_isbn = isb.id_isbn "
					+"inner join grupolivro grup on liv.id_grupolivro = grup.id_grupolivro "
					+"where liv.codigo like ? or liv.autor like ? or liv.titulo like ? or liv.ano like ? or "
					+"liv.edicao like ? or liv.numero_paginas like ? or "
					+"liv.sinopse like ? or edi.nome like ? or cat.nome like ? or sub.nome like ? or "
					+"isb.codigo_barras like ? or grup.nome like ? or grup.margem_lucro like ?")){
				pst.setString(1, "%"+livro.getCodigo()+"%");
				pst.setString(2, "%"+livro.getCodigo()+"%");
				pst.setString(3, "%"+livro.getCodigo()+"%");
				pst.setString(4, "%"+livro.getCodigo()+"%");
				pst.setString(5, "%"+livro.getCodigo()+"%");
				pst.setString(6, "%"+livro.getCodigo()+"%");
				pst.setString(7, "%"+livro.getCodigo()+"%");
				pst.setString(8, "%"+livro.getCodigo()+"%");
				pst.setString(9, "%"+livro.getCodigo()+"%");
				pst.setString(10, "%"+livro.getCodigo()+"%");
				pst.setString(11, "%"+livro.getCodigo()+"%");
				pst.setString(12, "%"+livro.getCodigo()+"%");
				pst.setString(13, "%"+livro.getCodigo()+"%");
			}	
			/*if (sql.equals("select * from fornecedor forn inner join endereco ende on forn.id_endereco = ende.id_endereco where ende.cidade like ?"))
				pst.setString(1, "%" + fornecedor.getEndereco().getCidade() + "%");	*/
			
			ResultSet rs = pst.executeQuery();
			List<EntidadeDominio> livros = new ArrayList<EntidadeDominio>();

			while (rs.next()) {
				Livro l = new Livro();
				
				l.setId(rs.getInt("id_livro"));
				l.setCodigo(rs.getString("codigo"));
				l.setTitulo(rs.getString("titulo"));
				l.setAutor(rs.getString("autor"));
				l.setAno(rs.getString("ano"));
				l.setEdicao(rs.getString("edicao"));
				l.setNumeroPaginas(rs.getString("numero_paginas"));
				l.setSinopse(rs.getString("sinopse"));
				l.setPreco(rs.getDouble("preco"));
				l.setAtivo(rs.getBoolean("ativo"));
				
				// ---------------------------------------------
				
				Integer idEditora = rs.getInt("id_editora");
				
				EditoraDAO editoraDao = new EditoraDAO();
				prepararDaoSubconsulta(editoraDao, connection);
				Editora editora = new Editora();
				
				editora.setId(idEditora);

				List<EntidadeDominio> editoras = editoraDao.listar(editora);
				
				if( ! editoras.isEmpty()){
					l.setEditora((Editora)editoras.get(0));
				}
				
				// ---------------------------------------------
				
				
				// ---------------------------------------------
				
				
				// ---------------------------------------------
				
				Integer idDimensoes = rs.getInt("id_dimensoes");
				
				DimensoesDAO dimensoesDao = new DimensoesDAO();
				prepararDaoSubconsulta(dimensoesDao, connection);
				Dimensoes dimensoes = new Dimensoes();
				
				dimensoes.setId(idDimensoes);

				List<EntidadeDominio> dimensoess = dimensoesDao.listar(dimensoes);	
				
				if( ! dimensoess.isEmpty()){
					l.setDimensoes((Dimensoes)dimensoess.get(0));
				}
				
				// ---------------------------------------------
				
				Integer idIsbn = rs.getInt("id_isbn");
				
				IsbnDAO isbnDao = new IsbnDAO();
				prepararDaoSubconsulta(isbnDao, connection);
				ISBN isbn = new ISBN();
				
				isbn.setId(idIsbn);

				List<EntidadeDominio> isbns = isbnDao.listar(isbn);
				
				if( ! isbns.isEmpty()){
					l.setIsbn((ISBN)isbns.get(0));
				}
				
				// ---------------------------------------------
				
				Integer idGrupoLivro = rs.getInt("id_grupolivro");
				
				GrupoLivroDAO grupoLivroDao = new GrupoLivroDAO();
				prepararDaoSubconsulta(grupoLivroDao, connection);
				GrupoLivro grupoLivro = new GrupoLivro();
				
				grupoLivro.setId(idGrupoLivro);

				List<EntidadeDominio> grupoLivros = grupoLivroDao.listar(grupoLivro);	
				
				if( ! grupoLivros.isEmpty()){
					l.setGrupolivro((GrupoLivro)grupoLivros.get(0));
				}
			
				// PESQUISAR TODAS AS CATEGORIAS DO LIVRO
				sql = "select id_categoria from livro_categoria where id_livro = ?";
				PreparedStatement pstCategoria = connection.prepareStatement(sql);
				pstCategoria.setInt(1, l.getId());
				ResultSet rsCategoria = pstCategoria.executeQuery();
				List<Categoria> categorias = new ArrayList<Categoria>();
				while (rsCategoria.next()){
			
					Integer idCategoria = rsCategoria.getInt("id_categoria");
					
					CategoriaDAO categoriaDao = new CategoriaDAO();
					prepararDaoSubconsulta(categoriaDao, connection);
					Categoria categoria = new Categoria();
					
					categoria.setId(idCategoria);
	
					List<EntidadeDominio> categoriaConsulta = categoriaDao.listar(categoria);
					
					if( ! categoriaConsulta.isEmpty()){
						categoria = (Categoria)categoriaConsulta.get(0);
						categorias.add(categoria);
					}
				}
				l.setCategorias(categorias);
				
				// PESQUISAR TODAS AS SUBCATEGORIAS DO LIVRO
				sql = "select id_subcategoria from livro_subcategoria where id_livro = ?";
				PreparedStatement pstSubCategoria = connection.prepareStatement(sql);
				pstSubCategoria.setInt(1, l.getId());
				ResultSet rsSubCategoria = pstSubCategoria.executeQuery();
				List<SubCategoria> subCategorias = new ArrayList<SubCategoria>();
				while (rsSubCategoria.next()){
			
					Integer idSubCategoria = rsSubCategoria.getInt("id_subcategoria");
					
					SubCategoriaDAO subCategoriaDao = new SubCategoriaDAO();
					prepararDaoSubconsulta(subCategoriaDao, connection);
					SubCategoria subCategoria = new SubCategoria();
					
					subCategoria.setId(idSubCategoria);
	
					List<EntidadeDominio> subCategoriaConsulta = subCategoriaDao.listar(subCategoria);
					
					if( ! subCategoriaConsulta.isEmpty()){
						subCategoria = (SubCategoria)subCategoriaConsulta.get(0);
						subCategorias.add(subCategoria);
					}
				}
				l.setSubCategorias(subCategorias);
				
				livros.add(l);
				
				// ---------------------------------------------
			}
			return livros;

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return null;
	}
}
