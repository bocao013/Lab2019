package br.com.livraria.core.dao.livro;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.Usuario;

public class UsuarioDAO extends AbstractDAO {

	public void salvar(EntidadeDominio entidade) {
		

	}

	public void alterar(EntidadeDominio entidade) {
		

	}

	public List<EntidadeDominio> listar(EntidadeDominio entidade) {
		PreparedStatement pst = null;
		
		Usuario usuario = (Usuario)entidade;
		String sql = "select * from usuario";
		
		if(usuario.getNome() == null)
			usuario.setNome("");
		
		if(usuario.getId() != null && usuario.getNome().equals(""))
			sql = sql + " where id = ?";
		
		if(usuario.getId() == null && !usuario.getNome().equals(""))
			sql = sql + " where nome = ?";
		
		try{
		openConnection();
		pst = connection.prepareStatement(sql);
		if(sql.equals("select * from usuario where id = ?"))
			pst.setInt(1, usuario.getId());
		
		if(sql.equals("select * from usuario where nome = ?"))
			pst.setString(1, usuario.getNome());
		
		ResultSet rs = pst.executeQuery();
		List<EntidadeDominio> usuarios = new ArrayList<EntidadeDominio>();
		
		while(rs.next()){
			Usuario u = new Usuario();
			u.setId(rs.getInt("id"));
			u.setNome(rs.getString("nome"));
			u.setSenha(rs.getString("senha"));
			u.setAdmin(rs.getBoolean("admin"));
			usuarios.add(u);
		}
		return usuarios;
		
		}catch(SQLException e){
			e.printStackTrace();
		}
		finally{
			try{
				pst.close();
				connection.close();
			}catch(SQLException e){
				e.printStackTrace();
			}
		}
		return null;		
	}

}
