package br.com.livraria.core.dao.livro;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Statement;

import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.livro.GrupoLivro;


public class GrupoLivroDAO extends AbstractDAO {

	/**
	 *  <3 <3 <3
	 *  <3 <3
	 *  <3
	 */
	public void salvar(EntidadeDominio entidade) {
		openConnection();
		PreparedStatement pst = null;
		GrupoLivro grupolivro = (GrupoLivro) entidade;

		try {
			connection.setAutoCommit(false);
			StringBuilder sql = new StringBuilder();
			sql.append("INSERT INTO grupolivro ");
			sql.append("(nome, margem_lucro)");
			sql.append(" VALUES (?,?)");

			pst = connection.prepareStatement(sql.toString(), Statement.RETURN_GENERATED_KEYS);
			pst.setString(1, grupolivro.getNome());
			pst.setDouble(2, grupolivro.getMargemLucro());
		
			pst.executeUpdate();

			ResultSet rs = pst.getGeneratedKeys();

			int id = 0;
			if (rs.next())
				id = rs.getInt(1);

			entidade.setId(id);
			
		} catch (Exception e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {

				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				if(controleTransacao){
					connection.commit();
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	public void alterar(EntidadeDominio entidade) {
		openConnection();
		PreparedStatement pst = null;
		GrupoLivro grupolivro = (GrupoLivro) entidade;

		try {
			connection.setAutoCommit(false);
			StringBuilder sql = new StringBuilder();
			sql.append("UPDATE grupolivro set ");
			sql.append("nome=?, margem_lucro=?");
			sql.append(" WHERE id_grupolivro=? ");

			pst = connection.prepareStatement(sql.toString(), Statement.RETURN_GENERATED_KEYS);
			pst.setString(1, grupolivro.getNome());
			pst.setDouble(2, grupolivro.getMargemLucro());
			pst.setInt(3, grupolivro.getId());
			
			pst.executeUpdate();

		
			
		} catch (Exception e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {

				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				if(controleTransacao){
					connection.commit();
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}	
	    public List<EntidadeDominio> listar(EntidadeDominio entidade) {
		PreparedStatement pst = null;

		GrupoLivro grupolivro = (GrupoLivro) entidade;
		String sql = "select * from grupolivro";

		if (grupolivro.getId() != null)
			sql = "select * from grupolivro where id_grupolivro = ?";
		
		try {
			openConnection();
			pst = connection.prepareStatement(sql);
			if (sql.equals("select * from grupolivro where id_grupolivro = ?"))
				pst.setInt(1, grupolivro.getId());
			
			ResultSet rs = pst.executeQuery();
			List<EntidadeDominio> grupolivros = new ArrayList<EntidadeDominio>();

			while (rs.next()) {
				GrupoLivro g = new GrupoLivro();
				g.setId(rs.getInt("id_grupolivro"));
				g.setNome(rs.getString("nome"));
				g.setMargemLucro(rs.getDouble("margem_lucro"));
				grupolivros.add(g);
			}
			return grupolivros;

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				if(controleTransacao) {
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return null;	    
	    }	    
}
