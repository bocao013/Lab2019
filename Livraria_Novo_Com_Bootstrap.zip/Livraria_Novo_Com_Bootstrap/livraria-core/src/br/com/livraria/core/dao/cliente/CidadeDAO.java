package br.com.livraria.core.dao.cliente;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Statement;

import br.com.livraria.core.dao.livro.AbstractDAO;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.cliente.Cidade;
import br.com.livraria.dominio.cliente.Estado;

public class CidadeDAO extends AbstractDAO {

	/**
	 *  <3 <3 <3
	 *  <3 <3
	 *  <3
	 */
	public void salvar(EntidadeDominio entidade) {
		openConnection();
		PreparedStatement pst = null;
		Cidade cidade = (Cidade) entidade;

		try {
			connection.setAutoCommit(false);
			StringBuilder sql = new StringBuilder();
			sql.append("INSERT INTO cidades ");
			sql.append("(nome, estados_id)");
			sql.append(" VALUES (?,?)");

			pst = connection.prepareStatement(sql.toString(), Statement.RETURN_GENERATED_KEYS);
			pst.setString(1, cidade.getNome());
			pst.setInt(2, cidade.getEstado().getId());
		
			pst.executeUpdate();

			ResultSet rs = pst.getGeneratedKeys();

			int id = 0;
			if (rs.next())
				id = rs.getInt(1);

			entidade.setId(id);

		} catch (Exception e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {

				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				if(controleTransacao) {
					connection.commit();
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	public void alterar(EntidadeDominio entidade) {
		openConnection();
		PreparedStatement pst = null;
		Cidade cidade = (Cidade) entidade;

		try {
			connection.setAutoCommit(false);
			StringBuilder sql = new StringBuilder();
			sql.append("UPDATE cidades set ");
			sql.append("nome=?, estados_id=?");
			sql.append(" WHERE id=? ");

			pst = connection.prepareStatement(sql.toString(), Statement.RETURN_GENERATED_KEYS);
			pst.setString(1, cidade.getNome());
			pst.setInt(2, cidade.getEstado().getId());
			pst.setInt(3, cidade.getId());
			
			pst.executeUpdate();
			
		} catch (Exception e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {

				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				if(controleTransacao) {
					connection.commit();
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}	
	    public List<EntidadeDominio> listar(EntidadeDominio entidade) {
		PreparedStatement pst = null;

		Cidade cidade = (Cidade) entidade;
		String sql = "select * from cidades";

		if (cidade.getId() != null)
			sql = "select * from cidades where id = ?";
		
		try {
			openConnection();
			pst = connection.prepareStatement(sql);
			if (sql.equals("select * from cidades where id = ?"))
				pst.setInt(1, cidade.getId());
			
			ResultSet rs = pst.executeQuery();
			List<EntidadeDominio> cidades = new ArrayList<EntidadeDominio>();

			while (rs.next()) {
				Cidade c = new Cidade();
				c.setId(rs.getInt("id"));
				c.setNome(rs.getString("nome"));
				
				Integer idEstado = rs.getInt("estados_id");
				
				EstadoDAO estadoDao = new EstadoDAO();
				estadoDao.connection = connection;
				estadoDao.controleTransacao = false;
				Estado estado = new Estado();
				
				// ------------------------------------------------------------------
				estado.setId(idEstado);

				List<EntidadeDominio> estados = estadoDao.listar(estado);
				
				if( ! estados.isEmpty()){
					c.setEstado((Estado)estados.get(0));
				}
				
				// ------------------------------------------------------------------
				
				cidades.add(c);
			}
			return cidades;

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				if(controleTransacao)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return null;	    
	    }	    
}


