package br.com.livraria.core.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;

public class Conexao {

	// Classe que tem a conex�o com o mysql
	public static Connection getConnection()
		throws Exception
	{
		String driver = "org.gjt.mm.mysql.Driver";
		String url = "jdbc:mysql://localhost:3306/livraria";
		String user = "root";
		String password = "123";
		Class.forName(driver);
		Connection conn = DriverManager.getConnection(url, user, password);
		return conn;
				
		
	}
}
