package br.com.livraria.core.util;

import br.com.livraria.dominio.cliente.CartaoCredito;
import br.com.livraria.dominio.cliente.Endereco;
import br.com.livraria.dominio.venda.CupomTroca;
import br.com.livraria.dominio.venda.ItemPedido;
import br.com.livraria.dominio.venda.PagamentoCartaoCredito;
import br.com.livraria.dominio.venda.Pedido;

public class PedidoUtils {

	public static Double calcularFrete(Pedido pedido){
		Double valorBase = 10.00;
		Double multiplicadorItem = 0.50;
		Double valorTotalFrete = valorBase;
		
		for(ItemPedido item: pedido.getItems()) {
			valorTotalFrete += item.getQuantidade() * multiplicadorItem;
		}
				
		Endereco endereco = pedido.getEndereco();
		if(endereco != null) {
			valorTotalFrete += endereco.getCidade().getId() % 10;
		}
		return valorTotalFrete;
		
	}
	
	public static Double getValorTotal(Pedido pedido) {
		Double valorTotalPedido = 0.0;
		
		if(pedido == null || pedido.getItems() == null) {
			return valorTotalPedido;
		}
		
		for(ItemPedido item : pedido.getItems()) {
			valorTotalPedido += LivroUtils.calcularPrecoLivro(item.getLivro()) * item.getQuantidade();

		}
		valorTotalPedido += calcularFrete(pedido);
		return valorTotalPedido;
	}

	public static Double getValorPago(Pedido pedido) {
		Double valorPago = 0.0;
		
		if(pedido == null || pedido.getPagamento() == null) {
			return valorPago;
		}
		
		if(pedido.getPagamento().getCupom() != null) {
			valorPago += pedido.getPagamento().getCupom().getValorDesconto();
		}
		
		if(pedido.getPagamento().getCuponsTroca() != null) {
			for(CupomTroca cupomTroca : pedido.getPagamento().getCuponsTroca()) {
				valorPago += cupomTroca.getValorDesconto();
			}
		}
		
		for(PagamentoCartaoCredito pagamentoCartaoCredito : pedido.getPagamento().getPagamentosCartao()) {
			valorPago += pagamentoCartaoCredito.getValor();
		}
		
		return valorPago;
	}

	public static Double getValorRestandoPagamento(Pedido pedido) {
		
		return getValorTotal(pedido) - getValorPago(pedido);
	}
	
	public static CartaoCredito simularRespostaOperadoraCartao(Pedido pedido) {
		for(PagamentoCartaoCredito pagamentoCartao : pedido.getPagamento().getPagamentosCartao()) {
			if(pagamentoCartao.getCartaoCredito().getNumero().endsWith("01")) {
				return pagamentoCartao.getCartaoCredito();
			}
		}
		return null;
		
	}
	
	public static String getUltimosDigitosCartao(CartaoCredito cartao) {
		
		return cartao.getNumero().substring(cartao.getNumero().length() - 4);
		
	}

}
