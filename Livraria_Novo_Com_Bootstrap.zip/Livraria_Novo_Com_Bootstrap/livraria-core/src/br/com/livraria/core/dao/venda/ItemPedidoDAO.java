package br.com.livraria.core.dao.venda;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Statement;

import br.com.livraria.core.dao.livro.AbstractDAO;
import br.com.livraria.core.dao.livro.LivroDAO;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.livro.Livro;
import br.com.livraria.dominio.venda.ItemEstoque;
import br.com.livraria.dominio.venda.ItemPedido;


public class ItemPedidoDAO extends AbstractDAO {

	/**
	 * <3 <3 <3 <3 <3 <3
	 */
	public void salvar(EntidadeDominio entidade) {
		openConnection();
		PreparedStatement pst = null;
		ItemPedido itemPedido = (ItemPedido) entidade;

		try {
			connection.setAutoCommit(false);

			StringBuilder sb = new StringBuilder();
			sb.append("INSERT INTO item_pedido ");
			sb.append("(quantidade, id_livro, id_pedido)");
			sb.append(" VALUES (?,?,?)");

			pst = connection.prepareStatement(sb.toString(), Statement.RETURN_GENERATED_KEYS);
			pst.setInt(1, itemPedido.getQuantidade());
			pst.setInt(2, itemPedido.getLivro().getId());
			pst.setInt(3, itemPedido.getPedido().getId());
			pst.executeUpdate();

			ResultSet rs = pst.getGeneratedKeys();

			int id = 0;
			if (rs.next())
				id = rs.getInt(1);

			itemPedido.setId(id);
			entidade = itemPedido;
			
			ItemEstoque ie = new ItemEstoque();
			ie.setQuantidade(0 - itemPedido.getQuantidade());
			ie.setLivro(itemPedido.getLivro());
			
			ItemEstoqueDAO itemEstoqueDao = new ItemEstoqueDAO();
			itemEstoqueDao.connection = connection;
			itemEstoqueDao.controleTransacao = false;
			itemEstoqueDao.alterar(ie);

		} catch (Exception e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {

				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				if (controleTransacao) {
					connection.commit();
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	public void alterar(EntidadeDominio entidade) {
		openConnection();
		PreparedStatement pst = null;
		ItemPedido itemPedido = (ItemPedido) entidade;

		try {
			connection.setAutoCommit(false);

			StringBuilder sb = new StringBuilder();
			sb.append("UPDATE item_pedido set ");
			sb.append("quantidade=?, id_livro=?");
			if(itemPedido.getPedido() != null && itemPedido.getPedido().getId() != null) {
				sb.append(", id_pedido=?");
			}
			sb.append(" WHERE id_item_pedido=? ");

			pst = connection.prepareStatement(sb.toString(), Statement.RETURN_GENERATED_KEYS);
			pst.setInt(1, itemPedido.getQuantidade());
			pst.setInt(2, itemPedido.getLivro().getId());
			if(itemPedido.getPedido() != null && itemPedido.getPedido().getId() != null) {
				pst.setInt(3, itemPedido.getPedido().getId());
				pst.setInt(4, itemPedido.getId());
				
			} else {			
				pst.setInt(3, itemPedido.getId());
			}
			pst.executeUpdate();

			ResultSet rs = pst.getGeneratedKeys();

			int id = 0;
			if (rs.next())
				id = rs.getInt(1);

			itemPedido.setId(id);
		} catch (Exception e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {

				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				if (controleTransacao) {
					connection.commit();
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	public List<EntidadeDominio> listar(EntidadeDominio entidade) {
		ItemPedido itemPedido = (ItemPedido) entidade;
		if(itemPedido.getPedido() != null && itemPedido.getPedido().getId() != null) {
			
			String sql = "select * from item_pedido where id_pedido = ?";
			PreparedStatement pst = null;
			try {
				openConnection();
				pst = connection.prepareStatement(sql);
				pst.setInt(1, itemPedido.getPedido().getId());
				
				ResultSet rs = pst.executeQuery();
				List<EntidadeDominio> itensPedido = new ArrayList<EntidadeDominio>();
	
				while (rs.next()) {
					ItemPedido ip = new ItemPedido();
					ip.setId(rs.getInt("id_item_pedido"));
					
					Livro livro = new Livro();
					livro.setId(rs.getInt("id_livro"));					
					LivroDAO livroDao = new LivroDAO();
					livro = (Livro) livroDao.listar(livro).get(0);
					ip.setLivro(livro);
					
					ip.setQuantidade(rs.getInt("quantidade"));
					ip.setPedido(itemPedido.getPedido());
					
					itensPedido.add(ip);
				}
				
				return itensPedido;
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				try {
					pst.close();
					if(controleTransacao) {						
						connection.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			return null;
		} else if ( itemPedido.getId() != null) {
			String sql = "select * from item_pedido where id_item_pedido = ?";
			PreparedStatement pst = null;
			try {
				openConnection();
				pst = connection.prepareStatement(sql);
				pst.setInt(1, itemPedido.getId());
				
				ResultSet rs = pst.executeQuery();
				List<EntidadeDominio> itensPedido = new ArrayList<EntidadeDominio>();
	
				while (rs.next()) {
					ItemPedido ip = new ItemPedido();
					ip.setId(rs.getInt("id_item_pedido"));
					
					Livro livro = new Livro();
					livro.setId(rs.getInt("id_livro"));					
					LivroDAO livroDao = new LivroDAO();
					livro = (Livro) livroDao.listar(livro).get(0);
					ip.setLivro(livro);
					
					ip.setQuantidade(rs.getInt("quantidade"));
					ip.setPedido(itemPedido.getPedido());
					
					itensPedido.add(ip);
				}
				
				return itensPedido;
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				try {
					pst.close();
					if(controleTransacao) {						
						connection.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			return null;
		}
		
		//retornar a mesma entidade que chegou, n�o vou precisar consultar isso no banco
		List<EntidadeDominio> improvisoTecnico = new ArrayList<EntidadeDominio>();
		improvisoTecnico.add(entidade);
		return improvisoTecnico;
	}
}
