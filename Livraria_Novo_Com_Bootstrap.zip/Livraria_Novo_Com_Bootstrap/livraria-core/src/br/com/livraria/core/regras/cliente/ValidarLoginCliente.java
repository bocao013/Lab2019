package br.com.livraria.core.regras.cliente;

import java.util.List;

import br.com.livraria.core.IStrategy;
import br.com.livraria.core.dao.cliente.ClienteDAO;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.cliente.Cliente;

public class ValidarLoginCliente implements IStrategy {

	public String processar(EntidadeDominio entidade) {
		Cliente cliente = (Cliente) entidade;
		ClienteDAO clienteDao = new ClienteDAO();
		
		if(cliente.getEmail() == null && cliente.getSenha() == null)
			return null;
	
		List<EntidadeDominio> resultado = clienteDao.listar(cliente);
		
		if(resultado.isEmpty())
			return "Cliente n�o cadastrado!";
		
		Cliente clienteResultado = (Cliente)resultado.get(0);
		
		if(!cliente.getSenha().equals(clienteResultado.getSenha()))
			return "Senha inv�lida!";
		
		
		return null;
	}

}
