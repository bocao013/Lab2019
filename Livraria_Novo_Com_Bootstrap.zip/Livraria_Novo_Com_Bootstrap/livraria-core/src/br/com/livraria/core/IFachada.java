package br.com.livraria.core;

import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.core.aplicacao.Resultado;

public interface IFachada {

	public Resultado salvar(EntidadeDominio entidade);
	public Resultado alterar(EntidadeDominio entidade);
	public Resultado excluir(EntidadeDominio entidade);
	public Resultado listar(EntidadeDominio entidade);
	public Resultado processar(EntidadeDominio entidade);
}
