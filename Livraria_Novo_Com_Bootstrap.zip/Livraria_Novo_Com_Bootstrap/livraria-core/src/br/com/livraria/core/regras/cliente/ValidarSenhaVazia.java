package br.com.livraria.core.regras.cliente;

import br.com.livraria.core.IStrategy;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.cliente.Cliente;

public class ValidarSenhaVazia implements IStrategy {

	public String processar(EntidadeDominio entidade) {
		String msgRetornoVazio = "Senha e confirma��o de senha � um campo obrigat�rio!";
		Cliente cliente = (Cliente)entidade;
		
		if(cliente.getSenha() == null || cliente.getConfirmacaoSenha() == null || cliente.getSenha().trim().isEmpty() ||
				cliente.getConfirmacaoSenha().trim().isEmpty())
				
			return msgRetornoVazio;
		
		if(!cliente.getSenha().equals(cliente.getConfirmacaoSenha()))
			
			return "Confirma��o de senha deve ser igual a senha!";
		
		ValidarPadraoSenha validarPadrao = new ValidarPadraoSenha();

		return validarPadrao.processar(cliente);
	}

}
