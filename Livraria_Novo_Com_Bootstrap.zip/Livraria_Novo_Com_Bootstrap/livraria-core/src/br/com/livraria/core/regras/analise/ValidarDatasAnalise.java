package br.com.livraria.core.regras.analise;

import java.util.Date;

import br.com.livraria.core.IStrategy;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.analise.AnaliseCategoriaMaisVendida;

public class ValidarDatasAnalise implements IStrategy {

	@Override
	public String processar(EntidadeDominio entidade) {
		AnaliseCategoriaMaisVendida analise = (AnaliseCategoriaMaisVendida) entidade;
		
		if(analise.getDtInicio() == null || analise.getDtFim() == null || 
				analise.getDtInicio().after(analise.getDtFim()) || analise.getDtInicio().after(new Date()))
			return "Por favor, preencha as datas com valores v�lidos!";
		
		return null;
			
	}

}
