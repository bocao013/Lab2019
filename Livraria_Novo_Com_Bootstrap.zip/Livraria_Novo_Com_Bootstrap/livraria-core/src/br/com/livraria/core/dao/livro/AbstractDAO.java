package br.com.livraria.core.dao.livro;

import java.sql.Connection;

import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.core.IDAO;
import br.com.livraria.core.jdbc.Conexao;

public abstract class AbstractDAO implements IDAO {
	public Connection connection;
	public boolean controleTransacao;

	public AbstractDAO() {
		controleTransacao = true; // a menos que configurado ao contr�rio, gerencia as conex�es automaticamente
	}
	// Para servir para todos, todas as classes tem ID pois herdam de EntidadeDominio
	public void excluir(EntidadeDominio entidade) {
		

	}
		
	protected void openConnection(){
		try {
			if(connection == null || connection.isClosed())
				connection = Conexao.getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		} 
	}
	
	protected void prepararDaoSubconsulta(AbstractDAO aDao, Connection conexao) {
		aDao.connection = conexao;
		aDao.controleTransacao = false;
	}

}
