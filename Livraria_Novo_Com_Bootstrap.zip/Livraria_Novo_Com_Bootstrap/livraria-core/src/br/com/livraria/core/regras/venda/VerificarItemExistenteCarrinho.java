package br.com.livraria.core.regras.venda;

import br.com.livraria.core.IStrategy;
import br.com.livraria.core.dao.livro.LivroDAO;
import br.com.livraria.core.dao.venda.ItemEstoqueDAO;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.livro.Livro;
import br.com.livraria.dominio.venda.ItemEstoque;
import br.com.livraria.dominio.venda.ItemPedido;
import br.com.livraria.dominio.venda.NovoItemPedido;
import br.com.livraria.dominio.venda.Pedido;

public class VerificarItemExistenteCarrinho implements IStrategy {

	@Override
	public String processar(EntidadeDominio entidade) {
		// verificar se j� existe o item no carrinho e alterar somente a quantidade, substituindo depois o item na mesma posi��o
		NovoItemPedido novoItemPedido = (NovoItemPedido) entidade;
		Pedido carrinho = novoItemPedido.getCarrinho();
		ItemPedido itemPedido = novoItemPedido.getNovoItem();
		
		ItemEstoqueDAO itemEstoqueDAO = new ItemEstoqueDAO();
		for(int i = 0 ; i < carrinho.getItems().size(); i++) {
			ItemPedido itemCarrinho = carrinho.getItems().get(i);
			if(itemCarrinho.getLivro().getId() == itemPedido.getLivro().getId()) {
				//  consultar o livro no banco para garantir que o t�tulo est� preenchido
				LivroDAO livroDao = new LivroDAO();
				Livro consulta = new Livro();	
				consulta.setId(itemCarrinho.getLivro().getId());
				consulta = (Livro) livroDao.listar(consulta).get(0);
				
				return String.format("%s j� est� no seu carrinho", consulta.getTitulo());
			}			
		}	
		
		ItemEstoque itemEstoque = new ItemEstoque();
		itemEstoque.setLivro(itemPedido.getLivro());
		itemEstoque = (ItemEstoque) itemEstoqueDAO.listar(itemEstoque).get(0);
		if(itemPedido.getQuantidade() > itemEstoque.getQuantidade()) {
			return String.format("S� existem %d deste item em estoque", itemEstoque.getQuantidade());
		}		
		
		carrinho.getItems().add(itemPedido);
		novoItemPedido.setCarrinho(carrinho);
		entidade = novoItemPedido;
		return null;
	}

}
