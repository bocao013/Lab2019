package br.com.livraria.core.regras.livro;

import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.livro.Livro;
import br.com.livraria.core.IStrategy;

public class ValidarDimensoesLivro implements IStrategy{

	@Override
	public String processar(EntidadeDominio entidade) {
		Livro livro = (Livro)entidade;
		if(livro.getDimensoes() == null || livro.getDimensoes().getAltura() == null || livro.getDimensoes().getLargura() == null || livro.getDimensoes().getPeso() == null ||
				livro.getDimensoes().getProfundidade() == null)
			return "Altura, Largura, Peso e Profundidade s�o obrigat�rios";
		
		if(livro.getDimensoes().getAltura() <= 0 || livro.getDimensoes().getLargura() <= 0 ||
				livro.getDimensoes().getPeso() <= 0 || livro.getDimensoes().getProfundidade() <= 0)
			return "Altura, Largura, Peso e Profundidade devem ser maiores do que 0";
		return null;
	}

}
