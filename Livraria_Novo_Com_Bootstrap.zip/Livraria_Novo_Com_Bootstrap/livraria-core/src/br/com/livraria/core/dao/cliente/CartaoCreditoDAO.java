package br.com.livraria.core.dao.cliente;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.mysql.jdbc.Statement;

import br.com.livraria.core.dao.livro.AbstractDAO;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.cliente.CartaoCredito;
import br.com.livraria.dominio.cliente.Cliente;

public class CartaoCreditoDAO extends AbstractDAO {

	/**
	 *  <3 <3 <3
	 *  <3 <3
	 *  <3
	 */
	public void salvar(EntidadeDominio entidade) {
		openConnection();
		PreparedStatement pst = null;
		CartaoCredito cartaoCredito = (CartaoCredito) entidade;

		try {
			connection.setAutoCommit(false);
			StringBuilder sql = new StringBuilder();
			sql.append("INSERT INTO cartao_credito ");
			sql.append("(numero, nome, codigo_seguranca, dt_vencimento, primario)");
			sql.append(" VALUES (?, ?, ?, ?, ?)");

			pst = connection.prepareStatement(sql.toString(), Statement.RETURN_GENERATED_KEYS);
			pst.setString(1, cartaoCredito.getNumero());
			pst.setString(2, cartaoCredito.getNome());
			pst.setString(3, cartaoCredito.getCodigoSeguranca());
	
			Timestamp timeStamp = new Timestamp(cartaoCredito.getDtVencimento().getTime());
			pst.setTimestamp(4, timeStamp);
			
			pst.setBoolean(5, cartaoCredito.getPrimario());
		
			pst.executeUpdate();

			ResultSet rs = pst.getGeneratedKeys();

			int id = 0;
			if (rs.next())
				id = rs.getInt(1);
			cartaoCredito.setId(id);
			
			String query = "insert into cliente_cartao_credito (id_cliente, id_cartao_credito) values (?, ?)";
			PreparedStatement pstCartaoCliente = connection.prepareStatement(query);
			pstCartaoCliente.setInt(1, cartaoCredito.getCliente().getId());	
			pstCartaoCliente.setInt(2, cartaoCredito.getId());	
			pstCartaoCliente.executeUpdate();	
			pstCartaoCliente.close();
			
			entidade = cartaoCredito;
	
		} catch (Exception e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {

				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				if(controleTransacao) {
					connection.commit();
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	public void alterar(EntidadeDominio entidade) {
		openConnection();
		PreparedStatement pst = null;
		CartaoCredito cartaoCredito = (CartaoCredito) entidade;

		try {
			connection.setAutoCommit(false);
			StringBuilder sql = new StringBuilder();
			sql.append("UPDATE cartao_credito set ");
			sql.append("numero=?, nome=?, codigo_seguranca=?, dt_vencimento=?, primario=?");
			sql.append(" WHERE id_cartao_credito=? ");

			pst = connection.prepareStatement(sql.toString(), Statement.RETURN_GENERATED_KEYS);
			pst.setString(1, cartaoCredito.getNumero());
			pst.setString(2, cartaoCredito.getNome());
			pst.setString(3, cartaoCredito.getCodigoSeguranca());
			
			Timestamp timeStamp = new Timestamp(cartaoCredito.getDtVencimento().getTime());
			
			pst.setTimestamp(4, timeStamp);
			
			pst.setBoolean(5, cartaoCredito.getPrimario());
		
			pst.setInt(6, cartaoCredito.getId());
			
			pst.executeUpdate();
			

		} catch (Exception e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {

				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				if(controleTransacao) {
					connection.commit();
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}	
	    public List<EntidadeDominio> listar(EntidadeDominio entidade) {
		PreparedStatement pst = null;

		CartaoCredito cartaoCredito = (CartaoCredito) entidade;
		String sql = "select * from cartao_credito";

		if (cartaoCredito.getId() != null)
			sql = "select * from cartao_credito where id_cartao_credito = ?";
		
		try {
			openConnection();
			pst = connection.prepareStatement(sql);
			if (sql.equals("select * from cartao_credito where id_cartao_credito = ?"))
				pst.setInt(1, cartaoCredito.getId());
			
			ResultSet rs = pst.executeQuery();
			List<EntidadeDominio> cartaoCreditos = new ArrayList<EntidadeDominio>();

			while (rs.next()) {
				CartaoCredito c = new CartaoCredito();
				c.setId(rs.getInt("id_cartao_credito"));
				c.setNumero(rs.getString("numero"));
				c.setNome(rs.getString("nome"));
				c.setCodigoSeguranca(rs.getString("codigo_seguranca"));
				
				Timestamp timeStamp = rs.getTimestamp("dt_vencimento");
				c.setDtVencimento(new Date(timeStamp.getTime()));
				
				c.setPrimario(rs.getBoolean("primario"));
				
				sql = "select id_cliente from cliente_cartao_credito where id_cartao_credito = ?";
				PreparedStatement pstCliente = connection.prepareStatement(sql);
				pstCliente.setInt(1, c.getId());	
				ResultSet resultado = pstCliente.executeQuery();
				resultado.next();
				
				// possivelmente inutil
				Integer idCliente = resultado.getInt("id_cliente");
				
				ClienteDAO clienteDao = new ClienteDAO();				
				clienteDao.setSubConsulta(true);
				prepararDaoSubconsulta(clienteDao, connection);
				Cliente cliente = new Cliente();
				cliente.setId(idCliente);
				cliente = (Cliente)clienteDao.listar(cliente).get(0);
				
				c.setCliente(cliente);
				
				
				cartaoCreditos.add(c);
			}
			return cartaoCreditos;

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				if(controleTransacao) {
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return null;	    
	    }	    
}

