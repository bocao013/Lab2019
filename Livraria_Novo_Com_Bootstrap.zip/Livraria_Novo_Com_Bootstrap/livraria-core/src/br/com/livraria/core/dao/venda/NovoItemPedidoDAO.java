package br.com.livraria.core.dao.venda;

import java.util.ArrayList;
import java.util.List;

import br.com.livraria.core.IDAO;
import br.com.livraria.dominio.EntidadeDominio;

public class NovoItemPedidoDAO implements IDAO {

	@Override
	public void salvar(EntidadeDominio entidade) {
		// TODO Auto-generated method stub

	}

	@Override
	public void alterar(EntidadeDominio entidade) {
		// TODO Auto-generated method stub

	}

	@Override
	public void excluir(EntidadeDominio entidade) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<EntidadeDominio> listar(EntidadeDominio entidade) {
		// TODO Auto-generated method stub
		List<EntidadeDominio> retorno = new ArrayList<EntidadeDominio>();
		retorno.add(entidade);
		
		return retorno;
	}

}
