package br.com.livraria.core.dao.cliente;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Statement;

import br.com.livraria.core.dao.livro.AbstractDAO;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.cliente.Logradouro;
import br.com.livraria.dominio.cliente.TipoLogradouro;

public class LogradouroDAO extends AbstractDAO {

	/**
	 *  <3 <3 <3
	 *  <3 <3
	 *  <3
	 */
	public void salvar(EntidadeDominio entidade) {
		openConnection();
		PreparedStatement pst = null;
		Logradouro logradouro = (Logradouro) entidade;

		try {
			connection.setAutoCommit(false);
			StringBuilder sql = new StringBuilder();
			sql.append("INSERT INTO logradouro ");
			sql.append("(logradouro, id_tipo_logradouro)");
			sql.append(" VALUES (?,?)");

			pst = connection.prepareStatement(sql.toString(), Statement.RETURN_GENERATED_KEYS);
			pst.setString(1, logradouro.getLogradouro());
			pst.setInt(2, logradouro.getTipoLogradouro().getId());
		
			pst.executeUpdate();

			ResultSet rs = pst.getGeneratedKeys();

			int id = 0;
			if (rs.next())
				id = rs.getInt(1);

			entidade.setId(id);
		
		} catch (Exception e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {

				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				if(controleTransacao){
					connection.commit();
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	public void alterar(EntidadeDominio entidade) {
		openConnection();
		PreparedStatement pst = null;
		Logradouro logradouro = (Logradouro) entidade;

		try {
			connection.setAutoCommit(false);
			StringBuilder sql = new StringBuilder();
			sql.append("UPDATE logradouro set ");
			sql.append("logradouro=?, id_tipo_logradouro=?");
			sql.append(" WHERE id_logradouro=? ");

			pst = connection.prepareStatement(sql.toString(), Statement.RETURN_GENERATED_KEYS);
			pst.setString(1, logradouro.getLogradouro());
			pst.setInt(2, logradouro.getTipoLogradouro().getId());
			pst.setInt(3, logradouro.getId());
			
			pst.executeUpdate();

			
		} catch (Exception e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {

				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				if(controleTransacao){
					connection.commit();
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}	
	    public List<EntidadeDominio> listar(EntidadeDominio entidade) {
		PreparedStatement pst = null;

		Logradouro logradouro = (Logradouro) entidade;
		String sql = "select * from logradouro";

		if (logradouro.getId() != null)
			sql = "select * from logradouro where id_logradouro = ?";
		
		try {
			openConnection();
			pst = connection.prepareStatement(sql);
			if (sql.equals("select * from logradouro where id_logradouro = ?"))
				pst.setInt(1, logradouro.getId());
			
			ResultSet rs = pst.executeQuery();
			List<EntidadeDominio> logradouros = new ArrayList<EntidadeDominio>();

			while (rs.next()) {
				Logradouro l = new Logradouro();
				l.setId(rs.getInt("id_logradouro"));
				l.setLogradouro(rs.getString("logradouro"));
				
				// ------------------------------------------------------------------
				
				Integer idTipoLogradouro = rs.getInt("id_tipo_logradouro");
				
				TipoLogradouroDAO tipoLogradouroDao = new TipoLogradouroDAO();
				prepararDaoSubconsulta(tipoLogradouroDao, connection);
				TipoLogradouro tipoLogradouro = new TipoLogradouro();
				
				tipoLogradouro.setId(idTipoLogradouro);

				List<EntidadeDominio> tipoLogradouros = tipoLogradouroDao.listar(tipoLogradouro);			
				
				if( ! tipoLogradouros.isEmpty()){
					l.setTipoLogradouro((TipoLogradouro)tipoLogradouros.get(0));
				}
				
				// ------------------------------------------------------------------
				
				logradouros.add(l);
			}
			return logradouros;

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				if(controleTransacao) {
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return null;	    
	    }	    
}


