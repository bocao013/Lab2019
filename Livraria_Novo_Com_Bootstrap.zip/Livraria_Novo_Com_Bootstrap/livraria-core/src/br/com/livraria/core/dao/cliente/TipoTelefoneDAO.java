package br.com.livraria.core.dao.cliente;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Statement;

import br.com.livraria.core.dao.livro.AbstractDAO;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.cliente.TipoTelefone;

public class TipoTelefoneDAO extends AbstractDAO {

	/**
	 *  <3 <3 <3
	 *  <3 <3
	 *  <3
	 */
	public void salvar(EntidadeDominio entidade) {
		openConnection();
		PreparedStatement pst = null;
		TipoTelefone tipoTelefone = (TipoTelefone) entidade;

		try {
			connection.setAutoCommit(false);
			StringBuilder sql = new StringBuilder();
			sql.append("INSERT INTO tipo_telefone ");
			sql.append("(tipo_telefone)");
			sql.append(" VALUES (?)");

			pst = connection.prepareStatement(sql.toString(), Statement.RETURN_GENERATED_KEYS);
			pst.setString(1, tipoTelefone.getTipoTelefone());
		
			pst.executeUpdate();

			ResultSet rs = pst.getGeneratedKeys();

			int id = 0;
			if (rs.next())
				id = rs.getInt(1);

			entidade.setId(id);
			
		} catch (Exception e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {

				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				if(controleTransacao){
					connection.commit();
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	public void alterar(EntidadeDominio entidade) {
		openConnection();
		PreparedStatement pst = null;
		TipoTelefone tipoTelefone = (TipoTelefone) entidade;

		try {
			connection.setAutoCommit(false);
			StringBuilder sql = new StringBuilder();
			sql.append("UPDATE tipo_telefone set ");
			sql.append("tipo_telefone=?");
			sql.append(" WHERE id_tipo_telefone=? ");

			pst = connection.prepareStatement(sql.toString(), Statement.RETURN_GENERATED_KEYS);
			pst.setString(1, tipoTelefone.getTipoTelefone());
			pst.setInt(2, tipoTelefone.getId());
			pst.executeUpdate();
			
		} catch (Exception e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {

				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				if(controleTransacao){
					connection.commit();
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}	
	    public List<EntidadeDominio> listar(EntidadeDominio entidade) {
		PreparedStatement pst = null;

		TipoTelefone tipoTelefone = (TipoTelefone) entidade;
		String sql = "select * from tipo_telefone";

		if (tipoTelefone.getId() != null)
			sql = "select * from tipo_telefone where id_tipo_telefone = ?";
		
		try {
			openConnection();
			pst = connection.prepareStatement(sql);
			if (sql.equals("select * from tipo_telefone where id_tipo_telefone = ?"))
				pst.setInt(1, tipoTelefone.getId());
			
			ResultSet rs = pst.executeQuery();
			List<EntidadeDominio> tipoTelefones = new ArrayList<EntidadeDominio>();

			while (rs.next()) {
				TipoTelefone t = new TipoTelefone();
				t.setId(rs.getInt("id_tipo_telefone"));
				t.setTipoTelefone(rs.getString("tipo_telefone"));
				tipoTelefones.add(t);
			}
			return tipoTelefones;

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				if(controleTransacao){
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return null;	    
	    }	    
}
