package br.com.livraria.core.regras.venda;

import br.com.livraria.core.IStrategy;
import br.com.livraria.core.dao.venda.StatusPedidoDAO;
import br.com.livraria.core.util.PedidoUtils;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.cliente.CartaoCredito;
import br.com.livraria.dominio.venda.Pedido;
import br.com.livraria.dominio.venda.StatusPedido;

public class ValidarStatusPedido implements IStrategy {

	@Override
	public String processar(EntidadeDominio entidade) {
		Pedido pedido = (Pedido) entidade;
		StatusPedido statusPedido = new StatusPedido();
		StatusPedidoDAO statusPedidoDao = new StatusPedidoDAO();
		CartaoCredito cartao = PedidoUtils.simularRespostaOperadoraCartao(pedido);
		
		if(cartao != null) {
			statusPedido.setId(StatusPedido.REPROVADO);
			statusPedido = (StatusPedido) statusPedidoDao.listar(statusPedido).get(0);
			pedido.setStatusPedido(statusPedido);
			entidade = pedido;
			
			return String.format("Cart�o com final %s reprovado pela operadora", PedidoUtils.getUltimosDigitosCartao(cartao));
			
		} else {
			statusPedido.setId(StatusPedido.APROVADO);
			statusPedido = (StatusPedido) statusPedidoDao.listar(statusPedido).get(0);
			pedido.setStatusPedido(statusPedido);
			entidade = pedido;	
			return null;
		}
		
	}

}
