package br.com.livraria.core.regras.venda;

import br.com.livraria.core.IStrategy;
import br.com.livraria.core.util.LivroUtils;
import br.com.livraria.core.util.PedidoUtils;
import br.com.livraria.dominio.EntidadeDominio;

import br.com.livraria.dominio.venda.PagamentoCartaoCredito;
import br.com.livraria.dominio.venda.Pedido;
import br.com.livraria.dominio.venda.ProcessarMeioPagamento;

public class ValidarProcessarMeioPagamento implements IStrategy {

	private static final Double VALOR_MINIMO_PAGAMENTO = 10.00;
	@Override
	public String processar(EntidadeDominio entidade) {
		ProcessarMeioPagamento processarMeioPagamento = (ProcessarMeioPagamento)entidade;
		Pedido carrinho = processarMeioPagamento.getCarrinho();
		
		Double valorTotalPedido = LivroUtils.arredondarPreco(PedidoUtils.getValorTotal(carrinho));
		Double valorTotalPago =  LivroUtils.arredondarPreco(PedidoUtils.getValorPago(carrinho));
	
		int indexUltimoPagamento = carrinho.getPagamento().getPagamentosCartao().size() - 1;
		PagamentoCartaoCredito ultimoPagamento = carrinho.getPagamento().getPagamentosCartao()
				.get(indexUltimoPagamento);
		
		// remove o valor do ultimo cart�o, pois � o cartao que estamos tentando adicionar
		carrinho.getPagamento().getPagamentosCartao().remove(indexUltimoPagamento);
		
		valorTotalPago = valorTotalPago -  LivroUtils.arredondarPreco(ultimoPagamento.getValor());
		
		Double valorRestante = valorTotalPedido - valorTotalPago;
		
		Double restanteComPagamentoMinimo = (valorRestante - VALOR_MINIMO_PAGAMENTO);
		
		
		if(ultimoPagamento != null && ultimoPagamento.getValor() < VALOR_MINIMO_PAGAMENTO && carrinho.getPagamento().getCupom() != null && restanteComPagamentoMinimo > VALOR_MINIMO_PAGAMENTO){
			carrinho.getPagamento().getPagamentosCartao().remove(ultimoPagamento);
			return String.format("Valor m�nimo de pagamento � (R$%.2f)", VALOR_MINIMO_PAGAMENTO);
		}
		
		if( ( valorRestante <= VALOR_MINIMO_PAGAMENTO || restanteComPagamentoMinimo < VALOR_MINIMO_PAGAMENTO) &&  
				 ! ultimoPagamento.getValor().equals( valorRestante)) {
			carrinho.getPagamento().getPagamentosCartao().remove(ultimoPagamento);
			return String.format("O valor deste pagamento deve ser de (R$%.2f)", valorRestante);
		}
		
		if(valorRestante - ultimoPagamento.getValor() < VALOR_MINIMO_PAGAMENTO &&
				valorRestante - ultimoPagamento.getValor() != 0) {
			return String.format("Valor restante do pedido ser� inferior ao valor m�nimo de (R$%.2f)."
					+ " \nPara este pagamento, o valor m�ximo deve ser o total restante do pedido (R$%.2f) ou o valor (R$%.2f)", VALOR_MINIMO_PAGAMENTO, valorRestante, valorRestante - VALOR_MINIMO_PAGAMENTO );
		}
		
		// se deu tudo certo, adicionar o pagamento de volta
		carrinho.getPagamento().getPagamentosCartao().add(ultimoPagamento);
		processarMeioPagamento.setCarrinho(carrinho);
		entidade = processarMeioPagamento;
		return null;
	}

}
