package br.com.livraria.core.util;

import java.text.SimpleDateFormat;
import java.util.Date;

public class FormatadorData {

	private static SimpleDateFormat sdf;

	public static String formatarData(Date data) {
		return formatarData(data, "dd/MM/yyyy");

	}
	
	public static String formatarData(Date data, String padrao) {
		if(data == null)
			return "";
		sdf = new SimpleDateFormat(padrao);
		return sdf.format(data);

	}
}
