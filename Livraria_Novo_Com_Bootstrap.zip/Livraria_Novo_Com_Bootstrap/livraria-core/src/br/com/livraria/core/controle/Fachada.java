package br.com.livraria.core.controle;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import br.com.livraria.core.IDAO;
import br.com.livraria.core.IFachada;
import br.com.livraria.core.IStrategy;
import br.com.livraria.core.aplicacao.Resultado;
import br.com.livraria.core.dao.analise.AnaliseCategoriaMaisVendidaDAO;
import br.com.livraria.core.dao.cliente.CartaoCreditoDAO;
import br.com.livraria.core.dao.cliente.CidadeDAO;
import br.com.livraria.core.dao.cliente.ClienteDAO;
import br.com.livraria.core.dao.cliente.EnderecoDAO;
import br.com.livraria.core.dao.cliente.EstadoDAO;
import br.com.livraria.core.dao.cliente.PaisDAO;
import br.com.livraria.core.dao.cliente.TelefoneDAO;
import br.com.livraria.core.dao.cliente.TipoLogradouroDAO;
import br.com.livraria.core.dao.cliente.TipoResidenciaDAO;
import br.com.livraria.core.dao.cliente.TipoTelefoneDAO;
import br.com.livraria.core.dao.livro.CategoriaDAO;
import br.com.livraria.core.dao.livro.GrupoLivroDAO;
import br.com.livraria.core.dao.livro.LivroDAO;
import br.com.livraria.core.dao.livro.SubCategoriaDAO;
import br.com.livraria.core.dao.livro.UsuarioDAO;
import br.com.livraria.core.dao.venda.CupomDAO;
import br.com.livraria.core.dao.venda.CupomTrocaDAO;
import br.com.livraria.core.dao.venda.ItemEstoqueDAO;
import br.com.livraria.core.dao.venda.ItemPedidoDAO;
import br.com.livraria.core.dao.venda.NovoItemPedidoDAO;
import br.com.livraria.core.dao.venda.PagamentoDAO;
import br.com.livraria.core.dao.venda.PedidoDAO;
import br.com.livraria.core.dao.venda.StatusPedidoDAO;
import br.com.livraria.core.regras.analise.ValidarDatasAnalise;
import br.com.livraria.core.regras.cartao.ValidarCamposVaziosCartao;
import br.com.livraria.core.regras.cartao.ValidarDtVencimentoCartao;
import br.com.livraria.core.regras.cliente.ValidarCamposVaziosAlterarCliente;
import br.com.livraria.core.regras.cliente.ValidarCamposVaziosSalvarCliente;
import br.com.livraria.core.regras.cliente.ValidarDtNascimentoCliente;
import br.com.livraria.core.regras.cliente.ValidarLoginCliente;
import br.com.livraria.core.regras.cliente.ValidarSenhaVazia;
import br.com.livraria.core.regras.endereco.ValidarCamposVaziosEndereco;
import br.com.livraria.core.regras.livro.ValidarCamposVaziosLivro;
import br.com.livraria.core.regras.livro.ValidarCategoriasLivro;
import br.com.livraria.core.regras.livro.ValidarDimensoesLivro;
import br.com.livraria.core.regras.livro.ValidarGrupoPrecificacao;
import br.com.livraria.core.regras.venda.AtualizarPedidosTroca;
import br.com.livraria.core.regras.venda.ProcessarAlterarEnderecoCarrinho;
import br.com.livraria.core.regras.venda.ProcessarMudarStatusPedido;
import br.com.livraria.core.regras.venda.ProcessarRealizarTroca;
import br.com.livraria.core.regras.venda.ProcessarRemoverCartaoPagamento;
import br.com.livraria.core.regras.venda.ProcessarSolicitarTroca;
import br.com.livraria.core.regras.venda.ProcessarValidarCupom;
import br.com.livraria.core.regras.venda.ValidarProcessarMeioPagamento;
import br.com.livraria.core.regras.venda.ValidarQtdeEstoque;
import br.com.livraria.core.regras.venda.ValidarStatusPedido;
import br.com.livraria.core.regras.venda.VerificarItemExistenteCarrinho;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.Usuario;
import br.com.livraria.dominio.analise.AnaliseCategoriaMaisVendida;
import br.com.livraria.dominio.cliente.CartaoCredito;
import br.com.livraria.dominio.cliente.Cidade;
import br.com.livraria.dominio.cliente.Cliente;
import br.com.livraria.dominio.cliente.Endereco;
import br.com.livraria.dominio.cliente.Estado;
import br.com.livraria.dominio.cliente.Pais;
import br.com.livraria.dominio.cliente.Telefone;
import br.com.livraria.dominio.cliente.TipoLogradouro;
import br.com.livraria.dominio.cliente.TipoResidencia;
import br.com.livraria.dominio.cliente.TipoTelefone;
import br.com.livraria.dominio.livro.Categoria;
import br.com.livraria.dominio.livro.GrupoLivro;
import br.com.livraria.dominio.livro.Livro;
import br.com.livraria.dominio.livro.SubCategoria;
import br.com.livraria.dominio.venda.AlterarEnderecoCarrinho;
import br.com.livraria.dominio.venda.Cupom;
import br.com.livraria.dominio.venda.CupomTroca;
import br.com.livraria.dominio.venda.ItemEstoque;
import br.com.livraria.dominio.venda.ItemPedido;
import br.com.livraria.dominio.venda.MudarStatusPedido;
import br.com.livraria.dominio.venda.NovoItemPedido;
import br.com.livraria.dominio.venda.Pagamento;
import br.com.livraria.dominio.venda.Pedido;
import br.com.livraria.dominio.venda.ProcessarMeioPagamento;
import br.com.livraria.dominio.venda.RealizarTroca;
import br.com.livraria.dominio.venda.RemoverCartaoPagamento;
import br.com.livraria.dominio.venda.SolicitarTroca;
import br.com.livraria.dominio.venda.StatusPedido;
import br.com.livraria.dominio.venda.ValidarCupom;

public class Fachada implements IFachada {

	private Map<String, IDAO> daos;
	private Map<String, Map<String, List<IStrategy>>> rns;
	private Resultado resultado;

	public Fachada() {
		daos = new HashMap<String, IDAO>();
		
		daos.put(Usuario.class.getName(), new UsuarioDAO());
		// MAGIC DONT TOUCH HERE 
		daos.put(Livro.class.getName(), new LivroDAO());
		daos.put(Categoria.class.getName(), new CategoriaDAO());
		daos.put(SubCategoria.class.getName(), new SubCategoriaDAO());
		daos.put(GrupoLivro.class.getName(), new GrupoLivroDAO());
		
		// cliente
		daos.put(Cliente.class.getName(), new ClienteDAO());
		daos.put(Cidade.class.getName(), new CidadeDAO());
		daos.put(Estado.class.getName(), new EstadoDAO());
		daos.put(Pais.class.getName(), new PaisDAO());
		daos.put(Endereco.class.getName(), new EnderecoDAO());
		daos.put(Telefone.class.getName(), new TelefoneDAO());
		daos.put(CartaoCredito.class.getName(), new CartaoCreditoDAO());
		daos.put(TipoLogradouro.class.getName(), new TipoLogradouroDAO());
		daos.put(TipoTelefone.class.getName(), new TipoTelefoneDAO());
		daos.put(TipoResidencia.class.getName(), new TipoResidenciaDAO());
		
		// venda
		daos.put(Cupom.class.getName(), new CupomDAO());
		daos.put(CupomTroca.class.getName(), new CupomTrocaDAO());
		daos.put(ItemEstoque.class.getName(), new ItemEstoqueDAO());
		daos.put(Pagamento.class.getName(), new PagamentoDAO());
		daos.put(Pedido.class.getName(), new PedidoDAO());
		// para as opera��es com o carrinho, que n�o precisam do banco de dados
		daos.put(ItemPedido.class.getName(), new ItemPedidoDAO());
		daos.put(NovoItemPedido.class.getName(), new NovoItemPedidoDAO());
		daos.put(StatusPedido.class.getName(), new StatusPedidoDAO());
		
		// analise
		daos.put(AnaliseCategoriaMaisVendida.class.getName(), new AnaliseCategoriaMaisVendidaDAO());
		
		rns = new HashMap<String, Map<String, List<IStrategy>>>();

		// Regras do livro
		ValidarCamposVaziosLivro validarCamposLivro = new ValidarCamposVaziosLivro();
		ValidarCategoriasLivro validarCategoriasLivro = new ValidarCategoriasLivro();
		ValidarGrupoPrecificacao validarPrecificacaoLivro = new ValidarGrupoPrecificacao();
		ValidarDimensoesLivro validarDimensoesLivro = new ValidarDimensoesLivro();
		List<IStrategy> regrasSalvarLivro = new ArrayList<IStrategy>();

		regrasSalvarLivro.add(validarCamposLivro);
		regrasSalvarLivro.add(validarCategoriasLivro);
		regrasSalvarLivro.add(validarPrecificacaoLivro);
		regrasSalvarLivro.add(validarDimensoesLivro);

		Map<String, List<IStrategy>> rnsLivro = new HashMap<String, List<IStrategy>>();

		rnsLivro.put("salvar", regrasSalvarLivro);
		rnsLivro.put("alterar", regrasSalvarLivro);

		rns.put(Livro.class.getName(), rnsLivro);	
		
		// REGRAS SALVAR DO CLIENTE
		ValidarCamposVaziosSalvarCliente validarCamposCliente = new ValidarCamposVaziosSalvarCliente();
		ValidarDtNascimentoCliente validarNascimentoCliente = new ValidarDtNascimentoCliente();
		ValidarSenhaVazia validarSenhaVazia = new ValidarSenhaVazia();
		
		List<IStrategy> regrasSalvarCliente = new ArrayList<IStrategy>();
		
		regrasSalvarCliente.add(validarCamposCliente);
		regrasSalvarCliente.add(validarNascimentoCliente);
		regrasSalvarCliente.add(validarSenhaVazia);
		
		Map<String, List<IStrategy>> rnsCliente = new HashMap<String, List<IStrategy>>();
		
		rnsCliente.put("salvar", regrasSalvarCliente);
		
		// REGRAS ALTERAR DO CLIENTE
		
		ValidarCamposVaziosAlterarCliente validarCamposVaziosAlterarCliente = new ValidarCamposVaziosAlterarCliente();
		
		List<IStrategy> regrasAlterarCliente = new ArrayList<IStrategy>();
		
		regrasAlterarCliente.add(validarCamposVaziosAlterarCliente);
		regrasAlterarCliente.add(validarSenhaVazia);
		
		// REGRAS CONSULTAR DO CLIENTE
		
		ValidarLoginCliente validarLoginCliente = new ValidarLoginCliente();
		
		List<IStrategy> regrasConsultarCliente = new ArrayList<IStrategy>();
		
		regrasConsultarCliente.add(validarLoginCliente);
		
		
		// mapa
		rnsCliente.put("alterar", regrasAlterarCliente);
		
		rns.put(Cliente.class.getName(), rnsCliente);
		
		// REGRAS DO ENDERECO
		
		ValidarCamposVaziosEndereco validarCamposVaziosEndereco = new ValidarCamposVaziosEndereco();
		List<IStrategy> regrasSalvarEndereco = new ArrayList<IStrategy>();
		
		regrasSalvarEndereco.add(validarCamposVaziosEndereco);
		
		Map<String, List<IStrategy>> rnsEndereco = new HashMap<String, List<IStrategy>>();
		
		rnsEndereco.put("salvar", regrasSalvarEndereco);
		rnsEndereco.put("alterar", regrasSalvarEndereco);
		
		rns.put(Endereco.class.getName(), rnsEndereco);
		
		// REGRAS DO CART�O
		
		ValidarCamposVaziosCartao validarCamposVaziosCartao = new ValidarCamposVaziosCartao();
		ValidarDtVencimentoCartao validarVencimentoCartao = new ValidarDtVencimentoCartao();
		List<IStrategy> regrasSalvarCartao = new ArrayList<IStrategy>();
		
		regrasSalvarCartao.add(validarCamposVaziosCartao);
		regrasSalvarCartao.add(validarVencimentoCartao);
		
		Map<String, List<IStrategy>> rnsCartao = new HashMap<String, List<IStrategy>>();
		
		rnsCartao.put("salvar", regrasSalvarCartao);
		rnsCartao.put("alterar", regrasSalvarCartao);
		
		rns.put(CartaoCredito.class.getName(), rnsCartao);
		
		
		// REGRAS DO CARRINHO
		ValidarQtdeEstoque validarQtdeEstoque = new ValidarQtdeEstoque();
		List<IStrategy> regrasConsultarItemPedido = new ArrayList<IStrategy>();
		regrasConsultarItemPedido.add(validarQtdeEstoque);
		
		Map<String, List<IStrategy>> rnsItemPedido = new HashMap<String, List<IStrategy>>();
		
		rnsItemPedido.put("consultar", regrasConsultarItemPedido);
		
		rns.put(ItemPedido.class.getName(), rnsItemPedido);
		
		// REGRAS PARA ADICIONAR UM NOVO ITEM AO CARRINHO
		VerificarItemExistenteCarrinho verificarItemExistenteCarrinho = new VerificarItemExistenteCarrinho();
		List<IStrategy> regrasConsultarNovoItemPedido = new ArrayList<IStrategy>();
		regrasConsultarNovoItemPedido.add(verificarItemExistenteCarrinho);
		
		Map<String, List<IStrategy>> rnsNovoItemPedido = new HashMap<String, List<IStrategy>>();
		
		rnsNovoItemPedido.put("consultar", regrasConsultarNovoItemPedido);
		
		rns.put(NovoItemPedido.class.getName(), rnsNovoItemPedido);
		
		// Regra /p processar meio de pagamento
		ValidarProcessarMeioPagamento validarProcessarMeioPagamento = new ValidarProcessarMeioPagamento();
		List<IStrategy> regrasProcessarMeioPagamento = new ArrayList<IStrategy>();
		regrasProcessarMeioPagamento.add(validarProcessarMeioPagamento);
		
		Map<String, List<IStrategy>> rnsProcessarMeioPagamento = new HashMap<String, List<IStrategy>>();
		
		rnsProcessarMeioPagamento.put("processar", regrasProcessarMeioPagamento);
		
		rns.put(ProcessarMeioPagamento.class.getName(), rnsProcessarMeioPagamento);
		
		// Regra /p add endere�os no carrinho
		ProcessarAlterarEnderecoCarrinho processarAlterarEnderecoCarrinho = new ProcessarAlterarEnderecoCarrinho();
		List<IStrategy> regrasProcessarEnderecoCarrinho = new ArrayList<IStrategy>();
		regrasProcessarEnderecoCarrinho.add(processarAlterarEnderecoCarrinho);
		
		Map<String, List<IStrategy>> rnsProcessarEnderecoCarrinho = new HashMap<String, List<IStrategy>>();
		
		rnsProcessarEnderecoCarrinho.put("processar", regrasProcessarEnderecoCarrinho);
		
		rns.put(AlterarEnderecoCarrinho.class.getName(), rnsProcessarEnderecoCarrinho);
		
		// Regra p/ validar cupom no carrinho
		ProcessarValidarCupom processarValidarCupom = new ProcessarValidarCupom();
		List<IStrategy> regrasProcessarValidarCupom = new ArrayList<IStrategy>();
		regrasProcessarValidarCupom.add(processarValidarCupom);
		
		Map<String, List<IStrategy>> rnsProcessarValidarCupom = new HashMap<String, List<IStrategy>>();
		
		rnsProcessarValidarCupom.put("processar", regrasProcessarValidarCupom);
		
		rns.put(ValidarCupom.class.getName(), rnsProcessarValidarCupom);
		
		// Regra p/ validar status do pedido
		ValidarStatusPedido validarStatusPedido = new ValidarStatusPedido();
		List<IStrategy> regrasSalvarPedido = new ArrayList<IStrategy>();
		regrasSalvarPedido.add(validarStatusPedido);
		
		Map<String, List<IStrategy>> rnsPedido = new HashMap<String, List<IStrategy>>();
		
		rnsPedido.put("salvar", regrasSalvarPedido);
		
		rns.put(Pedido.class.getName(), rnsPedido);
		
		// Regra p/ remover um cart�o do pagamento
		ProcessarRemoverCartaoPagamento processarRemoverCartaoCredito = new ProcessarRemoverCartaoPagamento();
		List<IStrategy> regrasProcessarRemoverCartaoCredito = new ArrayList<IStrategy>();
		regrasProcessarRemoverCartaoCredito.add(processarRemoverCartaoCredito);
		
		Map<String, List<IStrategy>> rnsProcessarRemoverCartaoCredito = new HashMap<String, List<IStrategy>>();
		
		rnsProcessarRemoverCartaoCredito.put("processar", regrasProcessarRemoverCartaoCredito);
		
		rns.put(RemoverCartaoPagamento.class.getName(), rnsProcessarRemoverCartaoCredito);
		
		// Regra p/ alterar o status de um pedido
		ProcessarMudarStatusPedido processarMudarStatusPedido = new ProcessarMudarStatusPedido();
		List<IStrategy> regrasProcessarMudarStatusPedido = new ArrayList<IStrategy>();
		regrasProcessarMudarStatusPedido.add(processarMudarStatusPedido);
		
		Map<String, List<IStrategy>> rnsProcessarMudarStatusPedido = new HashMap<String, List<IStrategy>>();
		
		rnsProcessarMudarStatusPedido.put("processar", regrasProcessarMudarStatusPedido);
		
		rns.put(MudarStatusPedido.class.getName(), rnsProcessarMudarStatusPedido);
		
		// Regra p/ solicitar a troca do pedido
		ProcessarSolicitarTroca processarSolicitarTroca = new ProcessarSolicitarTroca();
		AtualizarPedidosTroca atualizarPedidosTroca = new AtualizarPedidosTroca();
		List<IStrategy> regrasProcessarSolicitarTroca = new ArrayList<IStrategy>();
		regrasProcessarSolicitarTroca.add(processarSolicitarTroca);
		regrasProcessarSolicitarTroca.add(atualizarPedidosTroca);
		
		Map<String, List<IStrategy>> rnsProcessarSolicitarTroca = new HashMap<String, List<IStrategy>>();
		
		rnsProcessarSolicitarTroca.put("processar", regrasProcessarSolicitarTroca);
		
		rns.put(SolicitarTroca.class.getName(), rnsProcessarSolicitarTroca);
		
		// Regra p/ realizar a troca do pedido
		ProcessarRealizarTroca processarRealizarTroca = new ProcessarRealizarTroca();
		
		List<IStrategy> regrasProcessarRealizarTroca = new ArrayList<IStrategy>();
		regrasProcessarRealizarTroca.add(processarRealizarTroca);
			
		Map<String, List<IStrategy>> rnsProcessarRealizarTroca = new HashMap<String, List<IStrategy>>();
		
		rnsProcessarRealizarTroca.put("processar", regrasProcessarRealizarTroca);
		
		rns.put(RealizarTroca.class.getName(), rnsProcessarRealizarTroca);
		
		// Regra p/ data da an�lise 
		ValidarDatasAnalise validarDatasAnalise = new ValidarDatasAnalise();
		
		List<IStrategy> regrasValidarDatasAnalise = new ArrayList<IStrategy>();
		regrasValidarDatasAnalise.add(validarDatasAnalise);
			
		Map<String, List<IStrategy>> rnsValidarDatasAnalise = new HashMap<String, List<IStrategy>>();
		
		rnsValidarDatasAnalise.put("consultar", regrasValidarDatasAnalise);
		
		rns.put(AnaliseCategoriaMaisVendida.class.getName(), rnsValidarDatasAnalise);

	}

	public Resultado salvar(EntidadeDominio entidade) {
		resultado = new Resultado();
		String nomeClasse = entidade.getClass().getName();
		String msg = executarRegras(entidade, "salvar");

		if (msg == null) {
			// mesma coisa que IDAO dao = new ProdutoDAO();
			IDAO dao = daos.get(nomeClasse);
			try {
				dao.salvar(entidade);
				
			} catch (Exception e) {
				resultado.setMensagem("Erro ao salvar " + nomeClasse);
			}
		} else {
			resultado.setMensagem(msg);
		}
		List<EntidadeDominio> entidades = new ArrayList<EntidadeDominio>();
		entidades.add(entidade);
		resultado.setEntidades(entidades);
		return resultado;
	}

	public Resultado alterar(EntidadeDominio entidade) {
		resultado = new Resultado();
		String nomeClasse = entidade.getClass().getName();
		String msg = executarRegras(entidade, "alterar");

		if (msg == null) {
			// mesma coisa que IDAO dao = new ProdutoDAO();
			IDAO dao = daos.get(nomeClasse);
			try {
				dao.alterar(entidade);
			} catch (Exception e) {
				resultado.setMensagem("Erro ao alterar " + nomeClasse);
			}
		} else {
			resultado.setMensagem(msg);
		}
		List<EntidadeDominio> entidades = new ArrayList<EntidadeDominio>();
		entidades.add(entidade);
		resultado.setEntidades(entidades);
		return resultado;
	}

	public Resultado excluir(EntidadeDominio entidade) {
		// TODO Auto-generated method stub
		return null;
	}

	public Resultado listar(EntidadeDominio entidade) {
		resultado = new Resultado();
		String nmClasse = entidade.getClass().getName();

		String msg = executarRegras(entidade, "consultar");

		if (msg == null) {
			IDAO dao = daos.get(nmClasse);
			try {
				resultado.setEntidades(dao.listar(entidade));
			} catch (Exception e) {
				e.printStackTrace();
				resultado.setMensagem("N�o foi poss�vel realizar a consulta!");
			}
		} else {
			resultado.setMensagem(msg);

		}

		return resultado;

	}
	
	public Resultado processar(EntidadeDominio entidade) {
		resultado = new Resultado();
		String msg = executarRegras(entidade, "processar");
		
		List<EntidadeDominio> entidades = new ArrayList<EntidadeDominio>();
		entidades.add(entidade);
		resultado.setEntidades(entidades);
		
		if (msg != null) {
			resultado.setMensagem(msg);
		}
		return resultado;
	}

	private String executarRegras(EntidadeDominio entidade, String operacao) {
		String nomeClasse = entidade.getClass().getName();
		StringBuilder msg = new StringBuilder();

		Map<String, List<IStrategy>> regrasOperacao = rns.get(nomeClasse);
		if (regrasOperacao != null) {
			List<IStrategy> regras = regrasOperacao.get(operacao);
			if (regras != null) {
				for (IStrategy s : regras) {
					String mensagem = s.processar(entidade);

					if (mensagem != null) {
						msg.append(mensagem);
						msg.append("\n");
					}
				}
			}
		}
		if (msg.length() > 0)
			return msg.toString();
		else
			return null;
	}

}
