package br.com.livraria.core.dao.livro;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Statement;

import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.livro.SubCategoria;

public class SubCategoriaDAO extends AbstractDAO {

	/**
	 *  <3 <3 <3
	 *  <3 <3
	 *  <3
	 */
	public void salvar(EntidadeDominio entidade) {
		openConnection();
		PreparedStatement pst = null;
		SubCategoria subcategoria = (SubCategoria) entidade;

		try {
			connection.setAutoCommit(false);
			StringBuilder sql = new StringBuilder();
			sql.append("INSERT INTO subcategoria ");
			sql.append("(nome)");
			sql.append(" VALUES (?)");

			pst = connection.prepareStatement(sql.toString(), Statement.RETURN_GENERATED_KEYS);
			pst.setString(1, subcategoria.getNome());
		
			pst.executeUpdate();

			ResultSet rs = pst.getGeneratedKeys();

			int id = 0;
			if (rs.next())
				id = rs.getInt(1);

			entidade.setId(id);
		
		} catch (Exception e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {

				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				if(controleTransacao){
					connection.commit();
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	public void alterar(EntidadeDominio entidade) {
		openConnection();
		PreparedStatement pst = null;
		SubCategoria subcategoria = (SubCategoria) entidade;

		try {
			connection.setAutoCommit(false);
			StringBuilder sql = new StringBuilder();
			sql.append("UPDATE subcategoria set ");
			sql.append("nome=?");
			sql.append(" WHERE id_subcategoria=? ");

			pst = connection.prepareStatement(sql.toString(), Statement.RETURN_GENERATED_KEYS);
			pst.setString(1, subcategoria.getNome());
			pst.setInt(2, subcategoria.getId());
			pst.executeUpdate();
		
			
		} catch (Exception e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {

				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				if(controleTransacao){
					connection.commit();
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}	
	    public List<EntidadeDominio> listar(EntidadeDominio entidade) {
		PreparedStatement pst = null;

		SubCategoria subcategoria = (SubCategoria) entidade;
		String sql = "select * from subcategoria";

		if (subcategoria.getId() != null)
			sql = "select * from subcategoria where id_subcategoria = ?";
		
		try {
			openConnection();
			pst = connection.prepareStatement(sql);
			if (sql.equals("select * from subcategoria where id_subcategoria = ?"))
				pst.setInt(1, subcategoria.getId());
			
			ResultSet rs = pst.executeQuery();
			List<EntidadeDominio> subcategorias = new ArrayList<EntidadeDominio>();

			while (rs.next()) {
				SubCategoria s = new SubCategoria();
				s.setId(rs.getInt("id_subcategoria"));
				s.setNome(rs.getString("nome"));
				subcategorias.add(s);
			}
			return subcategorias;

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				if(controleTransacao) {
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return null;	    
	    }	    
}

