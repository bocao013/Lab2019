package br.com.livraria.core.dao.cliente;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Statement;

import br.com.livraria.core.dao.livro.AbstractDAO;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.cliente.TipoResidencia;

public class TipoResidenciaDAO extends AbstractDAO {

	/**
	 *  <3 <3 <3
	 *  <3 <3
	 *  <3
	 */
	public void salvar(EntidadeDominio entidade) {
		openConnection();
		PreparedStatement pst = null;
		TipoResidencia tipoResidencia = (TipoResidencia) entidade;

		try {
			connection.setAutoCommit(false);
			StringBuilder sql = new StringBuilder();
			sql.append("INSERT INTO tipo_residencia ");
			sql.append("(tipo_residencia)");
			sql.append(" VALUES (?)");

			pst = connection.prepareStatement(sql.toString(), Statement.RETURN_GENERATED_KEYS);
			pst.setString(1, tipoResidencia.getTipoResidencia());
		
			pst.executeUpdate();

			ResultSet rs = pst.getGeneratedKeys();

			int id = 0;
			if (rs.next())
				id = rs.getInt(1);

			entidade.setId(id);
			
		} catch (Exception e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {

				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				if(controleTransacao) {
					connection.commit();
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	public void alterar(EntidadeDominio entidade) {
		openConnection();
		PreparedStatement pst = null;
		TipoResidencia tipoResidencia = (TipoResidencia) entidade;

		try {
			connection.setAutoCommit(false);
			StringBuilder sql = new StringBuilder();
			sql.append("UPDATE tipo_residencia set ");
			sql.append("tipo_residencia=?");
			sql.append(" WHERE id_tipo_residencia=? ");

			pst = connection.prepareStatement(sql.toString(), Statement.RETURN_GENERATED_KEYS);
			pst.setString(1, tipoResidencia.getTipoResidencia());
			pst.setInt(2, tipoResidencia.getId());
			pst.executeUpdate();

			
		} catch (Exception e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {

				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				if(controleTransacao) {
					connection.commit();
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}	
	    public List<EntidadeDominio> listar(EntidadeDominio entidade) {
		PreparedStatement pst = null;

		TipoResidencia tipoResidencia = (TipoResidencia) entidade;
		String sql = "select * from tipo_residencia";

		if (tipoResidencia.getId() != null)
			sql = "select * from tipo_residencia where id_tipo_residencia = ?";
		
		try {
			openConnection();
			pst = connection.prepareStatement(sql);
			if (sql.equals("select * from tipo_residencia where id_tipo_residencia = ?"))
				pst.setInt(1, tipoResidencia.getId());
			
			ResultSet rs = pst.executeQuery();
			List<EntidadeDominio> tipoResidencias = new ArrayList<EntidadeDominio>();

			while (rs.next()) {
				TipoResidencia t = new TipoResidencia();
				t.setId(rs.getInt("id_tipo_residencia"));
				t.setTipoResidencia(rs.getString("tipo_residencia"));
				tipoResidencias.add(t);
			}
			return tipoResidencias;

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				if(controleTransacao) {
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return null;	    
	    }	    
}



