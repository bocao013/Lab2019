package br.com.livraria.core.dao.analise;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import br.com.livraria.core.dao.livro.AbstractDAO;
import br.com.livraria.core.util.FormatadorData;
import br.com.livraria.core.util.LivroUtils;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.analise.AnaliseCategoriaMaisVendida;
import br.com.livraria.dominio.analise.ResultadoAnalise;
import br.com.livraria.dominio.livro.Categoria;

public class AnaliseCategoriaMaisVendidaDAO extends AbstractDAO {

	@Override
	public void salvar(EntidadeDominio entidade) {
		// TODO Auto-generated method stub

	}

	@Override
	public void alterar(EntidadeDominio entidade) {
		// TODO Auto-generated method stub

	}

	@Override
	public void excluir(EntidadeDominio entidade) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<EntidadeDominio> listar(EntidadeDominio entidade) {
		PreparedStatement pst = null;

		AnaliseCategoriaMaisVendida analise = (AnaliseCategoriaMaisVendida) entidade;

		String sqlDatas = "select distinct pedido.dt_pedido from pedido "
				+ "where (dt_pedido >= ? and dt_pedido <= ? ) and (pedido.id_status_pedido = 3 or pedido.id_status_pedido = 7) "
				+ "order by dt_pedido asc";
		String sql = "select pedido.dt_pedido, categoria.nome as categoria, sum(item_pedido.quantidade) as quantidade from pedido "
				+ "inner join item_pedido on item_pedido.id_pedido = pedido.id_pedido "
				+ "inner join livro on livro.id_livro = item_pedido.id_livro "
				+ "inner join livro_categoria on livro_categoria.id_livro = livro.id_livro "
				+ "inner join categoria on categoria.id_categoria = livro_categoria.id_categoria "
				+ "inner join status_pedido on status_pedido.id_status_pedido = pedido.id_status_pedido "
				+ "where (dt_pedido >= ? and dt_pedido <= ? ) and (pedido.id_status_pedido = 3 or pedido.id_status_pedido = 7) "
				+ "group by dt_pedido, categoria";

		try {
			openConnection();

			pst = connection.prepareStatement(sqlDatas);

			Timestamp timeInicio = new Timestamp(analise.getDtInicio().getTime());
			pst.setTimestamp(1, timeInicio);

			Timestamp timeFim = new Timestamp(analise.getDtFim().getTime());
			pst.setTimestamp(2, timeFim);

			ResultSet rs = pst.executeQuery();

			while (rs.next()) {

				if (rs.isFirst()) {
					Timestamp ts = rs.getTimestamp("dt_pedido");
					Date dataPedido = new Date(ts.getTime());
					if (dataPedido.after(analise.getDtInicio())) {
						String dataFormatada = FormatadorData.formatarData(analise.getDtInicio());
						analise.getDatasPedidos().add(dataFormatada);
					}
				}

				Timestamp ts = rs.getTimestamp("dt_pedido");
				Date dataPedido = new Date(ts.getTime());

				String dataFormatada = FormatadorData.formatarData(dataPedido);
				analise.getDatasPedidos().add(dataFormatada);

				if (rs.isLast()) {
					ts = rs.getTimestamp("dt_pedido");
					dataPedido = new Date(ts.getTime());
					if (dataPedido.before(analise.getDtFim())) {
						dataFormatada = FormatadorData.formatarData(analise.getDtFim());
						analise.getDatasPedidos().add(dataFormatada);
					}
				}

			}

			rs.close();
			pst.close();

			pst = connection.prepareStatement(sql);

			pst.setTimestamp(1, timeInicio);

			pst.setTimestamp(2, timeFim);

			rs = pst.executeQuery();
			List<EntidadeDominio> analises = new ArrayList<EntidadeDominio>();

			while (rs.next()) {
				String nomeCategoria = rs.getString("categoria");

				Timestamp ts = rs.getTimestamp("dt_pedido");
				Date dataPedido = new Date(ts.getTime());

				Integer quantidade = rs.getInt("quantidade");

				analise.getMapaCategoria(nomeCategoria).put(FormatadorData.formatarData(dataPedido), quantidade);
			}
			analises.add(analise);
			return analises;

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				if (controleTransacao)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return null;
	}
}
