package br.com.livraria.core.regras.venda;

import br.com.livraria.core.IStrategy;
import br.com.livraria.core.dao.venda.PedidoDAO;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.venda.MudarStatusPedido;
import br.com.livraria.dominio.venda.Pedido;
import br.com.livraria.dominio.venda.StatusPedido;

public class ProcessarMudarStatusPedido implements IStrategy {

	@Override
	public String processar(EntidadeDominio entidade) {
		PedidoDAO pedidoDao = new PedidoDAO();
		MudarStatusPedido mudarStatusPedido = (MudarStatusPedido)entidade;
		Pedido pedido = mudarStatusPedido.getPedido();
		pedido = (Pedido) pedidoDao.listar(pedido).get(0);
		StatusPedido statusPedido = new StatusPedido();
		statusPedido.setId(mudarStatusPedido.getId());
		pedido.setStatusPedido(statusPedido);
		pedidoDao.alterar(pedido);
		return null;
	}

}
