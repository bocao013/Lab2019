package br.com.livraria.core.regras.cartao;

import br.com.livraria.core.IStrategy;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.cliente.CartaoCredito;

public class ValidarCamposVaziosCartao implements IStrategy {

	@Override
	public String processar(EntidadeDominio entidade) {
		String msgRetorno = "Todos os campos s�o obrigat�rios!";
		CartaoCredito cartaoCredito = (CartaoCredito)entidade;
		
		if(cartaoCredito.getNumero() == null || cartaoCredito.getNome() == null ||
				cartaoCredito.getCodigoSeguranca() == null)
				
			return msgRetorno;
		
		
		if(cartaoCredito.getNumero().trim().isEmpty()  || cartaoCredito.getNome().trim().isEmpty()  ||
				cartaoCredito.getCodigoSeguranca().trim().isEmpty())
			return msgRetorno;
	
		return null;
	}

}
