package br.com.livraria.core.regras.livro;

import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.livro.Livro;
import br.com.livraria.core.IStrategy;

public class ValidarCategoriasLivro implements IStrategy {

	@Override
	public String processar(EntidadeDominio entidade) {
		Livro livro = (Livro)entidade;
		
		if(livro.getCategorias() != null && livro.getCategorias().isEmpty())
			return "Selecione ao menos uma categoria!";
		
		if(livro.getSubCategorias()!= null && livro.getSubCategorias().isEmpty())
			return "Selecione ao menos uma Subcategoria!";
		
		return null;
	}

}
