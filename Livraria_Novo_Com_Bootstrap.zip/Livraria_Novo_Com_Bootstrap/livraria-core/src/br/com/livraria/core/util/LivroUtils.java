package br.com.livraria.core.util;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;

import br.com.livraria.dominio.cliente.Cliente;
import br.com.livraria.dominio.livro.Livro;
import br.com.livraria.dominio.venda.ItemPedido;
import br.com.livraria.dominio.venda.PagamentoCartaoCredito;
import br.com.livraria.dominio.venda.Pedido; 

public class LivroUtils {
	
	private static DecimalFormat df = new DecimalFormat("#,###.00");
	
	
	public static String formatarPrecoLivro(Livro livro){
		StringBuilder sb = new StringBuilder();
		Double precoCalculado = calcularPrecoLivro(livro);
		sb.append("R$").append(df.format(precoCalculado));
		return sb.toString();
	}
	
	public static Double calcularPrecoLivro(Livro livro){		
		return calcularPrecoLivro(livro, 1);
	}
	
	public static Double calcularPrecoLivro(Livro livro, int qtde){		
		return (livro.getPreco() + (livro.getPreco() * livro.getGrupolivro().getMargemLucro())) * qtde;
	}

	public static Double arredondarPreco(Double preco){
		if(preco == null)
			return null;
		
		BigDecimal bd = new BigDecimal(preco);
		return bd.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();

	}
	
	public static String formatarPreco(Double preco){		
		return String.format("R$%s", df.format(arredondarPreco(preco)));
	}
	
	public static String gerarNumeroCupom(Pedido pedido) {
		StringBuilder sb = new StringBuilder();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy");
		DecimalFormat idf = new DecimalFormat("00000");
		sb.append("CT").append(sdf.format(pedido.getDtPedido())).append(idf.format(pedido.getId())).append(idf.format(pedido.getCliente().getId().doubleValue()));		
		return sb.toString();
		
	}
	
	
		
}
