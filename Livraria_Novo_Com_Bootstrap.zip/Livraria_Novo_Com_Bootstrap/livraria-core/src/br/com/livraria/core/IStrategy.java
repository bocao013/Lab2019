package br.com.livraria.core;

import br.com.livraria.dominio.EntidadeDominio;

public interface IStrategy {
	
	public String processar(EntidadeDominio entidade);

}
