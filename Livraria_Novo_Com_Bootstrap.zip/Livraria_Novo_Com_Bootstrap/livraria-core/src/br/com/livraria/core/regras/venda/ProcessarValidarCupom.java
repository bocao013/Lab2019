package br.com.livraria.core.regras.venda;

import java.util.List;

import br.com.livraria.core.IStrategy;
import br.com.livraria.core.dao.venda.CupomDAO;
import br.com.livraria.core.dao.venda.CupomTrocaDAO;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.venda.Cupom;
import br.com.livraria.dominio.venda.CupomTroca;
import br.com.livraria.dominio.venda.ValidarCupom;

public class ProcessarValidarCupom implements IStrategy {

	@Override
	public String processar(EntidadeDominio entidade) {
		CupomDAO cupomDao = new CupomDAO();
		CupomTrocaDAO cupomTrocaDao = new CupomTrocaDAO();
		
		ValidarCupom validarCupom = (ValidarCupom) entidade;
		Cupom cupom = validarCupom.getCupom();
		CupomTroca cupomTroca = validarCupom.getCupomTroca();
		
		List<EntidadeDominio> resultadoCupom = cupomDao.listar(cupom);
		List<EntidadeDominio> resultadoCupomTroca = cupomTrocaDao.listar(cupomTroca);
		
		if(!resultadoCupom.isEmpty()) {
			cupom = (Cupom) resultadoCupom.get(0);
			validarCupom.getCarrinho().getPagamento().setCupom(cupom);	
		}else if (!resultadoCupomTroca.isEmpty()){
			cupomTroca = (CupomTroca) resultadoCupomTroca.get(0);
			cupomTroca.setFoiUtilizado(true);
			validarCupom.getCarrinho().getPagamento().getCuponsTroca().add(cupomTroca);
		} else {
			return "Cupom n�o encontrado";
		}
		entidade = validarCupom;
		return null;
	}

}
