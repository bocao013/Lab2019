package br.com.livraria.core.regras.venda;

import java.util.Date;

import br.com.livraria.core.IStrategy;
import br.com.livraria.core.dao.cliente.ClienteDAO;
import br.com.livraria.core.dao.venda.CupomTrocaDAO;
import br.com.livraria.core.dao.venda.ItemEstoqueDAO;
import br.com.livraria.core.dao.venda.PedidoDAO;
import br.com.livraria.core.util.LivroUtils;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.cliente.Cliente;
import br.com.livraria.dominio.livro.Livro;
import br.com.livraria.dominio.venda.CupomTroca;
import br.com.livraria.dominio.venda.ItemEstoque;
import br.com.livraria.dominio.venda.ItemPedido;
import br.com.livraria.dominio.venda.Pedido;
import br.com.livraria.dominio.venda.RealizarTroca;
import br.com.livraria.dominio.venda.StatusPedido;

public class ProcessarRealizarTroca implements IStrategy {

	@Override
	public String processar(EntidadeDominio entidade) {
		try {
			RealizarTroca realizarTroca = (RealizarTroca) entidade;
			Pedido pedidoTroca = realizarTroca.getPedidoTroca();
			StatusPedido statusTrocado = new StatusPedido();		
			statusTrocado.setId(StatusPedido.TROCADO);
			
			
			PedidoDAO pedidoDao = new PedidoDAO();
			pedidoTroca = (Pedido) pedidoDao.listar(pedidoTroca).get(0);
			pedidoTroca.setStatusPedido(statusTrocado);
			pedidoDao.alterar(pedidoTroca);
			pedidoTroca = (Pedido) pedidoDao.listar(pedidoTroca).get(0);
			
			Double valorTotalTroca = 0.0;
			ItemEstoqueDAO itemEstoqueDao = new ItemEstoqueDAO();
			for(ItemPedido itemTroca : pedidoTroca.getItems()) {
				ItemEstoque itemEstoque = new ItemEstoque();
				Livro livroTroca = new Livro();
				livroTroca.setId(itemTroca.getLivro().getId());
				itemEstoque.setLivro(livroTroca);
				itemEstoque = (ItemEstoque) itemEstoqueDao.listar(itemEstoque).get(0);
				itemEstoque.setQuantidade(itemTroca.getQuantidade());
				itemEstoqueDao.alterar(itemEstoque);
				valorTotalTroca += itemTroca.getQuantidade() * LivroUtils.calcularPrecoLivro(itemTroca.getLivro());
			}
			
			CupomTroca cupomTroca = new CupomTroca();
			cupomTroca.setValorDesconto(valorTotalTroca);
			cupomTroca.setCliente(pedidoTroca.getCliente());
			cupomTroca.setDtCadastro(new Date());
			cupomTroca.setFoiUtilizado(false);
			cupomTroca.setNome(LivroUtils.gerarNumeroCupom(pedidoTroca));
			CupomTrocaDAO cupomTrocaDao = new CupomTrocaDAO();
			cupomTrocaDao.salvar(cupomTroca);
			realizarTroca.setCupomGerado(cupomTroca);					
			
		
			entidade = realizarTroca;
			
			
		} catch (Exception e) {
			e.printStackTrace();
			return "Erro no processo de troca"; 
		}
		
		return null;
	}

}
