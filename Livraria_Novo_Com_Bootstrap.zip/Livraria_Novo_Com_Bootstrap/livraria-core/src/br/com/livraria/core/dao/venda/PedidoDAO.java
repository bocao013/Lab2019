package br.com.livraria.core.dao.venda;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.mysql.jdbc.Statement;

import br.com.livraria.core.dao.cliente.ClienteDAO;
import br.com.livraria.core.dao.cliente.EnderecoDAO;
import br.com.livraria.core.dao.livro.AbstractDAO;
import br.com.livraria.core.dao.livro.LivroDAO;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.cliente.Cliente;
import br.com.livraria.dominio.cliente.Endereco;
import br.com.livraria.dominio.livro.Livro;
import br.com.livraria.dominio.venda.ItemPedido;
import br.com.livraria.dominio.venda.Pagamento;
import br.com.livraria.dominio.venda.Pedido;
import br.com.livraria.dominio.venda.StatusPedido;

public class PedidoDAO extends AbstractDAO {

	@Override
	public void salvar(EntidadeDominio entidade) {
		openConnection();
		PreparedStatement pst = null;
		Pedido pedido = (Pedido) entidade;

		try {
			connection.setAutoCommit(false);
			PagamentoDAO pagamentoDao = new PagamentoDAO();
			pagamentoDao.connection = connection;
			pagamentoDao.controleTransacao = false;
			pagamentoDao.salvar(pedido.getPagamento());
			
			StringBuilder sql = new StringBuilder();
			sql.append("INSERT INTO pedido ");
			sql.append("(id_cliente, id_pagamento, id_endereco, dt_pedido, id_status_pedido)");
			sql.append(" VALUES (?, ?, ?, ?, ?)");

			pst = connection.prepareStatement(sql.toString(), Statement.RETURN_GENERATED_KEYS);
			pst.setInt(1, pedido.getCliente().getId());
			pst.setInt(2, pedido.getPagamento().getId());
			pst.setInt(3, pedido.getEndereco().getId());
			
			pedido.setDtPedido(new Date());
			Timestamp timeStamp = new Timestamp(pedido.getDtPedido().getTime());
			pst.setTimestamp(4, timeStamp);
			
			pst.setInt(5, pedido.getStatusPedido().getId());
		
			pst.executeUpdate();

			ResultSet rs = pst.getGeneratedKeys();

			int id = 0;
			if (rs.next())
				id = rs.getInt(1);
			
			pedido.setId(id);
			
			ItemPedidoDAO itemPedidoDao = new ItemPedidoDAO();
			itemPedidoDao.connection = connection;
			itemPedidoDao.controleTransacao = false;
			for(ItemPedido ip : pedido.getItems()) {
				ip.setPedido(pedido);
				itemPedidoDao.salvar(ip);
			}
			
			
			entidade = pedido;
			
		
		} catch (Exception e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {

				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				if(controleTransacao){
					connection.commit();
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	public void alterar(EntidadeDominio entidade) {
		openConnection();
		PreparedStatement pst = null;
		Pedido pedido = (Pedido) entidade;

		try {
			connection.setAutoCommit(false);
			StringBuilder sql = new StringBuilder();
			sql.append("UPDATE pedido set ");
			sql.append("id_cliente=?, id_pagamento=?, id_endereco=?, id_status_pedido=?");
			sql.append(" WHERE id_pedido=? ");

			pst = connection.prepareStatement(sql.toString(), Statement.RETURN_GENERATED_KEYS);
			pst.setInt(1, pedido.getCliente().getId());
			pst.setInt(2, pedido.getPagamento().getId());
			pst.setInt(3, pedido.getEndereco().getId());
			pst.setInt(4, pedido.getStatusPedido().getId());
			
			pst.setInt(5, pedido.getId());
			
			pst.executeUpdate();
			
		} catch (Exception e) {
			try {
				connection.rollback(); 
			} catch (SQLException e1) {

				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				if(controleTransacao){
					connection.commit();
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}	
	    public List<EntidadeDominio> listar(EntidadeDominio entidade) {
		PreparedStatement pst = null;

		Pedido pedido = (Pedido) entidade;
		if(pedido.getItems()!= null) {
			for(ItemPedido itemPedido: pedido.getItems()) {
				Livro livro = new Livro();
				livro.setId(itemPedido.getLivro().getId());
				LivroDAO livroDao = new LivroDAO();
				itemPedido.setLivro((Livro)livroDao.listar(livro).get(0));
			}
			List<EntidadeDominio> retorno = new ArrayList<EntidadeDominio>();
			retorno.add(pedido);
			return retorno;
			
		} else {
			
			String sql = "select * from pedido";
	
			if (pedido.getId() != null)
				sql = "select * from pedido where id_pedido = ?";
			
			if (pedido.getCliente() != null && pedido.getCliente().getId() != null)
				sql = "select * from pedido where id_cliente = ?";
			
			if(pedido.getStatusPedido() != null && pedido.getStatusPedido().getId() != null && pedido.getStatusPedido().getId() != 0)
				sql = "select * from pedido where id_status_pedido = ?";
			
			try {
				openConnection();
				pst = connection.prepareStatement(sql);
				if (sql.equals("select * from pedido where id_pedido = ?"))
					pst.setInt(1, pedido.getId());
				
				if (sql.equals("select * from pedido where id_cliente = ?"))
					pst.setInt(1, pedido.getCliente().getId());
				
				if(sql.equalsIgnoreCase("select * from pedido where id_status_pedido = ?"))
					pst.setInt(1, pedido.getStatusPedido().getId());
				
				ResultSet rs = pst.executeQuery();
				List<EntidadeDominio> pedidos = new ArrayList<EntidadeDominio>();
	
				while (rs.next()) {
					Pedido p = new Pedido();
					p.setId(rs.getInt("id_pedido"));
					
					Timestamp ts = rs.getTimestamp("dt_pedido");
					Date dataPedido = new Date(ts.getTime());
					p.setDtPedido(dataPedido);
					
					// ------------------------------------------
					if(pedido.getCliente() == null) {
						Integer idCliente = rs.getInt("id_cliente");
						
						ClienteDAO clienteDao = new ClienteDAO();
						clienteDao.setSubConsulta(true);
						prepararDaoSubconsulta(clienteDao, connection);
						
						Cliente cliente = new Cliente();
						
						cliente.setId(idCliente);
		
						List<EntidadeDominio> clientes = clienteDao.listar(cliente);
						
						if( ! clientes.isEmpty()){
							p.setCliente((Cliente)clientes.get(0));
						}
					}
					// ------------------------------------------
					Integer idPagamento = rs.getInt("id_pagamento");
					
					PagamentoDAO pagamentoDao = new PagamentoDAO();
					prepararDaoSubconsulta(pagamentoDao, connection);
					
					Pagamento pagamento = new Pagamento();
					
					pagamento.setId(idPagamento);
	
					List<EntidadeDominio> pagamentos = pagamentoDao.listar(pagamento);
					
					if( ! pagamentos.isEmpty()){
						p.setPagamento((Pagamento)pagamentos.get(0));
					}
					
					// ------------------------------------------
					
					Integer idEndereco = rs.getInt("id_endereco");
					
					EnderecoDAO enderecoDao = new EnderecoDAO();		
					prepararDaoSubconsulta(enderecoDao, connection);
					
					Endereco endereco = new Endereco();
					
					endereco.setId(idEndereco);
					endereco.setCliente(pedido.getCliente());
	
					List<EntidadeDominio> enderecos = enderecoDao.listar(endereco);					
					
					if( ! enderecos.isEmpty()){
						p.setEndereco((Endereco)enderecos.get(0));
					}
					
					
					
					
					// ------------------------------------------
					Integer idStatusPedido = rs.getInt("id_status_pedido");
					
					StatusPedidoDAO statusPedidoDao = new StatusPedidoDAO();
					prepararDaoSubconsulta(statusPedidoDao, connection);
					
					StatusPedido statusPedido = new StatusPedido();
					
					statusPedido.setId(idStatusPedido);
	
					List<EntidadeDominio> statusResultado = statusPedidoDao.listar(statusPedido);				
					
					if( ! statusResultado.isEmpty()){
						p.setStatusPedido((StatusPedido)statusResultado.get(0));
					}
					
					// ------------------------------------------
					

					
					ItemPedidoDAO itemPedidoDao = new ItemPedidoDAO();
					prepararDaoSubconsulta(itemPedidoDao, connection);
					
					ItemPedido itemPedido = new ItemPedido();
					itemPedido.setPedido(p);
					List<ItemPedido> itensPedido = new ArrayList<ItemPedido>();
					List<EntidadeDominio> resultado = itemPedidoDao.listar(itemPedido);
					for(EntidadeDominio edip : resultado) {
						itensPedido.add( (ItemPedido) edip);
					}
					p.setItems( itensPedido );
					
					// ------------------------------------------
					
					pedidos.add(p);
				}
				return pedidos;
	
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				try {
					pst.close();
					if(controleTransacao) {						
						connection.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			return null;	    
	   }
	}
}
