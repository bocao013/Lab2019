package br.com.livraria.core.regras.endereco;


import br.com.livraria.core.IStrategy;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.cliente.Endereco;

public class ValidarObsEndereco implements IStrategy {

	public String processar(EntidadeDominio entidade) {
		Endereco endereco = (Endereco)entidade;
		
		if(endereco.getObservacao().length() > 1000)	
		return "Campo observa��o n�o pode conter mais de 1000 caracteres!";
		
	return null;
	
	}
}
