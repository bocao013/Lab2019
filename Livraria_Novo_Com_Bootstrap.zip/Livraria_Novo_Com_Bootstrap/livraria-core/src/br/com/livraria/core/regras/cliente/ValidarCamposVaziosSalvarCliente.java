package br.com.livraria.core.regras.cliente;

import br.com.livraria.core.IStrategy;
import br.com.livraria.core.regras.cartao.ValidarDtVencimentoCartao;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.cliente.Cliente;

public class ValidarCamposVaziosSalvarCliente implements IStrategy {

	public String processar(EntidadeDominio entidade) {
		String msgRetorno = "Todos os campos s�o obrigat�rios!";
		Cliente cliente = (Cliente)entidade;
		
		if(cliente.getCodigo() == null|| cliente.getGenero() == null || cliente.getNome() == null ||
				cliente.getEmail() == null || cliente.getCpf() == null || cliente.getTelefone() == null || 
				cliente.getTelefone().getNumero() == null || cliente.getTelefone().getDdd() == null || 
				cliente.getTelefone().getTipoTelefone() == null || 
				cliente.getEnderecos() == null || cliente.getEnderecos().isEmpty() || cliente.getEnderecos().get(0).getLogradouro() == null ||
				cliente.getEnderecos().get(0).getLogradouro().getTipoLogradouro() == null || cliente.getEnderecos().get(0).getNumero() == null ||
				cliente.getEnderecos().get(0).getBairro() == null || cliente.getEnderecos().get(0).getCep() == null ||
				cliente.getEnderecos().get(0).getPais() == null || cliente.getEnderecos().get(0).getCidade() == null ||
				cliente.getEnderecos().get(0).getTipoResidencia() == null || cliente.getCartoesCredito().get(0).getNumero() == null ||
				cliente.getCartoesCredito().get(0).getNome() == null || cliente.getCartoesCredito().get(0).getCodigoSeguranca() == null ||
				cliente.getEnderecos().get(0).getLogradouro().getTipoLogradouro() == null)
				
			return msgRetorno;
		
		
		if(cliente.getCodigo().trim().isEmpty() || cliente.getGenero().trim().isEmpty()  || cliente.getNome().trim().isEmpty()  ||
				cliente.getEmail().trim().isEmpty()  || cliente.getCpf().trim().isEmpty()  ||
				cliente.getTelefone().getNumero().trim().isEmpty()  || cliente.getTelefone().getDdd().trim().isEmpty()  || 
				cliente.getEnderecos().get(0).getLogradouro().getLogradouro().trim().isEmpty() ||
				cliente.getEnderecos().get(0).getNumero().trim().isEmpty()  ||
				cliente.getEnderecos().get(0).getBairro().trim().isEmpty()  || cliente.getEnderecos().get(0).getCep().trim().isEmpty()  ||
				cliente.getCartoesCredito().get(0).getNumero().trim().isEmpty()  ||
				cliente.getCartoesCredito().get(0).getNome().trim().isEmpty()  || cliente.getCartoesCredito().get(0).getCodigoSeguranca().trim().isEmpty() )
			return msgRetorno;
	
	ValidarDtVencimentoCartao validarVencimentoCartao = new ValidarDtVencimentoCartao();
	String msgCartao = validarVencimentoCartao.processar(cliente.getCartoesCredito().get(0));
	
	if(msgCartao != null)
		return msgCartao;
	
		return null;
	}

}
