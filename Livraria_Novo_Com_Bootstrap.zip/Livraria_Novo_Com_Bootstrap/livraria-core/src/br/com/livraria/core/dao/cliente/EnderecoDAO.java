package br.com.livraria.core.dao.cliente;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Statement;

import br.com.livraria.core.dao.livro.AbstractDAO;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.cliente.Cidade;
import br.com.livraria.dominio.cliente.Cliente;
import br.com.livraria.dominio.cliente.Endereco;
import br.com.livraria.dominio.cliente.Estado;
import br.com.livraria.dominio.cliente.Logradouro;
import br.com.livraria.dominio.cliente.Pais;
import br.com.livraria.dominio.cliente.TipoResidencia;

public class EnderecoDAO extends AbstractDAO {


	/**
	 *  <3 <3 <3
	 *  <3 <3
	 *  <3
	 */
	public void salvar(EntidadeDominio entidade) {
		openConnection();
		PreparedStatement pst = null;
		Endereco endereco = (Endereco) entidade;
		
		LogradouroDAO logradouroDao = new LogradouroDAO();
		

		try {
			connection.setAutoCommit(false);
			
			logradouroDao.connection = connection;
			logradouroDao.controleTransacao = false;
			logradouroDao.salvar(endereco.getLogradouro());
			
			StringBuilder sql = new StringBuilder();
			sql.append("INSERT INTO endereco ");
			sql.append("(numero, bairro, cep, observacao, id_cidades, id_pais, id_tipo_residencia, primario, id_logradouro, identificador)");
			sql.append(" VALUES (?,?,?,?,?,?,?,?,?,?)");

			pst = connection.prepareStatement(sql.toString(), Statement.RETURN_GENERATED_KEYS);
			pst.setString(1, endereco.getNumero());
			pst.setString(2, endereco.getBairro());
			pst.setString(3, endereco.getCep());
			pst.setString(4, endereco.getObservacao());
			pst.setInt(5, endereco.getCidade().getId());
			pst.setInt(6, endereco.getPais().getId());
			pst.setInt(7, endereco.getTipoResidencia().getId());
			pst.setBoolean(8, endereco.getPrimario());
			pst.setInt(9, endereco.getLogradouro().getId());
			pst.setString(10, endereco.getIdentificador());
		
			pst.executeUpdate();

			ResultSet rs = pst.getGeneratedKeys();

			int id = 0;
			if (rs.next())
				id = rs.getInt(1);

			endereco.setId(id);
			
			String query = "insert into cliente_endereco (id_cliente, id_endereco) values (?, ?)";
			PreparedStatement pstEnderecoCliente = connection.prepareStatement(query);
			pstEnderecoCliente.setInt(1, endereco.getCliente().getId());	
			pstEnderecoCliente.setInt(2, endereco.getId());	
			pstEnderecoCliente.executeUpdate();	
			pstEnderecoCliente.close();
			
			// consultar as cidades e estados do endere�o para retornar o objeto totalmente preenchido
			Cidade cidade = new Cidade();
			CidadeDAO cidadeDao = new CidadeDAO();
			cidade.setId(endereco.getCidade().getId());
			
			endereco.setCidade((Cidade)cidadeDao.listar(cidade).get(0));
			
	
			entidade = endereco;
			
		} catch (Exception e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {

				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				if(controleTransacao) {
					connection.commit();
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	public void alterar(EntidadeDominio entidade) {
		openConnection();
		PreparedStatement pst = null;
		Endereco endereco = (Endereco) entidade;

		try {
			connection.setAutoCommit(false);
			StringBuilder sql = new StringBuilder();
			sql.append("UPDATE endereco set ");
			sql.append("numero=?, bairro=?, cep=?, observacao=?, id_cidades=?, id_pais=?, id_tipo_residencia=?, primario=?, id_logradouro=?, "
					+ "identificador=?");
			sql.append(" WHERE id_endereco=? ");

			pst = connection.prepareStatement(sql.toString(), Statement.RETURN_GENERATED_KEYS);
			pst.setString(1, endereco.getNumero());
			pst.setString(2, endereco.getBairro());
			pst.setString(3, endereco.getCep());
			pst.setString(4, endereco.getObservacao());
			pst.setInt(5, endereco.getCidade().getId());
			pst.setInt(6, endereco.getPais().getId());
			pst.setInt(7, endereco.getTipoResidencia().getId());
			pst.setBoolean(8, endereco.getPrimario());
			pst.setInt(9, endereco.getLogradouro().getId());
			pst.setString(10, endereco.getIdentificador());
			pst.setInt(11, endereco.getId());
			
			pst.executeUpdate();
			
			LogradouroDAO logradouroDao = new LogradouroDAO();
			prepararDaoSubconsulta(logradouroDao, connection);
			logradouroDao.alterar(endereco.getLogradouro());
			
			// consultar as cidades e estados do endere�o para retornar o objeto totalmente preenchido
			Cidade cidade = new Cidade();
			CidadeDAO cidadeDao = new CidadeDAO();
			prepararDaoSubconsulta(cidadeDao, connection);
			cidade.setId(endereco.getCidade().getId());
			
			endereco.setCidade((Cidade)cidadeDao.listar(cidade).get(0));
			
			entidade = endereco;
			
		} catch (Exception e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {

				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				if(controleTransacao) {
					connection.commit();
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}	
	    public List<EntidadeDominio> listar(EntidadeDominio entidade) {
		PreparedStatement pst = null;

		Endereco endereco = (Endereco) entidade;
		String sql = "select * from endereco";

		if (endereco.getId() != null)
			sql = "select * from endereco where id_endereco = ?";
		
		try {
			openConnection();
			pst = connection.prepareStatement(sql);
			if (sql.equals("select * from endereco where id_endereco = ?"))
				pst.setInt(1, endereco.getId());
			
			ResultSet rs = pst.executeQuery();
			List<EntidadeDominio> enderecos = new ArrayList<EntidadeDominio>();

			while (rs.next()) {
				Endereco e = new Endereco();
				e.setId(rs.getInt("id_endereco"));
				e.setNumero(rs.getString("numero"));
				e.setBairro(rs.getString("bairro"));
				e.setCep(rs.getString("cep"));
				e.setObservacao(rs.getString("observacao"));
				e.setPrimario(rs.getBoolean("primario"));
				e.setIdentificador(rs.getString("identificador"));
				
				// -----------------------------------------------------------------

				Integer idCidade = rs.getInt("id_cidades");
				
				CidadeDAO cidadeDao = new CidadeDAO();
				prepararDaoSubconsulta(cidadeDao, connection);
				Cidade cidade = new Cidade();
				
				
				cidade.setId(idCidade);

				List<EntidadeDominio> cidades = cidadeDao.listar(cidade);			
				
				if( ! cidades.isEmpty()){
					e.setCidade((Cidade)cidades.get(0));
				}
				
				// ------------------------------------------------------------------

				Integer idPais = rs.getInt("id_pais");
				
				PaisDAO paisDao = new PaisDAO();
				prepararDaoSubconsulta(paisDao, connection);
				Pais pais = new Pais();
				
				
				pais.setId(idPais);

				List<EntidadeDominio> paises = paisDao.listar(pais);		
				
				if( ! paises.isEmpty()){
					e.setPais((Pais)paises.get(0));
				}
				
				// ------------------------------------------------------------------
				
				Integer idTipoResidencia = rs.getInt("id_tipo_residencia");
				
				TipoResidenciaDAO tipoResidenciaDao = new TipoResidenciaDAO();
				prepararDaoSubconsulta(tipoResidenciaDao, connection);
				TipoResidencia tipoResidencia = new TipoResidencia();
				
				
				tipoResidencia.setId(idTipoResidencia);

				List<EntidadeDominio> tipoResidencias = tipoResidenciaDao.listar(tipoResidencia);
				
				if( ! tipoResidencias.isEmpty()){
					e.setTipoResidencia((TipoResidencia)tipoResidencias.get(0));
				}
				
				// ------------------------------------------------------------------
				
				Integer idLogradouro = rs.getInt("id_logradouro");
				
				LogradouroDAO logradouroDao = new LogradouroDAO();
				prepararDaoSubconsulta(logradouroDao, connection);
				Logradouro logradouro = new Logradouro();
				
				
				logradouro.setId(idLogradouro);

				List<EntidadeDominio> logradouros = logradouroDao.listar(logradouro);
				
				if( ! logradouros.isEmpty()){
					e.setLogradouro((Logradouro)logradouros.get(0));
				}
				
				// ------------------------------------------------------------------
				
				
				sql = "select id_cliente from cliente_endereco where id_endereco = ?";
				PreparedStatement pstCliente = connection.prepareStatement(sql);
				pstCliente.setInt(1, e.getId());	
				ResultSet resultado = pstCliente.executeQuery();
				resultado.next();
				
				Integer idCliente = resultado.getInt("id_cliente");
				
				ClienteDAO clienteDao = new ClienteDAO();
				prepararDaoSubconsulta(clienteDao, connection);
				clienteDao.setSubConsulta(true);
				Cliente cliente = new Cliente();
				cliente.setId(idCliente);
				cliente = (Cliente)clienteDao.listar(cliente).get(0);
					
				e.setCliente(cliente);
				
				
				enderecos.add(e);
			}
			return enderecos;

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				if(controleTransacao) {
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return null;	    
	    }	    
}

