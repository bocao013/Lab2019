package br.com.livraria.core.dao.venda;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.mysql.jdbc.Statement;

import br.com.livraria.core.dao.livro.AbstractDAO;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.venda.Cupom;
import br.com.livraria.dominio.venda.CupomTroca;
import br.com.livraria.dominio.venda.Pagamento;
import br.com.livraria.dominio.venda.PagamentoCartaoCredito;

public class PagamentoDAO extends AbstractDAO {

	/**
	 *  <3 <3 <3
	 *  <3 <3
	 *  <3
	 */
	public void salvar(EntidadeDominio entidade) {
		openConnection();
		PreparedStatement pst = null;
		Pagamento pagamento = (Pagamento) entidade;
		
		try {
			connection.setAutoCommit(false);
			
			StringBuilder sb = new StringBuilder();
			sb.append("INSERT INTO pagamento ");
			if(pagamento.getCupom() != null) {
				sb.append("(id_cupom, dt_pagamento, valor_total)");
				sb.append(" VALUES (?,?,?)");
			} else {
				sb.append("(dt_pagamento, valor_total)");
				sb.append(" VALUES (?,?)");
			}

			pst = connection.prepareStatement(sb.toString(), Statement.RETURN_GENERATED_KEYS);
			int countPreparedStatement = 1;
			
			if(pagamento.getCupom() != null && pagamento.getCupom().getId() != null) {
				pst.setInt(countPreparedStatement++, pagamento.getCupom().getId());
			}
			pagamento.setDtPagamento(new Date());
			Timestamp timeStamp = new Timestamp(pagamento.getDtPagamento().getTime());
			pst.setTimestamp(countPreparedStatement++, timeStamp);
			
			pst.setDouble(countPreparedStatement, pagamento.getValorTotal());
			pst.executeUpdate();

			ResultSet rs = pst.getGeneratedKeys();

			int id = 0;
			if (rs.next())
				id = rs.getInt(1);

			pagamento.setId(id);
			
			for(PagamentoCartaoCredito pcc : pagamento.getPagamentosCartao()) {
				String sql = "insert into pagamento_cartao_credito (id_pagamento, id_cartao_credito, valor_pagamento) values (?, ?, ?)";
				PreparedStatement pstPagamentoCartao = connection.prepareStatement(sql);
				pstPagamentoCartao.setInt(1, pagamento.getId());	
				pstPagamentoCartao.setInt(2, pcc.getCartaoCredito().getId());	
				pstPagamentoCartao.setDouble(3, pcc.getValor());
				pstPagamentoCartao.executeUpdate();	
				pstPagamentoCartao.close();
				
				
				CupomTrocaDAO cupomTrocaDao = new CupomTrocaDAO();
				cupomTrocaDao.connection = connection;
				cupomTrocaDao.controleTransacao = false;
				for(CupomTroca cupomTroca : pagamento.getCuponsTroca()) {
					cupomTroca.setFoiUtilizado(true);
					cupomTrocaDao.alterar(cupomTroca);
				}
			}	
			entidade = pagamento;
		} catch (Exception e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {

				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				if(controleTransacao){
					connection.commit();
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	public void alterar(EntidadeDominio entidade) {
/*		openConnection();
		PreparedStatement pst = null;
		Pagamento pagamento = (Pagamento) entidade;

		try {
			connection.setAutoCommit(false);
				
			StringBuilder sb = new StringBuilder();
			sb.append("UPDATE pagamento set ");
			sb.append("id_cupom=?, dt_pagamento=?, valor_total=?");
			sb.append(" WHERE id_pagamento=? ");
			
			Timestamp ts = new Timestamp(pagamento.getDtPagamento().getTime());

			pst = connection.prepareStatement(sb.toString(), Statement.RETURN_GENERATED_KEYS);
			
			pst.setInt(1, pagamento.getCupom().getId());
			pst.setTimestamp(2, ts);
			pst.setDouble(3, pagamento.getValorTotal());
			pst.setInt(1, pagamento.getId());
		
			pst.executeUpdate();

			connection.commit();
			
		} catch (Exception e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {

				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				connection.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}*/

	} 
	
		public List<EntidadeDominio> listar(EntidadeDominio entidade) {
		PreparedStatement pst = null;
		String sql = "select * from pagamento";
		Pagamento pagamento = (Pagamento) entidade;
		if(pagamento.getId() != null)
			sql = "select * from pagamento where id_pagamento = ?";
	
		try {
			openConnection();
			pst = connection.prepareStatement(sql);
			if(sql.equals("select * from pagamento where id_pagamento = ?"))
					pst.setInt(1, pagamento.getId());
				
			ResultSet rs = pst.executeQuery();
			List<EntidadeDominio> pagamentos = new ArrayList<EntidadeDominio>();

			while (rs.next()) {
				Pagamento p = new Pagamento();
				
				p.setId(rs.getInt("id_pagamento"));
				Timestamp ts = rs.getTimestamp("dt_pagamento");
				Date dataPagamento = new Date(ts.getTime());
				p.setDtPagamento(dataPagamento);
				p.setValorTotal(rs.getDouble("valor_total"));
	
				// ---------------------------------------------
				
				Integer idCupom = rs.getInt("id_cupom");
				
				CupomDAO cupomDao = new CupomDAO();
				prepararDaoSubconsulta(cupomDao, connection);
				Cupom cupom = new Cupom();
				
				cupom.setId(idCupom);

				List<EntidadeDominio> cupons = cupomDao.listar(cupom);
				
				if( ! cupons.isEmpty()){
					p.setCupom((Cupom)cupons.get(0));
				}
	
				pagamentos.add(p);
	
			}
			return pagamentos;

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				if(controleTransacao) {
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return null;
	}
}
