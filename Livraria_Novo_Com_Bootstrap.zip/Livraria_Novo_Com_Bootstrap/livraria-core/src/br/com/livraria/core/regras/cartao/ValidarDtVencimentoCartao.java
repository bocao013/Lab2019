package br.com.livraria.core.regras.cartao;

import java.util.Date;

import br.com.livraria.core.IStrategy;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.cliente.CartaoCredito;

public class ValidarDtVencimentoCartao implements IStrategy {

	public String processar(EntidadeDominio entidade) {
		CartaoCredito cartaoCredito = (CartaoCredito) entidade;
		Date dataAtual = new Date();
		
		if(cartaoCredito.getDtVencimento() == null)
			return "Data de vencimento � de preenchimento obrigat�rio";
	
		if(cartaoCredito.getDtVencimento().before(dataAtual))
			return "Vencimento inv�lido";
		
		return null;
	}
}
