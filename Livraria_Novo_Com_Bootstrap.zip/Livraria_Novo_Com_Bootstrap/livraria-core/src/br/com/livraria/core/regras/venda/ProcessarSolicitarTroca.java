package br.com.livraria.core.regras.venda;

import java.util.ArrayList;
import java.util.List;

import br.com.livraria.core.IStrategy;
import br.com.livraria.core.dao.venda.ItemPedidoDAO;
import br.com.livraria.core.dao.venda.PedidoDAO;
import br.com.livraria.core.util.LivroUtils;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.venda.ItemPedido;
import br.com.livraria.dominio.venda.Pagamento;
import br.com.livraria.dominio.venda.Pedido;
import br.com.livraria.dominio.venda.SolicitarTroca;
import br.com.livraria.dominio.venda.StatusPedido;

public class ProcessarSolicitarTroca implements IStrategy {

	@Override
	public String processar(EntidadeDominio entidade) {
		SolicitarTroca solicitarTroca = (SolicitarTroca) entidade;
		Pedido pedidoTroca = solicitarTroca.getPedidoTroca();
		
		if(pedidoTroca.getItems().size() == 0) {
			return "Selecione pelo menos 1 item para trocar!";
		}
		PedidoDAO pedidoDao = new PedidoDAO();
		Pedido pedidoConsulta = new Pedido();
		
		pedidoConsulta.setId(pedidoTroca.getId());
		pedidoConsulta = (Pedido) pedidoDao.listar(pedidoConsulta).get(0);
		
		Boolean trocaPedidoInteiro = pedidoTroca.getItems().size() == pedidoConsulta.getItems().size();
		StatusPedido statusEmTroca = new StatusPedido();
		statusEmTroca.setId(StatusPedido.EM_TROCA);
		
		Pedido pedidoAlterado = null;
		if(trocaPedidoInteiro) {
			pedidoConsulta.setStatusPedido(statusEmTroca);
			pedidoDao.alterar(pedidoConsulta);
			pedidoAlterado = pedidoConsulta;
			
		} else {
			List<ItemPedido> itensTroca = pedidoTroca.getItems();
			ItemPedidoDAO itemPedidoDao = new ItemPedidoDAO();			
			
			Double valorTotal = 0.0;
			for(ItemPedido itemTroca : itensTroca) {
				itemTroca = (ItemPedido) itemPedidoDao.listar(itemTroca).get(0);
				valorTotal += itemTroca.getQuantidade() * LivroUtils.calcularPrecoLivro(itemTroca.getLivro());
			}
			Pagamento pagamentoTroca = new Pagamento();
			pagamentoTroca.setValorTotal(valorTotal);					
			
			pedidoTroca = pedidoConsulta;
			pedidoTroca.setId(null);
			pedidoTroca.setItems(new ArrayList<ItemPedido>());
			pedidoConsulta.setStatusPedido(statusEmTroca);
			pedidoTroca.setPagamento(pagamentoTroca);
			pedidoDao.salvar(pedidoTroca);
			
			
			for(ItemPedido itemTroca : itensTroca) {
				itemTroca = (ItemPedido) itemPedidoDao.listar(itemTroca).get(0);
				itemTroca.setPedido(pedidoTroca);
				itemPedidoDao.alterar(itemTroca);				
			}
			pedidoAlterado = pedidoTroca;
		}
		solicitarTroca.setPedidoTroca(pedidoAlterado);
		entidade = solicitarTroca;
		return null;
	}

}
