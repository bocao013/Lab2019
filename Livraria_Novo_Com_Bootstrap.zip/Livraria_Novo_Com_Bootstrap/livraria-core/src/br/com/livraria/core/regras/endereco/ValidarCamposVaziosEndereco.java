package br.com.livraria.core.regras.endereco;

import br.com.livraria.core.IStrategy;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.cliente.Endereco;

public class ValidarCamposVaziosEndereco implements IStrategy {

	@Override
	public String processar(EntidadeDominio entidade) {
		String msgRetorno = "Todos os campos s�o obrigat�rios!";
		Endereco endereco = (Endereco)entidade;
		
		if(endereco.getLogradouro() == null || endereco.getLogradouro().getTipoLogradouro() == null ||
				endereco.getLogradouro().getTipoLogradouro().getId() == null ||
				endereco.getLogradouro().getLogradouro()== null || endereco.getNumero() == null ||
				endereco.getBairro() == null || endereco.getCep() == null || endereco.getPais() == null || 
				endereco.getPais().getId() == null || endereco.getTipoResidencia().getId() == null ||
				endereco.getCidade() == null  || endereco.getCidade().getId() == null|| endereco.getTipoResidencia() == null)
				
			return msgRetorno;
		
		
		if(endereco.getLogradouro().getLogradouro().trim().isEmpty() || endereco.getNumero().trim().isEmpty()  ||
				endereco.getBairro().trim().isEmpty()  || endereco.getCep().trim().isEmpty())
			return msgRetorno;
	
		return null;
	}

}
