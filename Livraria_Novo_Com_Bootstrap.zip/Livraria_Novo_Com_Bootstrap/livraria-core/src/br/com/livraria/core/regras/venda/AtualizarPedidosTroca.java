package br.com.livraria.core.regras.venda;

import java.util.ArrayList;
import java.util.List;

import br.com.livraria.core.IStrategy;
import br.com.livraria.core.dao.venda.PedidoDAO;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.cliente.Cliente;
import br.com.livraria.dominio.venda.Pedido;
import br.com.livraria.dominio.venda.SolicitarTroca;

public class AtualizarPedidosTroca implements IStrategy {

	@Override
	public String processar(EntidadeDominio entidade) {
		SolicitarTroca solicitarTroca = (SolicitarTroca) entidade;
		Cliente clienteLogado = solicitarTroca.getClienteLogado();
		Pedido pedidosConsulta = new Pedido();
		pedidosConsulta.setCliente(clienteLogado);
		PedidoDAO pedidoDao = new PedidoDAO();
		List<EntidadeDominio> resultadoConsulta = pedidoDao.listar(pedidosConsulta);
		List<Pedido> pedidosCliente = new ArrayList<Pedido>();
		for(EntidadeDominio ed : resultadoConsulta) {
			Pedido pedidoCliente = (Pedido) ed;
			pedidosCliente.add(pedidoCliente);
		}
		clienteLogado.setPedidos(pedidosCliente);
		solicitarTroca.setClienteLogado(clienteLogado);
		entidade = solicitarTroca;
		return null;
	}

}
