package br.com.livraria.core.regras.cliente;

import br.com.livraria.core.IStrategy;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.cliente.Cliente;

public class ValidarDtNascimentoCliente implements IStrategy {

	public String processar(EntidadeDominio entidade) {
		Cliente cliente = (Cliente) entidade;
		
		if(cliente.getDtNascimento() == null)
			return "Data de nascimento � de preenchimento obrigat�rio!";
		
		
		return null;
	}
}
