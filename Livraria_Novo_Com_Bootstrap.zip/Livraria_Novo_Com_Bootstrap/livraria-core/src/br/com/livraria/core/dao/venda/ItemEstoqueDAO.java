package br.com.livraria.core.dao.venda;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Statement;

import br.com.livraria.core.dao.livro.AbstractDAO;
import br.com.livraria.core.dao.livro.LivroDAO;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.livro.Livro;
import br.com.livraria.dominio.venda.ItemEstoque;


public class ItemEstoqueDAO extends AbstractDAO {

	/**
	 * <3 <3 <3 <3 <3 <3
	 */
	public void salvar(EntidadeDominio entidade) {
		openConnection();
		PreparedStatement pst = null;
		ItemEstoque itemEstoque = (ItemEstoque) entidade;

		try {
			connection.setAutoCommit(false);

			StringBuilder sb = new StringBuilder();
			sb.append("INSERT INTO estoque ");
			sb.append("(quantidade, id_livro)");
			sb.append(" VALUES (?,?)");

			pst = connection.prepareStatement(sb.toString(), Statement.RETURN_GENERATED_KEYS);
			pst.setInt(1, itemEstoque.getQuantidade());
			pst.setInt(2, itemEstoque.getLivro().getId());
			pst.executeUpdate();

			ResultSet rs = pst.getGeneratedKeys();

			int id = 0;
			if (rs.next())
				id = rs.getInt(1);

			itemEstoque.setId(id);

		} catch (Exception e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {

				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				if (controleTransacao) {
					connection.commit();
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	public void alterar(EntidadeDominio entidade) {
		openConnection();
		PreparedStatement pst = null;
		ItemEstoque itemEstoque = (ItemEstoque) entidade;

		try {
			connection.setAutoCommit(false);
			
			String select = "select quantidade from estoque where id_livro = ?";
			pst = connection.prepareStatement(select);
			pst.setInt(1, itemEstoque.getLivro().getId());
			ResultSet resultado = pst.executeQuery();
			int quantidadeAtual = 0;
			while(resultado.next()) {
				quantidadeAtual = resultado.getInt("quantidade");
			}
			pst.close();
			
			StringBuilder sb = new StringBuilder();
			sb.append("UPDATE estoque set ");
			sb.append("quantidade=?");
			sb.append(" WHERE id_livro=? ");

			pst = connection.prepareStatement(sb.toString(), Statement.RETURN_GENERATED_KEYS);
			pst.setInt(1, (quantidadeAtual + itemEstoque.getQuantidade()));
			pst.setInt(2, itemEstoque.getLivro().getId());

			pst.executeUpdate();

			ResultSet rs = pst.getGeneratedKeys();

			int id = 0;
			if (rs.next())
				id = rs.getInt(1);

			itemEstoque.setId(id);
		} catch (Exception e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {

				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				if (controleTransacao) {
					connection.commit();
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	public List<EntidadeDominio> listar(EntidadeDominio entidade) {
		PreparedStatement pst = null;
		String sql = "";
		ItemEstoque itemEstoque = (ItemEstoque) entidade;
		List<EntidadeDominio> itensEstoque = new ArrayList<EntidadeDominio>();
		sql = "select * from estoque";

		// busca de todos os livros para barra filtro de pesquisa
		if (itemEstoque.getLivro() != null && itemEstoque.getLivro().getCodigo() != null) {
			LivroDAO livroDao = new LivroDAO();
			List<EntidadeDominio> resultadoLivros = livroDao.listar(itemEstoque.getLivro());
			sql = "select * from estoque where";
			int contadorLivros = 1;
			List<Integer> idsLivros = new ArrayList<Integer>();
			
			for(EntidadeDominio ed : resultadoLivros) {
				sql += " id_livro=?";
				idsLivros.add(ed.getId());
				
				if(contadorLivros != resultadoLivros.size()) {
					contadorLivros++;
					sql += " or";
				}
			}
	
			try {
				openConnection();
				pst = connection.prepareStatement(sql);
				
				contadorLivros = 1;
				for(Integer idLivro : idsLivros) {
					pst.setInt(contadorLivros++, idLivro);
				}
				
				ResultSet rs = pst.executeQuery();
				
				while (rs.next()) {
					ItemEstoque i = new ItemEstoque();

					i.setId(rs.getInt("id_estoque"));
					i.setQuantidade(rs.getInt("quantidade"));

					Integer idLivro = rs.getInt("id_livro");

					Livro livro = new Livro();

					livro.setId(idLivro);

					List<EntidadeDominio> livros = livroDao.listar(livro);

					if (!livros.isEmpty()) {
						i.setLivro((Livro) livros.get(0));
					}

					itensEstoque.add(i);
				}

				return itensEstoque;
				
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				try {
					pst.close();
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			
		} else {
			if (itemEstoque.getId() != null)
				sql = "select * from estoque where id_estoque = ?";
	
			if (itemEstoque.getLivro() != null && itemEstoque.getLivro().getId() != null) 
				sql = "select * from estoque where id_livro = ?";			
			
				try {
					openConnection();
					pst = connection.prepareStatement(sql);
	
					if (sql.equals("select * from estoque where id_estoque = ?"))
						pst.setInt(1, itemEstoque.getId());
	
					if (sql.equals("select * from estoque where id_livro = ?"))
						pst.setInt(1, itemEstoque.getLivro().getId());
	
					ResultSet rs = pst.executeQuery();
	
					while (rs.next()) {
						ItemEstoque i = new ItemEstoque();
	
						i.setId(rs.getInt("id_estoque"));
						i.setQuantidade(rs.getInt("quantidade"));
	
						Integer idLivro = rs.getInt("id_livro");
	
						LivroDAO livroDao = new LivroDAO();
						Livro livro = new Livro();
	
						livro.setId(idLivro);
	
						List<EntidadeDominio> livros = livroDao.listar(livro);
	
						if (!livros.isEmpty()) {
							i.setLivro((Livro) livros.get(0));
						}
	
						itensEstoque.add(i);
					}
	
					return itensEstoque;
	
				} catch (SQLException e) {
					e.printStackTrace();
				} finally {
					try {
						pst.close();
						connection.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
		}
		return null;
	}
}
