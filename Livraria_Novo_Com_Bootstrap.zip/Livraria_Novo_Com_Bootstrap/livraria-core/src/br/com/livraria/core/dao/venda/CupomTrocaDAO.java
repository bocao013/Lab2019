package br.com.livraria.core.dao.venda;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Statement;

import br.com.livraria.core.dao.livro.AbstractDAO;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.venda.Cupom;
import br.com.livraria.dominio.venda.CupomTroca;

public class CupomTrocaDAO extends AbstractDAO {

	@Override
	public void salvar(EntidadeDominio entidade) {
		openConnection();
		PreparedStatement pst = null;
		CupomTroca cupomTroca = (CupomTroca) entidade;

		try {
			connection.setAutoCommit(false);
			StringBuilder sql = new StringBuilder();
			sql.append("INSERT INTO cupom_troca ");
			sql.append("(id_cliente, nome, valor_desconto, foi_utilizado)");
			sql.append(" VALUES (?, ?, ?, ?)");

			pst = connection.prepareStatement(sql.toString(), Statement.RETURN_GENERATED_KEYS);
			pst.setInt(1, cupomTroca.getCliente().getId());
			pst.setString(2, cupomTroca.getNome());
			pst.setDouble(3, cupomTroca.getValorDesconto());
			pst.setBoolean(4, cupomTroca.getFoiUtilizado());
		
			pst.executeUpdate();

			ResultSet rs = pst.getGeneratedKeys();

			int id = 0;
			if (rs.next())
				id = rs.getInt(1);

			entidade.setId(id);
		
		} catch (Exception e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {

				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				if(controleTransacao){
					connection.commit();
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}
	@Override
	public void alterar(EntidadeDominio entidade) {
		openConnection();
		PreparedStatement pst = null;
		CupomTroca cupomTroca = (CupomTroca) entidade;

		try {
			connection.setAutoCommit(false);
			StringBuilder sql = new StringBuilder();
			sql.append("UPDATE cupom_troca set ");
			sql.append("foi_utilizado=? ");
			sql.append(" WHERE id_cupom_troca=?");

			pst = connection.prepareStatement(sql.toString(), Statement.RETURN_GENERATED_KEYS);			
			pst.setBoolean(1, cupomTroca.getFoiUtilizado());
			pst.setInt(2, cupomTroca.getId());
			pst.executeUpdate();
			
		} catch (Exception e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {

				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				if(controleTransacao){
					connection.commit();
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	@Override
	public List<EntidadeDominio> listar(EntidadeDominio entidade) {
		PreparedStatement pst = null;

		CupomTroca cupomTroca = (CupomTroca) entidade;
		String sql = "select * from cupom_troca";

		if (cupomTroca.getId() != null)
			sql = "select * from cupom_troca where id_cupom_troca = ?";
		
		if (cupomTroca.getNome() != null)
			sql = "select * from cupom_troca where nome = ?";
		
		if (cupomTroca.getCliente() != null && cupomTroca.getCliente().getId() != null)
			sql = "select * from cupom_troca where id_cliente = ? and foi_utilizado = 0";
		
		try {
			openConnection();
			pst = connection.prepareStatement(sql);
			if (sql.equals("select * from cupom_troca where id_cupom_troca = ?"))
				pst.setInt(1, cupomTroca.getId());
			
			if (sql.equals("select * from cupom_troca where nome = ?"))
				pst.setString(1, cupomTroca.getNome());
			
			if (sql.equals("select * from cupom_troca where id_cliente = ? and foi_utilizado = 0"))
				pst.setInt(1, cupomTroca.getCliente().getId());
			
			ResultSet rs = pst.executeQuery();
			List<EntidadeDominio> cuponsTroca = new ArrayList<EntidadeDominio>();

			while (rs.next()) {
				CupomTroca c = new CupomTroca();
				c.setId(rs.getInt("id_cupom_troca"));
				c.setNome(rs.getString("nome"));
				c.setValorDesconto(rs.getDouble("valor_desconto"));
				c.setFoiUtilizado(rs.getBoolean("foi_utilizado"));
				cuponsTroca.add(c);
			}
			return cuponsTroca;

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pst.close();
				if(controleTransacao) {
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return null;	    
	  }
}
