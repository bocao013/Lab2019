package br.com.livraria.core.regras.venda;

import br.com.livraria.core.IStrategy;
import br.com.livraria.core.dao.venda.ItemEstoqueDAO;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.livro.Livro;
import br.com.livraria.dominio.venda.ItemEstoque;
import br.com.livraria.dominio.venda.ItemPedido;

public class ValidarQtdeEstoque implements IStrategy {

	@Override
	public String processar(EntidadeDominio entidade) {
		ItemPedido itemPedido = (ItemPedido) entidade;
		ItemEstoqueDAO itemEstoqueDao = new ItemEstoqueDAO();
		ItemEstoque itemEstoque = new ItemEstoque();
		
		Livro livroAddQtde = new Livro();
		livroAddQtde.setId(itemPedido.getLivro().getId());
		
		itemEstoque.setLivro(livroAddQtde); // saber a quantidade
		itemEstoque = (ItemEstoque) itemEstoqueDao.listar(itemEstoque).get(0); // receber o id do livro que est� no item pedido
		if(itemEstoque.getQuantidade() - (itemPedido.getQuantidade() + 1) < 0) {
			return String.format("S� existem %d deste item %s em estoque", itemEstoque.getQuantidade(), itemEstoque.getLivro().getTitulo());
		}

		return null;
	}

}
