package br.com.livraria.dominio.cliente;

import br.com.livraria.dominio.EntidadeDominio;

public class Telefone extends EntidadeDominio {
	private String ddd;
	private String numero;
	private TipoTelefone tipoTelefone;
	
	public String getDdd() {
		return ddd;
	}
	public void setDdd(String ddd) {
		this.ddd = ddd;
	}
	public String getNumero() {
		return numero;
	}
	public void setNumero(String numero) {
		this.numero = numero;
	}
	public TipoTelefone getTipoTelefone() {
		return tipoTelefone;
	}
	public void setTipoTelefone(TipoTelefone tipoTelefone) {
		this.tipoTelefone = tipoTelefone;
	}

}
