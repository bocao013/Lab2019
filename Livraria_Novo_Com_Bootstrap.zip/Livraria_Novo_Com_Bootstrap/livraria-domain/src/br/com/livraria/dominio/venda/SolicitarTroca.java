package br.com.livraria.dominio.venda;

import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.Usuario;
import br.com.livraria.dominio.cliente.Cliente;

public class SolicitarTroca extends EntidadeDominio {
	private Pedido pedidoTroca;
	private Cliente clienteLogado;

	public Pedido getPedidoTroca() {
		return pedidoTroca;
	}

	public void setPedidoTroca(Pedido pedidoTroca) {
		this.pedidoTroca = pedidoTroca;
	}

	public Cliente getClienteLogado() {
		return clienteLogado;
	}

	public void setClienteLogado(Cliente clienteLogado) {
		this.clienteLogado = clienteLogado;
	}

	

	
	
}
