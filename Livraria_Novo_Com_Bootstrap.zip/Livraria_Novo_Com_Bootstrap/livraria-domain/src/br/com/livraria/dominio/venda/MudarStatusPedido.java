package br.com.livraria.dominio.venda;

import br.com.livraria.dominio.EntidadeDominio;

public class MudarStatusPedido extends EntidadeDominio {
	private Pedido pedido;
	
	public Pedido getPedido() {
		return pedido;
	}
	public void setPedido(Pedido pedido) {
		this.pedido = pedido;
	}

}
