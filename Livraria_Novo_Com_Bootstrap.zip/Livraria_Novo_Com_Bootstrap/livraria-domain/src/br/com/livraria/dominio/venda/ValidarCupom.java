package br.com.livraria.dominio.venda;

import br.com.livraria.dominio.EntidadeDominio;

public class ValidarCupom extends EntidadeDominio {
	private Pedido carrinho;
	private Cupom cupom;
	private CupomTroca cupomTroca;

	public Pedido getCarrinho() {
		return carrinho;
	}

	public void setCarrinho(Pedido carrinho) {
		this.carrinho = carrinho;
	}

	public Cupom getCupom() {
		return cupom;
	}

	public void setCupom(Cupom cupom) {
		this.cupom = cupom;
	}

	public CupomTroca getCupomTroca() {
		return cupomTroca;
	}

	public void setCupomTroca(CupomTroca cupomTroca) {
		this.cupomTroca = cupomTroca;
	}
	
	
}
