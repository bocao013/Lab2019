package br.com.livraria.dominio.venda;

public class ItemEstoque extends Item {

}
