package br.com.livraria.dominio.cliente;

import br.com.livraria.dominio.EntidadeDominio;

public class Endereco extends EntidadeDominio {
	private String numero;
	private String bairro;
	private String cep;
	private Cidade cidade;
	private Pais pais;
	private String observacao;
	private String identificador;
	private TipoResidencia tipoResidencia;
	private Logradouro logradouro;
	private Boolean primario;
	private Cliente cliente;

	public Cliente getCliente() {
		return cliente;
	}
	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}
	public String getIdentificador() {
		return identificador;
	}
	public void setIdentificador(String identificador) {
		this.identificador = identificador;
	}
	public Logradouro getLogradouro() {
		return logradouro;
	}
	public void setLogradouro(Logradouro logradouro) {
		this.logradouro = logradouro;
	}
	public Boolean getPrimario() {
		return primario;
	}
	public void setPrimario(Boolean primario) {
		this.primario = primario;
	}
	public TipoResidencia getTipoResidencia() {
		return tipoResidencia;
	}
	public void setTipoResidencia(TipoResidencia tipoResidencia) {
		this.tipoResidencia = tipoResidencia;
	}
	public String getNumero() {
		return numero;
	}
	public void setNumero(String numero) {
		this.numero = numero;
	}
	public String getBairro() {
		return bairro;
	}
	public void setBairro(String bairro) {
		this.bairro = bairro;
	}
	public String getCep() {
		return cep;
	}
	public void setCep(String cep) {
		this.cep = cep;
	}
	public Cidade getCidade() {
		return cidade;
	}
	public void setCidade(Cidade cidade) {
		this.cidade = cidade;
	}
	
	public Pais getPais() {
		return pais;
	}
	public void setPais(Pais pais) {
		this.pais = pais;
	}
	public String getObservacao() {
		return observacao;
	}
	public void setObservacao(String observacao) {
		this.observacao = observacao;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append(getLogradouro().getTipoLogradouro().getTipoLogradouro()).append(" ").append(getLogradouro().getLogradouro()).append(" ");
		builder.append(getNumero()).append(" ").append(getBairro()).append(" ").append(getCep()).append(" ").append(getCidade().getNome()).append(" ");
		builder.append(getCidade().getEstado().getNome()).append(" ").append(getPais().getNome()).append(" ").append(getTipoResidencia().getTipoResidencia());
		return builder.toString();
	}
}
	
	