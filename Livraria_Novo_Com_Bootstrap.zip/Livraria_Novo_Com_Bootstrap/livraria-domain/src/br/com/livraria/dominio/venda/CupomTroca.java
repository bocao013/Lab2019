package br.com.livraria.dominio.venda;

import br.com.livraria.dominio.cliente.Cliente;

public class CupomTroca extends Cupom {
	private Cliente cliente;
	private Boolean foiUtilizado;

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public Boolean getFoiUtilizado() {
		return foiUtilizado;
	}

	public void setFoiUtilizado(Boolean foiUtilizado) {
		this.foiUtilizado = foiUtilizado;
	}
	

}
