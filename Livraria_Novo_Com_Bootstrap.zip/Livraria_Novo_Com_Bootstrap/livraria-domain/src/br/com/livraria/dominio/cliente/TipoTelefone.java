package br.com.livraria.dominio.cliente;

import br.com.livraria.dominio.EntidadeDominio;

public class TipoTelefone extends EntidadeDominio {
	private String tipoTelefone;

	public String getTipoTelefone() {
		return tipoTelefone;
	}

	public void setTipoTelefone(String tipoTelefone) {
		this.tipoTelefone = tipoTelefone;
	}

}
