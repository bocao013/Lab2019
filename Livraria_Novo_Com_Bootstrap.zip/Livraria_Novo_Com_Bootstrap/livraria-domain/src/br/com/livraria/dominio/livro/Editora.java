package br.com.livraria.dominio.livro;

import br.com.livraria.dominio.EntidadeDominio;

public class Editora extends EntidadeDominio {
	private String nome;

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

}
