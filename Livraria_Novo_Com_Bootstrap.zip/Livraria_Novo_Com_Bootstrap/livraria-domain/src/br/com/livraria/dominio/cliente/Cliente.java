package br.com.livraria.dominio.cliente;

import java.util.ArrayList;
import java.util.List;

import br.com.livraria.dominio.Usuario;
import br.com.livraria.dominio.venda.CupomTroca;
import br.com.livraria.dominio.venda.Pedido;

public class Cliente extends Usuario {
	private String codigo;
	private Integer ranking;
	private Boolean ativo;
	private Telefone telefone;
	private List<Endereco> enderecos;
	private List<CartaoCredito> cartoesCredito;
	private List<CupomTroca> cuponsTroca;
	private List<Pedido> pedidos;
	
	public Cliente () {
		enderecos = new ArrayList<Endereco>();
		cartoesCredito = new ArrayList<CartaoCredito>();
		cuponsTroca = new ArrayList<CupomTroca>();
		pedidos = new ArrayList<Pedido>();
	}
	
	public Telefone getTelefone() {
		return telefone;
	}
	public void setTelefone(Telefone telefone) {
		this.telefone = telefone;
	}
	public List<Endereco> getEnderecos() {
		return enderecos;
	}
	public void setEnderecos(List<Endereco> endereco) {
		this.enderecos = endereco;
	}
	public List<CartaoCredito> getCartoesCredito() {
		return cartoesCredito;
	}
	public void setCartoesCredito(List<CartaoCredito> cartaoCredito) {
		this.cartoesCredito = cartaoCredito;
	}
	
	public List<CupomTroca> getCuponsTroca() {
		return cuponsTroca;
	}
	public void setCuponsTroca(List<CupomTroca> cuponsTroca) {
		this.cuponsTroca = cuponsTroca;
	}
	public Boolean getAtivo() {
		return ativo;
	}
	public void setAtivo(Boolean ativo) {
		this.ativo = ativo;
	}
	public String getCodigo() {
		return codigo;
	}
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	public Integer getRanking() {
		return ranking;
	}
	public void setRanking(Integer ranking) {
		this.ranking = ranking;
	}
	
	public List<Pedido> getPedidos() {
		return pedidos;
	}
	public void setPedidos(List<Pedido> pedidos) {
		this.pedidos = pedidos;
	}
	public Endereco getEnderecoPrincipal() {
		for(Endereco endereco : this.getEnderecos()) {
			if(endereco.getPrimario())
				return endereco;
		}
		return null;
	}

}
