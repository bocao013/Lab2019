package br.com.livraria.dominio.cliente;

import br.com.livraria.dominio.EntidadeDominio;

public class Bandeira extends EntidadeDominio {
	public Integer padrao;
	public String nomeBandeira;
	
	public Integer getPadrao() {
		return padrao;
	}
	public void setPadrao(Integer padrao) {
		this.padrao = padrao;
	}
	public String getNomeBandeira() {
		return nomeBandeira;
	}
	public void setNomeBandeira(String nomeBandeira) {
		this.nomeBandeira = nomeBandeira;
	}

}
