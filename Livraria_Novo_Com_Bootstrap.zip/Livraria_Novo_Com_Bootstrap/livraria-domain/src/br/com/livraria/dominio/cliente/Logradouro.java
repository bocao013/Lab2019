package br.com.livraria.dominio.cliente;

import br.com.livraria.dominio.EntidadeDominio;

public class Logradouro extends EntidadeDominio {
	private String logradouro;
	private TipoLogradouro tipoLogradouro;
	
	public TipoLogradouro getTipoLogradouro() {
		return tipoLogradouro;
	}
	public void setTipoLogradouro(TipoLogradouro tipoLogradouro) {
		this.tipoLogradouro = tipoLogradouro;
	}
	public String getLogradouro() {
		return logradouro;
	}
	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}

}
