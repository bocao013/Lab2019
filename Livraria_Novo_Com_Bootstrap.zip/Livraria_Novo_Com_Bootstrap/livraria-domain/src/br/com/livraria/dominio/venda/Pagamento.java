package br.com.livraria.dominio.venda;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import br.com.livraria.dominio.EntidadeDominio;

public class Pagamento extends EntidadeDominio {
	private Date dtPagamento;
	private Cupom cupom;
	private List<CupomTroca> cuponsTroca;
	private Double valorTotal;
	private List<PagamentoCartaoCredito> pagamentosCartao;
	
	public Pagamento() {
		cuponsTroca = new ArrayList<CupomTroca>();
		pagamentosCartao = new ArrayList<PagamentoCartaoCredito>();
	}
	
	public Date getDtPagamento() {
		return dtPagamento;
	}
	public void setDtPagamento(Date dtPagamento) {
		this.dtPagamento = dtPagamento;
	}
	public Cupom getCupom() {
		return cupom;
	}
	public void setCupom(Cupom cupom) {
		this.cupom = cupom;
	}
	public List<PagamentoCartaoCredito> getPagamentosCartao() {
		return pagamentosCartao;
	}
	public void setPagamentosCartao(List<PagamentoCartaoCredito> pagamentosCartao) {
		this.pagamentosCartao = pagamentosCartao;
	}
	public Double getValorTotal() {
		return valorTotal;
	}
	public void setValorTotal(Double valorTotal) {
		this.valorTotal = valorTotal;
	}
	public List<CupomTroca> getCuponsTroca() {
		return cuponsTroca;
	}
	public void setCuponsTroca(List<CupomTroca> cuponsTroca) {
		this.cuponsTroca = cuponsTroca;
	}
	
	
	
	

}
