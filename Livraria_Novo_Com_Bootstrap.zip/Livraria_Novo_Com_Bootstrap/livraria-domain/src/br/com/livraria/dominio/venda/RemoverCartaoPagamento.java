package br.com.livraria.dominio.venda;

import br.com.livraria.dominio.EntidadeDominio;

public class RemoverCartaoPagamento extends EntidadeDominio {
	private Pedido carrinho;
	private Integer idCartaoRemover;
	
	public Pedido getCarrinho() {
		return carrinho;
	}
	public void setCarrinho(Pedido carrinho) {
		this.carrinho = carrinho;
	}
	public Integer getIdCartaoRemover() {
		return idCartaoRemover;
	}
	public void setIdCartaoRemover(Integer idCartaoRemover) {
		this.idCartaoRemover = idCartaoRemover;
	}
	
	

}
