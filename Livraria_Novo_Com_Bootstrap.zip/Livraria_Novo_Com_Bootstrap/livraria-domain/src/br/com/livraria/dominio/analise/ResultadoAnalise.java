package br.com.livraria.dominio.analise;

public class ResultadoAnalise {
	
	private String valorEixoX;
	private String valorEixoY;
	
	public String getValorEixoX() {
		return valorEixoX;
	}
	public void setValorEixoX(String valorEixoX) {
		this.valorEixoX = valorEixoX;
	}
	public String getValorEixoY() {
		return valorEixoY;
	}
	public void setValorEixoY(String valorEixoY) {
		this.valorEixoY = valorEixoY;
	}
	
	

}
