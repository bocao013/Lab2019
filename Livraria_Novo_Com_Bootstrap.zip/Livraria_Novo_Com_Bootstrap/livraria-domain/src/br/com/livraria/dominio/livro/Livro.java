package br.com.livraria.dominio.livro;

import java.util.List;

import br.com.livraria.dominio.EntidadeDominio;

public class Livro extends EntidadeDominio {
	private String codigo;
	private String autor;
	private String titulo;
	private String ano;
	private String edicao;
	private String numeroPaginas;
	private String sinopse;
	private List<Categoria> categorias;
	private Dimensoes dimensoes;
	private Editora editora;
	private GrupoLivro grupolivro;
	private ISBN isbn;
	private List<SubCategoria> subCategorias;
	private Boolean ativo;
	private Double preco;
	
	public Double getPreco() {
		return preco;
	}
	public void setPreco(Double preco) {
		this.preco = preco;
	}
	public List<Categoria> getCategorias() {
		return categorias;
	}
	public void setCategorias(List<Categoria> categorias) {
		this.categorias = categorias;
	}
	public Dimensoes getDimensoes() {
		return dimensoes;
	}
	public void setDimensoes(Dimensoes dimensoes) {
		this.dimensoes = dimensoes;
	}
	public Editora getEditora() {
		return editora;
	}
	public void setEditora(Editora editora) {
		this.editora = editora;
	}
	public GrupoLivro getGrupolivro() {
		return grupolivro;
	}
	public void setGrupolivro(GrupoLivro grupolivro) {
		this.grupolivro = grupolivro;
	}
	public ISBN getIsbn() {
		return isbn;
	}
	public void setIsbn(ISBN isbn) {
		this.isbn = isbn;
	}
	public List<SubCategoria> getSubCategorias() {
		return subCategorias;
	}
	public void setSubCategorias(List<SubCategoria> subCategorias) {
		this.subCategorias = subCategorias;
	}
	public String getCodigo() {
		return codigo;
	}
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	public String getAutor() {
		return autor;
	}
	public void setAutor(String autor) {
		this.autor = autor;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public String getAno() {
		return ano;
	}
	public void setAno(String ano) {
		this.ano = ano;
	}
	public String getEdicao() {
		return edicao;
	}
	public void setEdicao(String edicao) {
		this.edicao = edicao;
	}
	public String getNumeroPaginas() {
		return numeroPaginas;
	}
	public void setNumeroPaginas(String numeroPaginas) {
		this.numeroPaginas = numeroPaginas;
	}
	public String getSinopse() {
		return sinopse;
	}
	public void setSinopse(String sinopse) {
		this.sinopse = sinopse;
	}
	public Boolean getAtivo() {
		return ativo;
	}
	public void setAtivo(Boolean ativo) {
		this.ativo = ativo;
	}

}
