package br.com.livraria.dominio.venda;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.cliente.Cliente;
import br.com.livraria.dominio.cliente.Endereco;

public class Pedido extends EntidadeDominio {
	private Cliente cliente;
	private List<ItemPedido> items;
	private Endereco endereco;
	private Pagamento pagamento;
	private Date dtPedido;
	private StatusPedido statusPedido;
	
	public Pedido() {
		Pagamento pagamento = new Pagamento();
		List<PagamentoCartaoCredito> pagamentos = new ArrayList<PagamentoCartaoCredito>();
		pagamento.setPagamentosCartao(pagamentos);
		this.setPagamento(pagamento);
	}
	
	public List<ItemPedido> getItems() {
		return items;
	}
	public void setItems(List<ItemPedido> items) {
		this.items = items;
	}
	public Cliente getCliente() {
		return cliente;
	}
	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}
	public Date getDtPedido() {
		return dtPedido;
	}
	public void setDtPedido(Date dtPedido) {
		this.dtPedido = dtPedido;
	}
	public Endereco getEndereco() {
		return endereco;
	}
	public void setEndereco(Endereco endereco) {
		this.endereco = endereco;
	}
	
	public Pagamento getPagamento() {
		return pagamento;
	}
	public void setPagamento(Pagamento pagamento) {
		this.pagamento = pagamento;
	}

	public StatusPedido getStatusPedido() {
		return statusPedido;
	}

	public void setStatusPedido(StatusPedido statusPedido) {
		this.statusPedido = statusPedido;
	}


}
