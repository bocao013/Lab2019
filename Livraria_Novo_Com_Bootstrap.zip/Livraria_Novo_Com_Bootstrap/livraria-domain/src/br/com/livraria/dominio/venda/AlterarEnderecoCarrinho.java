package br.com.livraria.dominio.venda;

import br.com.livraria.dominio.EntidadeDominio;

public class AlterarEnderecoCarrinho extends EntidadeDominio {
	private Pedido carrinho;

	public Pedido getCarrinho() {
		return carrinho;
	}

	public void setCarrinho(Pedido carrinho) {
		this.carrinho = carrinho;
	}

}
