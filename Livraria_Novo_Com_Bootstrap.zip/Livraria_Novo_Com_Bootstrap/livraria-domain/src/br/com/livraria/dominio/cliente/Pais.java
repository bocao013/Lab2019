package br.com.livraria.dominio.cliente;

import java.util.List;

import br.com.livraria.dominio.EntidadeDominio;

public class Pais extends EntidadeDominio {
	private String nome;
	List<Estado> estados;
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public List<Estado> getEstados() {
		return estados;
	}
	public void setEstados(List<Estado> estados) {
		this.estados = estados;
	}

}
