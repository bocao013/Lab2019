package br.com.livraria.dominio.livro;

import br.com.livraria.dominio.EntidadeDominio;

public class ISBN extends EntidadeDominio {
	private String codigoBarras;

	public String getCodigoBarras() {
		return codigoBarras;
	}

	public void setCodigoBarras(String codigoBarras) {
		this.codigoBarras = codigoBarras;
	}
}

