package br.com.livraria.dominio.venda;

import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.livro.Livro;

public class Item extends EntidadeDominio {
	private Integer quantidade;
	private Livro livro;
	
	public Integer getQuantidade() {
		return quantidade;
	}
	public void setQuantidade(Integer quantidade) {
		this.quantidade = quantidade;
	}
	public Livro getLivro() {
		return livro;
	}
	public void setLivro(Livro livro) {
		this.livro = livro;
	}
	
}
