package br.com.livraria.dominio.venda;

import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.cliente.Cliente;

public class RealizarTroca extends EntidadeDominio {
	private Pedido pedidoTroca;
	private CupomTroca cupomGerado;

	public Pedido getPedidoTroca() {
		return pedidoTroca;
	}

	public void setPedidoTroca(Pedido pedidoTroca) {
		this.pedidoTroca = pedidoTroca;
	}

	public CupomTroca getCupomGerado() {
		return cupomGerado;
	}

	public void setCupomGerado(CupomTroca cupomGerado) {
		this.cupomGerado = cupomGerado;
	}
	
	
}
