package br.com.livraria.dominio.cliente;

import br.com.livraria.dominio.EntidadeDominio;

public class TipoResidencia extends EntidadeDominio {
	private String tipoResidencia;

	public String getTipoResidencia() {
		return tipoResidencia;
	}

	public void setTipoResidencia(String tipoResidencia) {
		this.tipoResidencia = tipoResidencia;
	}

}
