package br.com.livraria.dominio.cliente;

import java.util.Date;

import br.com.livraria.dominio.EntidadeDominio;

public class CartaoCredito extends EntidadeDominio {
	private String numero;
	private String nome;
	private String codigoSeguranca;
	private Date dtVencimento;
	private Boolean primario;
	private Cliente cliente;
	
	public Cliente getCliente() {
		return cliente;
	}
	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}
	public Boolean getPrimario() {
		return primario;
	}
	public void setPrimario(Boolean primario) {
		this.primario = primario;
	}
	public String getNumero() {
		return numero;
	}
	public void setNumero(String numero) {
		this.numero = numero;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCodigoSeguranca() {
		return codigoSeguranca;
	}
	public void setCodigoSeguranca(String codigoSeguranca) {
		this.codigoSeguranca = codigoSeguranca;
	}
	public Date getDtVencimento() {
		return dtVencimento;
	}
	public void setDtVencimento(Date dtVencimento) {
		this.dtVencimento = dtVencimento;
	}


}
