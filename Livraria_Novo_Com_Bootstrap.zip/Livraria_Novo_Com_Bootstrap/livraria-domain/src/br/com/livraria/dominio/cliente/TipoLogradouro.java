package br.com.livraria.dominio.cliente;

import br.com.livraria.dominio.EntidadeDominio;

public class TipoLogradouro extends EntidadeDominio {
	private String tipoLogradouro;

	public String getTipoLogradouro() {
		return tipoLogradouro;
	}

	public void setTipoLogradouro(String tipoLogradouro) {
		this.tipoLogradouro = tipoLogradouro;
	}

}
