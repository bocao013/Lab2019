package br.com.livraria.dominio.cliente;

import java.util.List;

import br.com.livraria.dominio.EntidadeDominio;

public class Estado extends EntidadeDominio {
	private String nome;
	private String uf;
	private Pais pais;
	List<Cidade> cidades;
	
	public Pais getPais() {
		return pais;
	}
	public void setPais(Pais pais) {
		this.pais = pais;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getUf() {
		return uf;
	}
	public void setUf(String uf) {
		this.uf = uf;
	}
	public List<Cidade> getCidades() {
		return cidades;
	}
	public void setCidades(List<Cidade> cidades) {
		this.cidades = cidades;
	}
	

}
