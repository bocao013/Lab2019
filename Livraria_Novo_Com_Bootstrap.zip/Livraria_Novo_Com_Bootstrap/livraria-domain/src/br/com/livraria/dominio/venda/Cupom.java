package br.com.livraria.dominio.venda;

import br.com.livraria.dominio.EntidadeDominio;

public class Cupom extends EntidadeDominio {
	private String nome;
	private Double valorDesconto;
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public Double getValorDesconto() {
		return valorDesconto;
	}
	public void setValorDesconto(Double valorDesconto) {
		this.valorDesconto = valorDesconto;
	}

	@Override
	public String toString() {
		return String.format("Cupom %s no valor de R$%.2f", getNome(), getValorDesconto());
	}
}
