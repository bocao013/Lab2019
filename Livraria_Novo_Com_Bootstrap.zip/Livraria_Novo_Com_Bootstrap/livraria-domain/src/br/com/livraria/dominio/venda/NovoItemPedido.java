package br.com.livraria.dominio.venda;

import br.com.livraria.dominio.EntidadeDominio;

public class NovoItemPedido extends EntidadeDominio {
	private Pedido carrinho;
	private ItemPedido novoItem;
	
	public Pedido getCarrinho() {
		return carrinho;
	}
	public void setCarrinho(Pedido carrinho) {
		this.carrinho = carrinho;
	}
	public ItemPedido getNovoItem() {
		return novoItem;
	}
	public void setNovoItem(ItemPedido novoItem) {
		this.novoItem = novoItem;
	}

}
