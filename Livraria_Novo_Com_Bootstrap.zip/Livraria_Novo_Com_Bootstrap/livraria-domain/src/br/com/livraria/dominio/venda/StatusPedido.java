package br.com.livraria.dominio.venda;

import br.com.livraria.dominio.EntidadeDominio;

public class StatusPedido extends EntidadeDominio {
	private String status;
	private StatusPedido proximoStatus;
	public static final Integer EM_PROGRESSO = 1;
	public static final Integer EM_TRANSPORTE = 2;
	public static final Integer ENTREGUE = 3;
	public static final Integer EM_TROCA= 4;
	public static final Integer APROVADO = 5;
	public static final Integer REPROVADO = 6;
	public static final Integer TROCADO = 7;
	
	public StatusPedido getProximoStatus() {
		return proximoStatus;
	}
	public void setProximoStatus(StatusPedido proximoStatus) {
		this.proximoStatus = proximoStatus;
	}
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	

}
