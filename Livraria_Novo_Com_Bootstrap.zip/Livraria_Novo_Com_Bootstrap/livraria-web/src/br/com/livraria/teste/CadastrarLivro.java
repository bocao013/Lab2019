package br.com.livraria.teste;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;


public class CadastrarLivro {

	public static void main(String[] args) throws InterruptedException {
		// pra evitar a excess�o de n�o encontrar o driver
		System.setProperty("webdriver.chrome.driver","D:\\Documents\\01 - Programa��o\\Eclipse\\lib\\chromedriver.exe");
		
		// cria o driver do google chrome para pilotar o browser
		WebDriver driver = new ChromeDriver();

		// abre a p�gina do admin
		driver.get("http://localhost:8080/livraria/admin");

		Thread.sleep(2000); // espera 2 segundos
		
		//limpa o campo 
		driver.findElement(By.id("txtNome")).clear();
		//passa os valores
		driver.findElement(By.id("txtNome")).sendKeys("admin");
		
		Thread.sleep(2000); // espera 2 segundos
		
		//limpa o campo 
		driver.findElement(By.id("txtSenha")).clear();
		//passa os valores
		driver.findElement(By.id("txtSenha")).sendKeys("123");
		
		Thread.sleep(2000); // espera 2 segundos
		
		// clica no bot�o para entrar
		driver.findElement(By.id("btEntrar")).click();

		Thread.sleep(2000); // espera 2 segundos

		// clica no link para mostrar os produtos
		driver.findElement(By.id("linkLivros")).click();
		
		Thread.sleep(2000); // espera 2 segundos
		
		//limpa o campo 
		driver.findElement(By.id("txtConsulta")).clear();
		//passa os valores
		driver.findElement(By.id("txtConsulta")).sendKeys("Paulo Coelho");
		Thread.sleep(2000); // espera 2 segundos
		driver.findElement(By.id("btConsulta")).click();

		Thread.sleep(4000); // espera 4 segundos
		
		// clica no bot�o para buscar
		driver.findElement(By.id("linkCadastrarLivro")).click();
		
		Thread.sleep(2000); // espera 2 segundos
		
		//limpa o campo 
		driver.findElement(By.id("txtCodigo")).clear();
		//passa os valores
		driver.findElement(By.id("txtCodigo")).sendKeys("150");
		Thread.sleep(2000); // espera 2 segundos
		
		//limpa o campo 
		driver.findElement(By.id("txtAutor")).clear();
		//passa os valores
		driver.findElement(By.id("txtAutor")).sendKeys("J.K.Rowling");
		Thread.sleep(2000); // espera 2 segundos
		
		//limpa o campo 
		driver.findElement(By.id("txtTitulo")).clear();
		//passa os valores
		driver.findElement(By.id("txtTitulo")).sendKeys("Harry Potter e o C�lice de Fogo");
		Thread.sleep(2000); // espera 2 segundos
		
		//limpa o campo 
		driver.findElement(By.id("txtAno")).clear();
		//passa os valores
		driver.findElement(By.id("txtAno")).sendKeys("2000");
		Thread.sleep(2000); // espera 2 segundos
		
		//limpa o campo 
		driver.findElement(By.id("txtEdicao")).clear();
		//passa os valores
		driver.findElement(By.id("txtEdicao")).sendKeys("2");
		Thread.sleep(2000); // espera 2 segundos
		
		//limpa o campo 
		driver.findElement(By.id("txtNumPaginas")).clear();
		//passa os valores
		driver.findElement(By.id("txtNumPaginas")).sendKeys("400");
		Thread.sleep(2000); // espera 2 segundos
		
		//limpa o campo 
		driver.findElement(By.id("txtSinopse")).clear();
		//passa os valores
		driver.findElement(By.id("txtSinopse")).sendKeys("Harry ...");
		Thread.sleep(2000); // espera 2 segundos
		
		//limpa o campo 
		driver.findElement(By.id("txtEditora")).clear();
		//passa os valores
		driver.findElement(By.id("txtEditora")).sendKeys("Rocco");
		Thread.sleep(2000); // espera 2 segundos

		//passa os valores
		driver.findElement(By.id("categoriaAventura")).click();
		Thread.sleep(2000); // espera 2 segundos
		
		//passa os valores
		driver.findElement(By.id("categoriaFic��o")).click();
		Thread.sleep(2000); // espera 2 segundos
		
		// criar o executor de javascript
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		
		// dar scroll down na p�gina
		jse.executeScript("window.scrollBy(0,500)", "");
		Thread.sleep(4000); // espera 4 segundos
		
		//passa os valores
		driver.findElement(By.id("subcategoriaAventura fant�stica")).click();
		Thread.sleep(2000); // espera 2 segundos
		
		//passa os valores
		driver.findElement(By.id("subcategoriaTerror psicol�gico")).click();
		Thread.sleep(2000); // espera 2 segundos
		
		//limpa o campo 
		driver.findElement(By.id("txtAltura")).clear();
		//passa os valores
		driver.findElement(By.id("txtAltura")).sendKeys("0.50");
		Thread.sleep(2000); // espera 2 segundos
		
		//limpa o campo 
		driver.findElement(By.id("txtLargura")).clear();
		//passa os valores
		driver.findElement(By.id("txtLargura")).sendKeys("0.30");
		Thread.sleep(2000); // espera 2 segundos
		
		//limpa o campo 
		driver.findElement(By.id("txtPeso")).clear();
		//passa os valores
		driver.findElement(By.id("txtPeso")).sendKeys("500");
		Thread.sleep(2000); // espera 2 segundos
		
		//limpa o campo 
		driver.findElement(By.id("txtProfundidade")).clear();
		//passa os valores
		driver.findElement(By.id("txtProfundidade")).sendKeys("0.30");
		Thread.sleep(2000); // espera 2 segundos
		
		//limpa o campo 
		driver.findElement(By.id("txtIsbn")).clear();
		//passa os valores
		driver.findElement(By.id("txtIsbn")).sendKeys("85-325-1101-5");
		Thread.sleep(2000); // espera 2 segundos
		
		//limpa o campo 
		driver.findElement(By.id("txtPreco")).clear();
		//passa os valores
		driver.findElement(By.id("txtPreco")).sendKeys("63.90");
		Thread.sleep(2000); // espera 2 segundos
		
		Select cbPrecificacao = new Select(driver.findElement(By.id("cbPrecificacao")));
		cbPrecificacao.selectByValue("2");
		Thread.sleep(2000); // espera 2 segundos
		
		//clica no bot�o para salvar
		driver.findElement(By.id("btSalvar")).click();
		Thread.sleep(4000); // espera 4 segundos
		
		// VISUALIZAR O LIVRO
		
		driver.findElement(By.id("linkVisualizar150")).click();
		Thread.sleep(2000); // espera 4 segundos
		
		//limpa o campo 
		driver.findElement(By.id("txtAno")).clear();
		driver.findElement(By.id("txtAno")).sendKeys("2001");
		Thread.sleep(4000); // espera 4 segundos
		
		//limpa o campo 
		driver.findElement(By.id("txtEditora")).clear();
		driver.findElement(By.id("txtEditora")).sendKeys("Editora Rocco");
		Thread.sleep(4000); // espera 4 segundos
		
		//clica no bot�o para salvar
		driver.findElement(By.id("btSalvar")).click();
		Thread.sleep(2000); // espera 4 segundos
	}

}
