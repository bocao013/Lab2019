package br.com.livraria.teste;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;


public class Compra {

	public static void main(String[] args) throws InterruptedException {
		// pra evitar a excess�o de n�o encontrar o driver
		System.setProperty("webdriver.chrome.driver","D:\\Documents\\01 - Programa��o\\Eclipse\\lib\\chromedriver.exe");
		
		// cria o driver do google chrome para pilotar o browser
		WebDriver driver = new ChromeDriver();

		// abre a p�gina do index
		driver.get("http://localhost:8080/livraria");

		Thread.sleep(2000);
		
		// ----------------------------------CONSULTAR UM LIVRO----------------------------------------
		
		driver.findElement(By.id("txtConsulta")).clear();
		driver.findElement(By.id("txtConsulta")).sendKeys("As Duas Torres");
		Thread.sleep(4000);
		
		driver.findElement(By.id("btConsulta")).click();
		Thread.sleep(4000); 
		
		// ------------------------------CLICAR NO LINK P/ ENTRAR NO SISTEMA----------------------------
		
		driver.findElement(By.id("linkEntrar")).click();
		Thread.sleep(2000);
		
		// --------------------------------LOGAR NO SISTEMA---------------------------------------------
	
		driver.findElement(By.id("txtEmail")).clear();
		driver.findElement(By.id("txtEmail")).sendKeys("monica@mail.com");
		Thread.sleep(2000); 
		
		driver.findElement(By.id("txtSenha")).clear();
		driver.findElement(By.id("txtSenha")).sendKeys("aA1@xxxx");
		Thread.sleep(2000); 
		
		driver.findElement(By.id("btEntrar")).click();
		Thread.sleep(4000); 
		
		// --------------------------ADICIONAR NO CARRINHO----------------------------------------------

		driver.findElement(By.id("linkDetalharLivro3")).click();
		Thread.sleep(2000);
		
		// criar o executor de javascript
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		
		// dar scroll down na p�gina
		jse.executeScript("window.scrollBy(0,500)", "");
		Thread.sleep(4000); // espera 4 segundos
				
		
		driver.findElement(By.id("linkAddCarrinho")).click();
		Thread.sleep(2000);
		
		// -------------------------ACESSAR O CARRINHO--------------------------------------------------
		
		driver.findElement(By.id("linkCarrinho")).click();
		Thread.sleep(2000);
		
		// -------------------------MUDAR ENDERECO------------------------------------------------------
		driver.findElement(By.id("linkEnd39")).click();
		Thread.sleep(4000);
		
		driver.findElement(By.id("linkEnd41")).click();
		Thread.sleep(4000);
		
		// -------------------------CADASTRAR NOVO ENDERECO----------------------------------------------
		driver.findElement(By.id("linkCadastrarEndereco")).click();
		Thread.sleep(4000);
		
		Select cbTipoLogradouro = new Select(driver.findElement(By.id("cbTipoLogradouro")));
		cbTipoLogradouro.selectByValue("1");
		Thread.sleep(3000);
		
		driver.findElement(By.id("txtLogradouro")).clear();
		driver.findElement(By.id("txtLogradouro")).sendKeys("Jos� Cardoso Xavier");
		Thread.sleep(3000);
		
		driver.findElement(By.id("txtNumero")).clear();
		driver.findElement(By.id("txtNumero")).sendKeys("222");
		Thread.sleep(3000);
		
		driver.findElement(By.id("txtBairro")).clear();
		driver.findElement(By.id("txtBairro")).sendKeys("Jd.Cacique");
		Thread.sleep(3000);
		
		driver.findElement(By.id("txtCep")).clear();
		driver.findElement(By.id("txtCep")).sendKeys("08616020");
		Thread.sleep(3000);
		
		driver.findElement(By.id("txtObservacao")).clear();
		driver.findElement(By.id("txtObservacao")).sendKeys("Em frente ao posto");
		Thread.sleep(3000);
		
		Select cbPais = new Select(driver.findElement(By.id("cbPais")));
		cbPais.selectByValue("1");
		Thread.sleep(3000);
		
		Select cbEstado = new Select(driver.findElement(By.id("cbEstado")));
		cbEstado.selectByValue("1");
		Thread.sleep(3000); 
		
		Select cbCidade = new Select(driver.findElement(By.id("cbCidade")));
		cbCidade.selectByValue("1");
		Thread.sleep(3000); 
		
		Select cbTipoResidencia = new Select(driver.findElement(By.id("cbTipoResidencia")));
		cbTipoResidencia.selectByValue("1");
		Thread.sleep(3000); 
		
		driver.findElement(By.id("btSalvar")).click();
		Thread.sleep(4000); 
		
		// -------------------------QTDES NO CARRINHO----------------------------------------------
		
		driver.findElement(By.id("add5")).click();
		Thread.sleep(4000); 
		
		driver.findElement(By.id("sub5")).click();
		Thread.sleep(4000); 

		// -------------------------ADD NOVAMENTE ITEM NO CARRINHO---------------------------------
		
		driver.findElement(By.id("linkLoja")).click();
		Thread.sleep(4000); 
		
		driver.findElement(By.id("linkDetalharLivro3")).click();
		Thread.sleep(4000); 
		
		// dar scroll down na p�gina
		jse.executeScript("window.scrollBy(0,500)", "");
		Thread.sleep(4000); // espera 4 segundos

		driver.findElement(By.id("linkAddCarrinho")).click();
		Thread.sleep(4000); 
		
		driver.findElement(By.id("linkCarrinho")).click();
		Thread.sleep(4000); 
		
		// -------------------------IR P/ CONTINUAR COMPRANDO----------------------------------------
		// dar scroll down na p�gina
		jse.executeScript("window.scrollBy(0,500)", "");
		Thread.sleep(4000); // espera 4 segundos
		
		driver.findElement(By.id("operacao")).click();
		Thread.sleep(4000); 
		
		// -------------------------USAR UM CUPOM PROMOCIONAL----------------------------------------
		
		driver.findElement(By.id("checkCupom")).click();
		Thread.sleep(4000); 
		
		driver.findElement(By.id("txtCupom")).clear();
		driver.findElement(By.id("txtCupom")).sendKeys("teste");
		Thread.sleep(4000);
		
		driver.findElement(By.id("idValidarCupom")).click();
		Thread.sleep(4000); 
		
		// -----------------------CADASTRAR UM NOVO CART�O--------------------------------------------
		
		// dar scroll down na p�gina
		jse.executeScript("window.scrollBy(0,500)", "");
		Thread.sleep(4000); // espera 4 segundos
		
		driver.findElement(By.id("linkCadastrarCartao")).click();
		Thread.sleep(4000); 
		
		driver.findElement(By.id("txtNumCartao")).clear();
		driver.findElement(By.id("txtNumCartao")).sendKeys("5162208535126924");
		Thread.sleep(4000);
		
		driver.findElement(By.id("txtNomeCartao")).clear();
		driver.findElement(By.id("txtNomeCartao")).sendKeys("Monica G. S.");
		Thread.sleep(4000);
		
		driver.findElement(By.id("txtCodSeguranca")).clear();
		driver.findElement(By.id("txtCodSeguranca")).sendKeys("419");
		Thread.sleep(4000);
		
		driver.findElement(By.id("txtDtVencimento")).sendKeys("21/12/2020");
		Thread.sleep(4000);
		
		driver.findElement(By.id("btSalvar")).click();
		Thread.sleep(4000); 
		
		// -----------------------ADD PAGAMENTO INV�LIDO--------------------------------------------
		
		// dar scroll down na p�gina
		jse.executeScript("window.scrollBy(0,500)", "");
		Thread.sleep(4000); // espera 4 segundos
		
		driver.findElement(By.id("linkAddPagamento27")).click();
		Thread.sleep(4000); 
		
		driver.findElement(By.id("txtValorPagamento")).clear();
		driver.findElement(By.id("txtValorPagamento")).sendKeys("196.22");
		Thread.sleep(4000);
		
		driver.findElement(By.id("btSalvar")).click();
		Thread.sleep(4000); 
		
		driver.findElement(By.id("operacao")).click();
		Thread.sleep(4000); 
		
		driver.findElement(By.id("linkRemoverCartao")).click();
		Thread.sleep(4000); 
		
		// -----------------------ADD PAGAMENTO V�LIDO-----------------------------------------------
		
		// dar scroll down na p�gina
		jse.executeScript("window.scrollBy(0,500)", "");
		Thread.sleep(4000); // espera 4 segundos
		
		driver.findElement(By.id("linkAddPagamento24")).click();
		Thread.sleep(4000);

		driver.findElement(By.id("txtValorPagamento")).clear();
		driver.findElement(By.id("txtValorPagamento")).sendKeys("10.00");
		Thread.sleep(4000);
		
		driver.findElement(By.id("btSalvar")).click();
		Thread.sleep(4000); 
		
		// dar scroll down na p�gina
		jse.executeScript("window.scrollBy(0,500)", "");
		Thread.sleep(4000); // espera 4 segundos
		
		driver.findElement(By.id("linkAddPagamento26")).click();
		Thread.sleep(4000);
		
		driver.findElement(By.id("txtValorPagamento")).clear();
		driver.findElement(By.id("txtValorPagamento")).sendKeys("186.22");
		Thread.sleep(4000);
		
		driver.findElement(By.id("btSalvar")).click();
		Thread.sleep(4000); 
		
		// -----------------------FINALIZAR PEDIDO---------------------------------------------------
		
		// dar scroll down na p�gina
		jse.executeScript("window.scrollBy(0,500)", "");
		Thread.sleep(4000); // espera 4 segundos

		driver.findElement(By.id("operacao")).click();
		Thread.sleep(4000); 
		
		driver.findElement(By.id("linkLoja")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.id("linkPerfil")).click();
		Thread.sleep(2000);
		
		// dar scroll down na p�gina
		jse.executeScript("window.scrollBy(0,500)", "");
		Thread.sleep(4000); // espera 4 segundos
	}

}
