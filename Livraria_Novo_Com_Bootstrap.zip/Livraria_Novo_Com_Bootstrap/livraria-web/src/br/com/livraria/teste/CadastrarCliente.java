package br.com.livraria.teste;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class CadastrarCliente {

	public static void main(String[] args) throws InterruptedException {
		// pra evitar a excess�o de n�o encontrar o driver
		System.setProperty("webdriver.chrome.driver","D:\\Documents\\01 - Programa��o\\Eclipse\\lib\\chromedriver.exe");
		
		// cria o driver do google chrome para pilotar o browser
		WebDriver driver = new ChromeDriver();

		// abre a p�gina do admin
		driver.get("http://localhost:8080/livraria");

		Thread.sleep(4000); // espera 2 segundos
		
	/*	// clica no bot�o para cadastrar
		driver.findElement(By.id("linkCadastrarCliente")).click();

		Thread.sleep(4000); // espera 8 segundos
	
		//limpa o campo 
		driver.findElement(By.id("txtCodigo")).clear();
		//passa os valores
		driver.findElement(By.id("txtCodigo")).sendKeys("150");
		Thread.sleep(2000); // espera 2 segundos
		
		//limpa o campo 
		driver.findElement(By.id("txtGenero")).clear();
		//passa os valores
		driver.findElement(By.id("txtGenero")).sendKeys("Feminino");
		Thread.sleep(2000); // espera 2 segundos
		
		//limpa o campo 
		driver.findElement(By.id("txtNome")).clear();
		//passa os valores
		driver.findElement(By.id("txtNome")).sendKeys("Monica Geller");
		Thread.sleep(2000); // espera 2 segundos
		
		//passa os valores
		driver.findElement(By.id("txtDtNascimento")).sendKeys("10/05/1980");
		Thread.sleep(2000); // espera 2 segundos
		
		//limpa o campo 
		driver.findElement(By.id("txtEmail")).clear();
		//passa os valores
		driver.findElement(By.id("txtEmail")).sendKeys("monica@mail.com");
		Thread.sleep(2000); // espera 2 segundos
		
		//limpa o campo 
		driver.findElement(By.id("txtCpf")).clear();
		//passa os valores
		driver.findElement(By.id("txtCpf")).sendKeys("34100154852");
		Thread.sleep(2000); // espera 2 segundos
		
		//limpa o campo 
		driver.findElement(By.id("txtTelefone")).clear();
		//passa os valores
		driver.findElement(By.id("txtTelefone")).sendKeys("999582545");
		Thread.sleep(2000); // espera 2 segundos
		
		//limpa o campo 
		driver.findElement(By.id("txtDdd")).clear();
		//passa os valores
		driver.findElement(By.id("txtDdd")).sendKeys("12");
		Thread.sleep(2000); // espera 2 segundos
		
		Select cbTipoTelefone = new Select(driver.findElement(By.id("cbTipoTelefone")));
		cbTipoTelefone.selectByValue("1");
		Thread.sleep(2000); // espera 2 segundos
		
		Select cbTipoLogradouro = new Select(driver.findElement(By.id("cbTipoLogradouro")));
		cbTipoLogradouro.selectByValue("1");
		Thread.sleep(2000); // espera 2 segundos

		//limpa o campo 
		driver.findElement(By.id("txtLogradouro")).clear();
		//passa os valores
		driver.findElement(By.id("txtLogradouro")).sendKeys("Teste");
		Thread.sleep(2000); // espera 2 segundos
		
		//limpa o campo 
		driver.findElement(By.id("txtNumero")).clear();
		//passa os valores
		driver.findElement(By.id("txtNumero")).sendKeys("222");
		Thread.sleep(2000); // espera 2 segundos
		
		//limpa o campo 
		driver.findElement(By.id("txtBairro")).clear();
		//passa os valores
		driver.findElement(By.id("txtBairro")).sendKeys("Jd.Teste");
		Thread.sleep(2000); // espera 2 segundos
		
		//limpa o campo 
		driver.findElement(By.id("txtCep")).clear();
		//passa os valores
		driver.findElement(By.id("txtCep")).sendKeys("08780510");
		Thread.sleep(2000); // espera 2 segundos
		
		//limpa o campo 
		driver.findElement(By.id("txtObservacao")).clear();
		//passa os valores
		driver.findElement(By.id("txtObservacao")).sendKeys("Em frente ao pr�dio");
		Thread.sleep(2000); // espera 2 segundos
		
		Select cbPais = new Select(driver.findElement(By.id("cbPais")));
		cbPais.selectByValue("1");
		Thread.sleep(2000); // espera 2 segundos
		
		Select cbEstado = new Select(driver.findElement(By.id("cbEstado")));
		cbEstado.selectByValue("1");
		Thread.sleep(2000); // espera 2 segundos
		
		Select cbCidade = new Select(driver.findElement(By.id("cbCidade")));
		cbCidade.selectByValue("1");
		Thread.sleep(2000); // espera 2 segundos
		
		Select cbTipoResidencia = new Select(driver.findElement(By.id("cbTipoResidencia")));
		cbTipoResidencia.selectByValue("1");
		Thread.sleep(2000); // espera 2 segundos
		
		//limpa o campo 
		driver.findElement(By.id("txtNumCartao")).clear();
		//passa os valores
		driver.findElement(By.id("txtNumCartao")).sendKeys("2345678");
		Thread.sleep(2000); // espera 2 segundos
		
		//limpa o campo 
		driver.findElement(By.id("txtNomeCartao")).clear();
		//passa os valores
		driver.findElement(By.id("txtNomeCartao")).sendKeys("Monica G.");
		Thread.sleep(2000); // espera 2 segundos
		
		//limpa o campo 
		driver.findElement(By.id("txtCodSeguranca")).clear();
		//passa os valores
		driver.findElement(By.id("txtCodSeguranca")).sendKeys("411");
		Thread.sleep(2000); // espera 2 segundos
	
		//passa os valores
		driver.findElement(By.id("txtDtVencimento")).sendKeys("31/10/2020");
		Thread.sleep(2000); // espera 2 segundos
		
		//limpa o campo 
		driver.findElement(By.id("txtSenha")).clear();
		//passa os valores
		driver.findElement(By.id("txtSenha")).sendKeys("aA1@xxxx");
		Thread.sleep(2000); // espera 2 segundos
		
		//limpa o campo 
		driver.findElement(By.id("txtConfirmacaoSenha")).clear();
		//passa os valores
		driver.findElement(By.id("txtConfirmacaoSenha")).sendKeys("aA1@xxxx");
		Thread.sleep(2000); // espera 2 segundos
		
		//clica no bot�o para salvar
		driver.findElement(By.id("btSalvar")).click();
		Thread.sleep(2000); // espera 4 segundos
*/		
		// LOGAR COM O CLIENTE CRIADO
		
		//clica no bot�o para entrar na loja
		driver.findElement(By.id("linkEntrar")).click();
		Thread.sleep(2000); // espera 4 segundos
		
		//limpa o campo 
		driver.findElement(By.id("txtEmail")).clear();
		//passa os valores
		driver.findElement(By.id("txtEmail")).sendKeys("monica@mail.com");
		Thread.sleep(2000); // espera 2 segundos
		
		//limpa o campo 
		driver.findElement(By.id("txtSenha")).clear();
		//passa os valores
		driver.findElement(By.id("txtSenha")).sendKeys("aA1@xxxx");
		Thread.sleep(2000); // espera 2 segundos
		
		//clica no bot�o para entrar
		driver.findElement(By.id("btEntrar")).click();
		Thread.sleep(2000); // espera 4 segundos
		
		// VISUALIZAR O PERFIL
		
		//clica no bot�o para entrar no perfil
		driver.findElement(By.id("linkPerfil")).click();
		Thread.sleep(4000); // espera 4 segundos
		
		// criar o executor de javascript
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		
		// dar scroll down na p�gina
		jse.executeScript("window.scrollBy(0,500)", "");
		Thread.sleep(4000); // espera 4 segundos
		
		// dar scroll down na p�gina
		jse.executeScript("window.scrollBy(0,-500)", "");
		Thread.sleep(4000); // espera 4 segundos
				
		
		// Alterar dados, endereco e cart�es
	
		driver.findElement(By.id("btAtualizar")).click();
    	Thread.sleep(4000); // espera 4 segundos
    	
    	//limpa o campo 
		driver.findElement(By.id("txtNome")).clear();
		//passa os valores
		driver.findElement(By.id("txtNome")).sendKeys("Monica G.");
		Thread.sleep(4000); // espera 2 segundos
		
		//limpa o campo 
		driver.findElement(By.id("txtSenha")).clear();
		//passa os valores
		driver.findElement(By.id("txtSenha")).sendKeys("aA1@xxxx");
		Thread.sleep(4000); // espera 2 segundos
						
		//limpa o campo 
		driver.findElement(By.id("txtConfirmacaoSenha")).clear();
		//passa os valores
		driver.findElement(By.id("txtConfirmacaoSenha")).sendKeys("aA1@xxxx");
		Thread.sleep(4000); // espera 2 segundos
		
		//clica no bot�o para salvar
		driver.findElement(By.id("btSalvar")).click();
		Thread.sleep(4000); // espera 4 segundos
		
		// dar scroll down na p�gina
		jse.executeScript("window.scrollBy(0,250)", "");
		Thread.sleep(4000); // espera 4 segundos
				
		// ENDERECO
		
		driver.findElement(By.id("linkCadastrarEndereco")).click();
		Thread.sleep(4000); // espera 4 segundos
		
		Select cbTipoLogradouro = new Select(driver.findElement(By.id("cbTipoLogradouro")));
		cbTipoLogradouro.selectByValue("2");
		Thread.sleep(2000); // espera 2 segundos

		//limpa o campo 
		driver.findElement(By.id("txtLogradouro")).clear();
		//passa os valores
		driver.findElement(By.id("txtLogradouro")).sendKeys("Teste");
		Thread.sleep(2000); // espera 2 segundos
		
		//limpa o campo 
		driver.findElement(By.id("txtNumero")).clear();
		//passa os valores
		driver.findElement(By.id("txtNumero")).sendKeys("111");
		Thread.sleep(2000); // espera 2 segundos
		
		//limpa o campo 
		driver.findElement(By.id("txtBairro")).clear();
		//passa os valores
		driver.findElement(By.id("txtBairro")).sendKeys("Teste");
		Thread.sleep(2000); // espera 2 segundos
		
		//limpa o campo 
		driver.findElement(By.id("txtCep")).clear();
		//passa os valores
		driver.findElement(By.id("txtCep")).sendKeys("11111");
		Thread.sleep(2000); // espera 2 segundos
		
		//limpa o campo 
		driver.findElement(By.id("txtObservacao")).clear();
		//passa os valores
		driver.findElement(By.id("txtObservacao")).sendKeys("Teste");
		Thread.sleep(2000); // espera 2 segundos
		
		Select cbPais = new Select(driver.findElement(By.id("cbPais")));
		cbPais.selectByValue("1");
		Thread.sleep(2000); // espera 2 segundos
		
		Select cbEstado = new Select(driver.findElement(By.id("cbEstado")));
		cbEstado.selectByValue("2");
		Thread.sleep(2000); // espera 2 segundos
		
		Select cbCidade = new Select(driver.findElement(By.id("cbCidade")));
		cbCidade.selectByValue("100");
		Thread.sleep(2000); // espera 2 segundos
		
		Select cbTipoResidencia = new Select(driver.findElement(By.id("cbTipoResidencia")));
		cbTipoResidencia.selectByValue("2");
		Thread.sleep(2000); // espera 2 segundos
		
		//clica no bot�o para salvar
		driver.findElement(By.id("btSalvar")).click();
		Thread.sleep(5000); // espera 4 segundos
		
		// dar scroll down na p�gina
		jse.executeScript("window.scrollBy(0,250)", "");
		Thread.sleep(4000); // espera 4 segundos
	
		// ALTERAR ENDERECO
		driver.findElement(By.id("linkVisualizarEndereco39")).click();
		Thread.sleep(4000); // espera 4 segundos
		
		//limpa o campo 
		driver.findElement(By.id("txtNumero")).clear();
		driver.findElement(By.id("txtNumero")).sendKeys("111111");
		Thread.sleep(2000); // espera 4 segundos
		
		//clica no bot�o para salvar
		driver.findElement(By.id("btAlterar")).click();
		Thread.sleep(4000); // espera 4 segundos
		
		// CART�O DE CR�DITO
		
		// dar scroll down na p�gina
		jse.executeScript("window.scrollBy(0,500)", "");
		Thread.sleep(4000); // espera 4 segundos
	
		
		driver.findElement(By.id("linkCadastrarCartao")).click();
		Thread.sleep(2000); // espera 4 segundos
		
		//limpa o campo 
		driver.findElement(By.id("txtNumCartao")).clear();
		//passa os valores
		driver.findElement(By.id("txtNumCartao")).sendKeys("11111111");
		Thread.sleep(2000); // espera 2 segundos
		
		//limpa o campo 
		driver.findElement(By.id("txtNomeCartao")).clear();
		//passa os valores
		driver.findElement(By.id("txtNomeCartao")).sendKeys("Monica G. S.");
		Thread.sleep(2000); // espera 2 segundos
		
		//limpa o campo 
		driver.findElement(By.id("txtCodSeguranca")).clear();
		//passa os valores
		driver.findElement(By.id("txtCodSeguranca")).sendKeys("444444");
		Thread.sleep(2000); // espera 2 segundos
	
		//passa os valores
		driver.findElement(By.id("txtDtVencimento")).sendKeys("31/10/2020");
		Thread.sleep(2000); // espera 2 segundos
		
		//clica no bot�o para salvar
		driver.findElement(By.id("btSalvar")).click();
		Thread.sleep(4000); // espera 4 segundos
		
		// ALTERAR CARTAO
		
		// dar scroll down na p�gina
		jse.executeScript("window.scrollBy(0,500)", "");
		Thread.sleep(4000); // espera 4 segundos
	
		driver.findElement(By.id("linkVisualizarCartao25")).click();
		Thread.sleep(2000); // espera 4 segundos
		
		//limpa o campo 
		driver.findElement(By.id("txtNumCartao")).clear();
		driver.findElement(By.id("txtNumCartao")).sendKeys("22222222");
		Thread.sleep(2000); // espera 4 segundos
		
		//clica no bot�o para salvar
		driver.findElement(By.id("btAlterar")).click();
		Thread.sleep(4000); // espera 4 segundos
		
		// dar scroll down na p�gina
		jse.executeScript("window.scrollBy(0,500)", "");
		Thread.sleep(4000); // espera 4 segundos

	}

}
