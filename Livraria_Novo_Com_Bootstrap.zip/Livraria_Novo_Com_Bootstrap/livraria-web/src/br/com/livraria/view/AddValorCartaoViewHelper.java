package br.com.livraria.view;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.livraria.core.aplicacao.Resultado;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.venda.Pagamento;
import br.com.livraria.dominio.venda.PagamentoCartaoCredito;
import br.com.livraria.dominio.venda.Pedido;
import br.com.livraria.dominio.venda.ProcessarMeioPagamento;

public class AddValorCartaoViewHelper implements IViewHelper {

	@Override
	public EntidadeDominio getEntidade(HttpServletRequest request) {
		PagamentoCartaoCredito pagamentoCartaoCredito = (PagamentoCartaoCredito) request.getSession().getAttribute("pagamentoCartaoCredito");
		Pedido carrinho = (Pedido) request.getSession().getAttribute("carrinho");
		String valorPagamento = request.getParameter("txtValorPagamento");
		if(valorPagamento != null && !valorPagamento.trim().isEmpty()) {
			pagamentoCartaoCredito.setValor(Double.parseDouble(valorPagamento));
		}
		if(carrinho.getPagamento() == null) {
			Pagamento pagamento = new Pagamento();
			List<PagamentoCartaoCredito> pagamentos = new ArrayList<>();
			pagamentos.add(pagamentoCartaoCredito);
			pagamento.setPagamentosCartao(pagamentos);
			carrinho.setPagamento(pagamento);
		} else {
			carrinho.getPagamento().getPagamentosCartao().add(pagamentoCartaoCredito);
		}
		
		ProcessarMeioPagamento processarMeioPagamento = new ProcessarMeioPagamento();
		processarMeioPagamento.setCarrinho(carrinho);
		
		return processarMeioPagamento;
	
	}

	@Override
	public void setView(HttpServletRequest request, HttpServletResponse response, Resultado resultado)
			throws Exception {
		RequestDispatcher d = null;
		
		if(resultado != null && resultado.getMensagem() != null) {
			request.setAttribute("mensagem", resultado.getMensagem());
			d = request.getRequestDispatcher("/pages/FormAddPagamentoCartao.jsp");
		} else {
			ProcessarMeioPagamento processarMeioPagamento = (ProcessarMeioPagamento) resultado.getEntidades().get(0);
			request.getSession().setAttribute("carrinho", processarMeioPagamento.getCarrinho());
			d = request.getRequestDispatcher("/pages/ContinuarComprando.jsp");
		}
		d.forward(request, response);

	}

}
