package br.com.livraria.view.command;

import br.com.livraria.core.IFachada;
import br.com.livraria.core.controle.Fachada;

public abstract class AbstractCommand implements ICommand {

	protected IFachada fachada = new Fachada();

}
