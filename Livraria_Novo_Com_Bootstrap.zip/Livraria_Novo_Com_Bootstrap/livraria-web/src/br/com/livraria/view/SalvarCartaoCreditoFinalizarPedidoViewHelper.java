package br.com.livraria.view;

import java.text.SimpleDateFormat;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.livraria.core.aplicacao.Resultado;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.cliente.CartaoCredito;
import br.com.livraria.dominio.cliente.Cidade;
import br.com.livraria.dominio.cliente.Cliente;
import br.com.livraria.dominio.cliente.Endereco;
import br.com.livraria.dominio.cliente.Estado;
import br.com.livraria.dominio.cliente.Logradouro;
import br.com.livraria.dominio.cliente.Pais;
import br.com.livraria.dominio.cliente.TipoLogradouro;
import br.com.livraria.dominio.cliente.TipoResidencia;

public class SalvarCartaoCreditoFinalizarPedidoViewHelper implements IViewHelper {

	@Override
	public EntidadeDominio getEntidade(HttpServletRequest request) {
		CartaoCredito cartaoCredito = new CartaoCredito();
		String idCartaoCredito = request.getParameter("txtIdCartaoCredito");
		String numero = request.getParameter("txtNumCartao");
		String nome = request.getParameter("txtNomeCartao");
		String codigoSeguranca = request.getParameter("txtCodSeguranca");
		String dtVencimento = request.getParameter("txtDtVencimento");
		String primario = request.getParameter("checkPrimario");

		if(primario!= null && primario.equals("primario"))
			cartaoCredito.setPrimario(true);
		else
			cartaoCredito.setPrimario(false);
		
		if(idCartaoCredito != null && !idCartaoCredito.trim().isEmpty())	
			cartaoCredito.setId(Integer.parseInt(idCartaoCredito));	
		  
		cartaoCredito.setCliente((Cliente)request.getSession().getAttribute("cliente"));
		 
		cartaoCredito.setNumero(numero);
		cartaoCredito.setNome(nome);
		cartaoCredito.setCodigoSeguranca(codigoSeguranca);
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		
		try {
			if(!dtVencimento.isEmpty())
				cartaoCredito.setDtVencimento(sdf.parse(dtVencimento));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return cartaoCredito;
	}

	@Override
	public void setView(HttpServletRequest request, HttpServletResponse response, Resultado resultado)
			throws Exception {
		if(resultado != null && resultado.getMensagem()!= null) {
			request.setAttribute("mensagem", resultado.getMensagem());
		
		}else {
			request.setAttribute("mensagem", "Cart�o de cr�dito cadastrado com sucesso!");
			Cliente cliente = (Cliente)request.getSession().getAttribute("cliente");
			cliente.getCartoesCredito().add((CartaoCredito)resultado.getEntidades().get(0));
			request.getSession().setAttribute("cliente", cliente);
			
		}
		
		request.getRequestDispatcher("/pages/ContinuarComprando.jsp").forward(request, response);
		
	}

}
