package br.com.livraria.view;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.livraria.core.aplicacao.Resultado;
import br.com.livraria.dominio.EntidadeDominio;

public interface IViewHelper {
	
	// Requisi��es https
	public EntidadeDominio getEntidade(HttpServletRequest request);
	// entrega de volta a resposta para a p�gina, mensagens de resultado...
	public void setView(HttpServletRequest request, HttpServletResponse response, Resultado resultado) throws Exception; 

}
