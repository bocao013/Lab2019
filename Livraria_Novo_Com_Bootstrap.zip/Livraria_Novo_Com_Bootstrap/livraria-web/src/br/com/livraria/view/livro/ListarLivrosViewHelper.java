package br.com.livraria.view.livro;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.livraria.core.aplicacao.Resultado;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.livro.Livro;
import br.com.livraria.view.IViewHelper;

public class ListarLivrosViewHelper implements IViewHelper {
	
	public EntidadeDominio getEntidade(HttpServletRequest request) {
		
		return new Livro();
	}

	public void setView(HttpServletRequest request, HttpServletResponse response, Resultado resultado)
			throws Exception {
		request.setAttribute("livros", resultado.getEntidades());
		RequestDispatcher d = request.getRequestDispatcher("/pages/TelaLivros.jsp");
		d.forward(request, response);
	}

}
