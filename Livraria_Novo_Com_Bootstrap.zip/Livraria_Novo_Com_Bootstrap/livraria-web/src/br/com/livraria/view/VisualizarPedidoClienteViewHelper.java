package br.com.livraria.view;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sun.jna.IntegerType;

import br.com.livraria.core.aplicacao.Resultado;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.venda.Pedido;

public class VisualizarPedidoClienteViewHelper implements IViewHelper {

	@Override
	public EntidadeDominio getEntidade(HttpServletRequest request) {
		Pedido pedido = new Pedido();
		pedido.setId(Integer.parseInt(request.getParameter("idPedido")));
		
		return pedido;
	}

	@Override
	public void setView(HttpServletRequest request, HttpServletResponse response, Resultado resultado)
			throws Exception {
		if(resultado != null && resultado.getEntidades()!= null && !resultado.getEntidades().isEmpty()) {
			request.setAttribute("pedido", resultado.getEntidades().get(0));
		}
		request.getRequestDispatcher("/pages/VisualizarPedidoClienteAdmin.jsp").forward(request, response); 
		

	}

}
