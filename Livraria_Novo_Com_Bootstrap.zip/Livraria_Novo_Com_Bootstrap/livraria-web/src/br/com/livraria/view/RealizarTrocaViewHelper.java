package br.com.livraria.view;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.livraria.core.aplicacao.Resultado;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.cliente.Cliente;
import br.com.livraria.dominio.venda.ItemPedido;
import br.com.livraria.dominio.venda.Pedido;
import br.com.livraria.dominio.venda.RealizarTroca;
import br.com.livraria.dominio.venda.SolicitarTroca;

public class RealizarTrocaViewHelper implements IViewHelper {

	@Override
	public EntidadeDominio getEntidade(HttpServletRequest request) {
		RealizarTroca realizarTroca = new RealizarTroca();
		Pedido pedidoTroca = new Pedido();
		pedidoTroca.setId(Integer.parseInt(request.getParameter("idPedido")));
		realizarTroca.setPedidoTroca(pedidoTroca);

		return realizarTroca;

	}

	@Override
	public void setView(HttpServletRequest request, HttpServletResponse response, Resultado resultado)
			throws Exception {
		if (resultado != null && resultado.getMensagem() != null) {
			request.setAttribute("mensagem", resultado.getMensagem());
		} else {
			RealizarTroca trocaRealizada = (RealizarTroca) resultado.getEntidades().get(0);
			request.setAttribute("mensagem", String.format(
					"Troca realizada com sucesso! Itens retornados para o estoque. Gerado cupom %s no valor de %.2f",
					trocaRealizada.getCupomGerado().getNome(), trocaRealizada.getCupomGerado().getValorDesconto()));
				
		}
		request.getRequestDispatcher("ListarPedido?operacao=consultar").forward(request, response);

	}

}
