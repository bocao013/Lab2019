package br.com.livraria.view.livro;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.livraria.core.aplicacao.Resultado;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.livro.Livro;
import br.com.livraria.dominio.venda.ItemEstoque;
import br.com.livraria.view.IViewHelper;

public class ConsultarLivroLojaViewHelper implements IViewHelper {

	@Override
	public EntidadeDominio getEntidade(HttpServletRequest request) {
		Livro livro = new Livro();
		String txtConsulta = request.getParameter("txtConsulta");
		livro.setCodigo(txtConsulta);
		ItemEstoque itemEstoque = new ItemEstoque();
		itemEstoque.setLivro(livro);
		return itemEstoque;
	}

	@Override
	public void setView(HttpServletRequest request, HttpServletResponse response, Resultado resultado)
			throws Exception {
		
		request.setAttribute("itensEstoque", resultado.getEntidades());
	
		request.getRequestDispatcher("/pages/LojaIndex.jsp").forward(request, response);
	}

}