package br.com.livraria.view;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.livraria.core.aplicacao.Resultado;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.Usuario;
import br.com.livraria.dominio.cliente.Cliente;
import br.com.livraria.dominio.venda.ItemPedido;
import br.com.livraria.dominio.venda.Pedido;
import br.com.livraria.dominio.venda.SolicitarTroca;

public class SolicitarTrocaViewHelper implements IViewHelper{

	@Override
	public EntidadeDominio getEntidade(HttpServletRequest request) {
		SolicitarTroca solicitarTroca = new SolicitarTroca();
		Pedido pedidoTroca = new Pedido();
		String [] itensTroca = request.getParameterValues("itemTroca");
		List<ItemPedido> itensPedido = new ArrayList<>();
		if(itensTroca != null) {
			for(String itemTroca: itensTroca) {
				ItemPedido itemPedido = new ItemPedido();
				itemPedido.setId(Integer.parseInt(itemTroca));
				itensPedido.add(itemPedido);
			}
		}
		pedidoTroca.setItems(itensPedido);
		pedidoTroca.setId(Integer.parseInt(request.getParameter("idPedido")));
		solicitarTroca.setPedidoTroca(pedidoTroca);
		solicitarTroca.setClienteLogado((Cliente) request.getSession().getAttribute("cliente"));
		return solicitarTroca;
	}

	@Override
	public void setView(HttpServletRequest request, HttpServletResponse response, Resultado resultado)
			throws Exception {
		RequestDispatcher rd = null;
		if(resultado != null && resultado.getMensagem()!= null){
			request.setAttribute("mensagem", resultado.getMensagem());
			rd = request.getRequestDispatcher("CarregarTelaTroca?idPedido="+request.getParameter("idPedido")+"&operacao=consultar");
		} else {			
			request.setAttribute("mensagem", "Troca solicitada com sucesso! Acompanhe o status no seu perfil");
			rd = request.getRequestDispatcher("/pages/PerfilCliente.jsp");
		}
		rd.forward(request, response); 
		
	}

}
