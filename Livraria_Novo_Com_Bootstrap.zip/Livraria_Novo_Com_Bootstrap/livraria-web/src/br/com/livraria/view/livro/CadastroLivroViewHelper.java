package br.com.livraria.view.livro;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.livraria.core.aplicacao.Resultado;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.livro.Categoria;
import br.com.livraria.dominio.livro.Dimensoes;
import br.com.livraria.dominio.livro.Editora;
import br.com.livraria.dominio.livro.GrupoLivro;
import br.com.livraria.dominio.livro.ISBN;
import br.com.livraria.dominio.livro.Livro;
import br.com.livraria.dominio.livro.SubCategoria;
import br.com.livraria.view.IViewHelper;

public class CadastroLivroViewHelper implements IViewHelper {

	public EntidadeDominio getEntidade(HttpServletRequest request) {
		Livro livro = new Livro();
		String idLivro = request.getParameter("txtIdLivro");
		String codigo = request.getParameter("txtCodigo");
		String autor = request.getParameter("txtAutor");
		String titulo = request.getParameter("txtTitulo");
		String ano = request.getParameter("txtAno");
		String edicao = request.getParameter("txtEdicao");
		String numPaginas = request.getParameter("txtNumPaginas");
		String sinopse = request.getParameter("txtSinopse");
		String ativo = request.getParameter("checkAtivo");
		String nomeEditora = request.getParameter("txtEditora");
		String[] idsCategoria = request.getParameterValues("categoria");
		String[] idsSubCategoria = request.getParameterValues("subcategoria");
		String altura = request.getParameter("txtAltura");
		String largura = request.getParameter("txtLargura");
		String peso = request.getParameter("txtPeso");
		String profundidade = request.getParameter("txtProfundidade");
		String codigoIsbn = request.getParameter("txtIsbn");
		String idGrupoLivro = request.getParameter("grupoLivro");
		String preco = request.getParameter("txtPreco");
		
		if(ativo!= null && ativo.equals("ativo"))
			livro.setAtivo(true);
		else
			livro.setAtivo(false);
		
		if(idLivro != null && !idLivro.trim().isEmpty())	
			livro.setId(Integer.parseInt(idLivro));
		
		livro.setCodigo(codigo);
		livro.setAutor(autor);
		livro.setTitulo(titulo);
		livro.setAno(ano);
		livro.setEdicao(edicao);
		livro.setNumeroPaginas(numPaginas);
		livro.setSinopse(sinopse);
		
		if(preco != null)
			livro.setPreco(Double.valueOf(preco));
	
		Editora editora = new Editora();
		editora.setNome(nomeEditora);
		livro.setEditora(editora);
		
		Dimensoes dimensoes = new Dimensoes();
		if(altura != null && !altura.trim().isEmpty())
			dimensoes.setAltura(Double.valueOf(altura));
		
		if(largura != null && !largura.trim().isEmpty())
			dimensoes.setLargura(Double.valueOf(largura));
		
		if(peso != null && !peso.trim().isEmpty())
			dimensoes.setPeso(Double.valueOf(peso));
		
		if(profundidade != null && !profundidade.trim().isEmpty())
			dimensoes.setProfundidade(Double.valueOf(profundidade));
	
		livro.setDimensoes(dimensoes);
		
		ISBN isbn = new ISBN();
		isbn.setCodigoBarras(codigoIsbn);
		livro.setIsbn(isbn);
		
		List<Categoria> categoriasLivro = new ArrayList<>();
		if(idsCategoria != null && idsCategoria.length > 0){
			for(String idCategoria: idsCategoria){
				Categoria categoria = new Categoria();
				categoria.setId(Integer.parseInt(idCategoria));
				categoriasLivro.add(categoria);
			}
		}
		livro.setCategorias(categoriasLivro);
	
		List<SubCategoria> subCategoriasLivro = new ArrayList<>();
		if(idsSubCategoria != null && idsSubCategoria.length > 0){
			for(String idSubCategoria: idsSubCategoria){
				SubCategoria subCategoria = new SubCategoria();
				subCategoria.setId(Integer.parseInt(idSubCategoria));
				subCategoriasLivro.add(subCategoria);
			}
		}
		livro.setSubCategorias(subCategoriasLivro);
		
		GrupoLivro grupoLivro = new GrupoLivro();
		if(idGrupoLivro != null && !idGrupoLivro.isEmpty())
			grupoLivro.setId(Integer.parseInt(idGrupoLivro));
		livro.setGrupolivro(grupoLivro);
		
		return livro;
	}

	public void setView(HttpServletRequest request, HttpServletResponse response, Resultado resultado)
			throws Exception {
		RequestDispatcher d = null;
		String operacao = request.getParameter("operacao");
		if(operacao != null){
			if (operacao.equals("salvar"))
				operacao = "cadastrado";
			if(operacao.equals("alterar"))
				operacao = "alterado";
		}
		if( resultado != null && resultado.getMensagem() == null){
			request.setAttribute("mensagem", "Livro "+operacao+" com sucesso!");
			d = request.getRequestDispatcher("ListarLivro?operacao=consultar");
		}
		else if (resultado.getMensagem() != null) {
			request.setAttribute("mensagem", resultado.getMensagem());
			d = request.getRequestDispatcher("/pages/FormLivro.jsp");
		}
		
		d.forward(request, response);
	}

}
