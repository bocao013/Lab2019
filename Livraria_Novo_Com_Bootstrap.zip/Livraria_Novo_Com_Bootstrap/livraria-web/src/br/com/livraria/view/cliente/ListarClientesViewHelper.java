package br.com.livraria.view.cliente;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.livraria.core.aplicacao.Resultado;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.cliente.Cliente;
import br.com.livraria.view.IViewHelper;

public class ListarClientesViewHelper implements IViewHelper {
	
	public EntidadeDominio getEntidade(HttpServletRequest request) {
		
		return new Cliente();
	}

	public void setView(HttpServletRequest request, HttpServletResponse response, Resultado resultado)
			throws Exception {
		request.setAttribute("clientes", resultado.getEntidades());
		RequestDispatcher d = request.getRequestDispatcher("/pages/TelaClientes.jsp");
		d.forward(request, response);
	}

}
