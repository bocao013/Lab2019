package br.com.livraria.view;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.livraria.core.aplicacao.Resultado;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.venda.ItemEstoque;

public class IndexViewHelper implements IViewHelper {

	public EntidadeDominio getEntidade(HttpServletRequest request) {
		
		return new ItemEstoque();
	}

	@Override
	public void setView(HttpServletRequest request, HttpServletResponse response, Resultado resultado)
			throws Exception {
		request.setAttribute("itensEstoque", resultado.getEntidades());
		request.getRequestDispatcher("/pages/LojaIndex.jsp").forward(request, response);

	}

}
