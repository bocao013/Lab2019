package br.com.livraria.view;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.livraria.core.aplicacao.Resultado;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.venda.Pedido;

public class VisualizarCarrinhoViewHelper implements IViewHelper {

	@Override
	public EntidadeDominio getEntidade(HttpServletRequest request) {
		
		return (Pedido)request.getSession().getAttribute("carrinho");
	}

	@Override
	public void setView(HttpServletRequest request, HttpServletResponse response, Resultado resultado)
			throws Exception {
		if(resultado != null && resultado.getEntidades()!= null && !resultado.getEntidades().isEmpty()) {
			request.getSession().setAttribute("carrinho", resultado.getEntidades().get(0));
		}
		request.getRequestDispatcher("/pages/Carrinho.jsp").forward(request, response);
		

	}

}
