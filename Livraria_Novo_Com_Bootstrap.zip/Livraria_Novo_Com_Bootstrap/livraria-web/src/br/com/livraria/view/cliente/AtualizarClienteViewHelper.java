package br.com.livraria.view.cliente;

import java.text.SimpleDateFormat;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.livraria.core.aplicacao.Resultado;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.cliente.Cliente;
import br.com.livraria.dominio.cliente.Telefone;
import br.com.livraria.dominio.cliente.TipoTelefone;
import br.com.livraria.view.IViewHelper;

public class AtualizarClienteViewHelper implements IViewHelper {

	public EntidadeDominio getEntidade(HttpServletRequest request) {
		Cliente cliente = new Cliente();
		String ativo = request.getParameter("checkAtivo");
		String idCliente = request.getParameter("txtIdCliente");
		String codigo = request.getParameter("txtCodigo");
		String genero = request.getParameter("txtGenero");
		String nome = request.getParameter("txtNome");
		String dtNascimento = request.getParameter("txtDtNascimento");
		String email = request.getParameter("txtEmail");
		String cpf = request.getParameter("txtCpf");
		String idTelefone = request.getParameter("txtIdTelefone");
		String numeroTelefone = request.getParameter("txtTelefone");
		String ddd = request.getParameter("txtDdd");
		String idIipoTelefone = request.getParameter("tipoTelefone");
		String senha = request.getParameter("txtSenha");
		String confirmacaoSenha = request.getParameter("txtConfirmacaoSenha");
		

		if(ativo!= null && ativo.equals("ativo"))
			cliente.setAtivo(true);
		else
			cliente.setAtivo(false);
		
		if(idCliente != null && !idCliente.trim().isEmpty())	
			cliente.setId(Integer.parseInt(idCliente));
		
		cliente.setCodigo(codigo);
		cliente.setGenero(genero);
		cliente.setNome(nome);
		cliente.setRanking(0);
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		
		try {
			if(!dtNascimento.isEmpty())
				cliente.setDtNascimento(sdf.parse(dtNascimento));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		cliente.setEmail(email);
		cliente.setCpf(cpf);
		cliente.setSenha(senha);
		cliente.setConfirmacaoSenha(confirmacaoSenha);
		
		TipoTelefone tipoTelefone = new TipoTelefone();
		
		if(idIipoTelefone != null && !idIipoTelefone.trim().isEmpty())	
			tipoTelefone.setId(Integer.parseInt(idIipoTelefone));
		
		Telefone telefone = new Telefone();
		
		if(idTelefone != null && !idTelefone.trim().isEmpty())	
			telefone.setId(Integer.parseInt(idTelefone));
		
		telefone.setNumero(numeroTelefone);
		telefone.setDdd(ddd);
		telefone.setTipoTelefone(tipoTelefone);
		
		cliente.setTelefone(telefone);
			
		return cliente;
	}

	public void setView(HttpServletRequest request, HttpServletResponse response, Resultado resultado)
			throws Exception {
		RequestDispatcher d = null;
		String msg = "";
		String operacao = request.getParameter("operacao");
		if(operacao != null){
			if (operacao.equals("salvar"))
				 msg = "cadastrado";
			if(operacao.equals("alterar"))
				msg = "alterado";
		}
		if( resultado != null && resultado.getMensagem() == null){
			Cliente cliente = (Cliente)resultado.getEntidades().get(0);
			request.setAttribute("mensagem", "Cliente "+msg+" com sucesso!");
			request.getSession().setAttribute("cliente", cliente);
			d = request.getRequestDispatcher("DetalharCliente?operacao=consultar&id="+cliente.getId());
		}
		else if (resultado.getMensagem() != null) {
			
			Cliente cliente = (Cliente)resultado.getEntidades().get(0);
			request.setAttribute("mensagem", resultado.getMensagem());
			if(operacao.equals("alterar")) {
				request.setAttribute("cliente", cliente);
				d = request.getRequestDispatcher("/pages/AtualizarCliente.jsp");
			}
			if(operacao.equalsIgnoreCase("salvar")) {
				
				d = request.getRequestDispatcher("/pages/AtualizarCliente.jsp");
			}
			
		}
		
		d.forward(request, response);
	}

}
