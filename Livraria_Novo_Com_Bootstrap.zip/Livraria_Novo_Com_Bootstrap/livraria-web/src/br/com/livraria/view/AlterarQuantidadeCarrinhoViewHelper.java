package br.com.livraria.view;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.livraria.core.aplicacao.Resultado;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.livro.Livro;
import br.com.livraria.dominio.venda.ItemPedido;
import br.com.livraria.dominio.venda.Pedido;

public class AlterarQuantidadeCarrinhoViewHelper implements IViewHelper {

	@Override
	public EntidadeDominio getEntidade(HttpServletRequest request) {
		String id = request.getParameter("id");
		String acao = request.getParameter("acao");
		
		Pedido carrinho = (Pedido)request.getSession().getAttribute("carrinho");
		
		// remover item do carrinho
		if(acao.equals("subQtde")) {
			for(ItemPedido itemCarrinho: carrinho.getItems()) {
				if(itemCarrinho.getLivro().getId().equals(Integer.parseInt(id))) {
					itemCarrinho.setQuantidade(itemCarrinho.getQuantidade() - 1);
					if(itemCarrinho.getQuantidade() == 0) {
						carrinho.getItems().remove(itemCarrinho);
					}
					request.getSession().setAttribute("carrinho", carrinho); // atualizar a sess�o
					return null;
				}
			}	
		}
		
		// add item no carrinho
		if(acao.equals("addQtde")) {
			for(ItemPedido itemCarrinho: carrinho.getItems()) {
				if(itemCarrinho.getLivro().getId().equals(Integer.parseInt(id))) {
					
					
					return itemCarrinho;
				}
			}	
		}
				
		request.getSession().setAttribute("carrinho", carrinho);
				
		return null;	
	}

	@Override
	public void setView(HttpServletRequest request, HttpServletResponse response, Resultado resultado)
			throws Exception {
		String acao = request.getParameter("acao");
		Pedido carrinho = (Pedido)request.getSession().getAttribute("carrinho");
		
		if(resultado != null && resultado.getMensagem() != null) {
			request.setAttribute("mensagem", resultado.getMensagem());
			request.getRequestDispatcher("/pages/Carrinho.jsp").forward(request, response);
			return;
		}

		if(acao.equals("addQtde")) {
			ItemPedido itemPedido = (ItemPedido) resultado.getEntidades().get(0);
			for(ItemPedido itemCarrinho: carrinho.getItems()) {
				if(itemCarrinho.getLivro().getId().equals(itemPedido.getLivro().getId())) {
					itemCarrinho.setQuantidade( itemCarrinho.getQuantidade() + 1);
					request.getSession().setAttribute("carrinho", carrinho);
				}
			}	
		}
		
		request.getRequestDispatcher("/pages/Carrinho.jsp").forward(request, response);

	}

}
