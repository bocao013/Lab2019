package br.com.livraria.view.cartao;

import java.text.SimpleDateFormat;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.livraria.core.aplicacao.Resultado;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.cliente.CartaoCredito;

import br.com.livraria.dominio.cliente.Cliente;
import br.com.livraria.view.IViewHelper;

public class SalvarCartaoCreditoViewHelper implements IViewHelper {

	public EntidadeDominio getEntidade(HttpServletRequest request) {
		CartaoCredito cartaoCredito = new CartaoCredito();
		String idCliente = request.getParameter("txtIdCliente");
		String idCartaoCredito = request.getParameter("txtIdCartaoCredito");
		String numeroCartao = request.getParameter("txtNumCartao");
		String nomeCartao = request.getParameter("txtNomeCartao");
		String codSeguranca = request.getParameter("txtCodSeguranca");
		String dtVencimento = request.getParameter("txtDtVencimento");
		String primario = request.getParameter("checkPrimario");

		if(primario!= null && primario.equals("primario"))
			cartaoCredito.setPrimario(true);
		else
			cartaoCredito.setPrimario(false);
		
		if(idCartaoCredito != null && !idCartaoCredito.trim().isEmpty())	
			cartaoCredito.setId(Integer.parseInt(idCartaoCredito));
		
		Cliente cliente = new Cliente();
		if(idCliente != null && !idCliente.trim().isEmpty())	
			cliente.setId(Integer.parseInt(idCliente));
		
		cartaoCredito.setCliente(cliente);
		
		cartaoCredito.setNumero(numeroCartao);
		cartaoCredito.setNome(nomeCartao);
		cartaoCredito.setCodigoSeguranca(codSeguranca);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		
		try {
			if(!dtVencimento.isEmpty())
				cartaoCredito.setDtVencimento(sdf.parse(dtVencimento));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return cartaoCredito;
	}

	public void setView(HttpServletRequest request, HttpServletResponse response, Resultado resultado)
			throws Exception {
		RequestDispatcher d = null;
		String msg = "";
		String operacao = request.getParameter("operacao");
		if(operacao != null){
			if (operacao.equals("salvar"))
				 msg = "cadastrado";
			if(operacao.equals("alterar"))
				msg = "alterado";
		}
		if( resultado != null && resultado.getMensagem() == null){
			CartaoCredito cartaoCredito = (CartaoCredito)resultado.getEntidades().get(0);
			request.setAttribute("mensagem", "Cart�o de cr�dito "+msg+" com sucesso!");
			
			Cliente cliente = (Cliente) request.getSession().getAttribute("cliente");
			cliente.getCartoesCredito().add(cartaoCredito);
			request.getSession().setAttribute("cliente", cliente);
			
			d = request.getRequestDispatcher("DetalharCliente?operacao=consultar&id="+cartaoCredito.getCliente().getId());
		}
		else if (resultado.getMensagem() != null) {
			
			CartaoCredito cartaoCredito = (CartaoCredito)resultado.getEntidades().get(0);
			request.setAttribute("mensagem", resultado.getMensagem());
			request.setAttribute("idCliente", cartaoCredito.getCliente().getId().toString());
			if(operacao.equals("alterar")) {
				request.setAttribute("cartaoCredito", cartaoCredito);
				d = request.getRequestDispatcher("/pages/FormCartaoCredito.jsp");
			}
			if(operacao.equalsIgnoreCase("salvar")) {
				
				d = request.getRequestDispatcher("/pages/FormCartaoCredito.jsp");
			}
			
		}
		
		d.forward(request, response);
	}

}
