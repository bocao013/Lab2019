package br.com.livraria.view.cliente;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.livraria.core.aplicacao.Resultado;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.cliente.Cliente;
import br.com.livraria.dominio.venda.Pedido;
import br.com.livraria.view.IViewHelper;

public class LoginClienteViewHelper implements IViewHelper {

	@Override
	public EntidadeDominio getEntidade(HttpServletRequest request) {
		Cliente cliente = new Cliente();
		String email = request.getParameter("txtEmail");
		String senha = request.getParameter("txtSenha");
		
		cliente.setEmail(email);
		cliente.setSenha(senha);
		
		return cliente;
	}

	public void setView(HttpServletRequest request, HttpServletResponse response, Resultado resultado)
			throws Exception {
		RequestDispatcher d = null;
		if( resultado != null && resultado.getMensagem() == null){
			if(resultado.getEntidades() == null || resultado.getEntidades().isEmpty()) {
				request.setAttribute("mensagem", "Usu�rio n�o cadastrado ou senha inv�lida!");
				d = request.getRequestDispatcher("/pages/LoginCliente.jsp");
			} else {
				request.getSession().setAttribute("cliente", resultado.getEntidades().get(0));
				d = request.getRequestDispatcher("/LojaIndex?operacao=consultar");
			}
						
		}	
		else if(resultado.getMensagem() != null){
			request.setAttribute("mensagem", resultado.getMensagem());
			d = request.getRequestDispatcher("/pages/LoginCliente.jsp");
		}
		d.forward(request, response);
		
	}
}
