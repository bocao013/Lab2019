package br.com.livraria.view.cliente;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.livraria.core.aplicacao.Resultado;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.cliente.CartaoCredito;
import br.com.livraria.dominio.cliente.Cidade;
import br.com.livraria.dominio.cliente.Cliente;
import br.com.livraria.dominio.cliente.Endereco;
import br.com.livraria.dominio.cliente.Estado;
import br.com.livraria.dominio.cliente.Logradouro;
import br.com.livraria.dominio.cliente.Pais;
import br.com.livraria.dominio.cliente.Telefone;
import br.com.livraria.dominio.cliente.TipoLogradouro;
import br.com.livraria.dominio.cliente.TipoResidencia;
import br.com.livraria.dominio.cliente.TipoTelefone;
import br.com.livraria.view.IViewHelper;

public class CadastroClienteViewHelper implements IViewHelper {

	public EntidadeDominio getEntidade(HttpServletRequest request) {
		Cliente cliente = new Cliente();
		String ativo = request.getParameter("checkAtivo");
		String idCliente = request.getParameter("txtIdCliente");
		String codigo = request.getParameter("txtCodigo");
		String genero = request.getParameter("txtGenero");
		String nome = request.getParameter("txtNome");
		String dtNascimento = request.getParameter("txtDtNascimento");
		String email = request.getParameter("txtEmail");
		String cpf = request.getParameter("txtCpf");
		String idTelefone = request.getParameter("txtIdTelefone");
		String numeroTelefone = request.getParameter("txtTelefone");
		String ddd = request.getParameter("txtDdd");
		String idIipoTelefone = request.getParameter("tipoTelefone");
		String senha = request.getParameter("txtSenha");
		String confirmacaoSenha = request.getParameter("txtConfirmacaoSenha");
		String idTipoLogradouro = request.getParameter("tipoLogradouro");
		String idEndereco = request.getParameter("txtIdEndereco");
		String nomeLogradouro = request.getParameter("txtLogradouro");
		String numero = request.getParameter("txtNumero");
		String bairro = request.getParameter("txtBairro");
		String cep = request.getParameter("txtCep");
		String observacao = request.getParameter("txtObservacao");
		String idPais = request.getParameter("pais");
		String idEstado = request.getParameter("estado");
		String idCidade = request.getParameter("cidade");
		String idTipoResidencia = request.getParameter("tipoResidencia");
		String idCartaoCredito = request.getParameter("txtIdCartaoCredito");
		String numeroCartao = request.getParameter("txtNumCartao");
		String nomeCartao = request.getParameter("txtNomeCartao");
		String codSeguranca = request.getParameter("txtCodSeguranca");
		String dtVencimento = request.getParameter("txtDtVencimento");
		
		
		if(ativo!= null && ativo.equals("ativo"))
			cliente.setAtivo(true);
		else
			cliente.setAtivo(false);
		
		if(idCliente != null && !idCliente.trim().isEmpty())	
			cliente.setId(Integer.parseInt(idCliente));
		
		cliente.setCodigo(codigo);
		cliente.setGenero(genero);
		cliente.setNome(nome);
		cliente.setRanking(0);
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		
		try {
			if(!dtNascimento.isEmpty())
				cliente.setDtNascimento(sdf.parse(dtNascimento));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		cliente.setEmail(email);
		cliente.setCpf(cpf);
		cliente.setSenha(senha);
		cliente.setConfirmacaoSenha(confirmacaoSenha);
		
		TipoTelefone tipoTelefone = new TipoTelefone();
		
		if(idIipoTelefone != null && !idIipoTelefone.trim().isEmpty())	
			tipoTelefone.setId(Integer.parseInt(idIipoTelefone));
		
		Telefone telefone = new Telefone();
		
		if(idTelefone != null && !idTelefone.trim().isEmpty())	
			telefone.setId(Integer.parseInt(idTelefone));
		
		telefone.setNumero(numeroTelefone);
		telefone.setDdd(ddd);
		telefone.setTipoTelefone(tipoTelefone);
		
		cliente.setTelefone(telefone);
		
		TipoLogradouro tipoLogradouro = new TipoLogradouro();
		if(idTipoLogradouro != null && !idTipoLogradouro.trim().isEmpty())	
			tipoLogradouro.setId(Integer.parseInt(idTipoLogradouro));
		
		Endereco endereco = new Endereco();
		
		if(idEndereco != null && !idEndereco.trim().isEmpty())	
			endereco.setId(Integer.parseInt(idEndereco));
		
		
		endereco.setNumero(numero);
		endereco.setBairro(bairro);
		endereco.setCep(cep);
		endereco.setObservacao(observacao);
		
		Logradouro logradouro = new Logradouro();
		logradouro.setLogradouro(nomeLogradouro);
		logradouro.setTipoLogradouro(tipoLogradouro);
		
		
		Pais pais = new Pais();
		if(idPais != null && !idPais.trim().isEmpty())	
			pais.setId(Integer.parseInt(idPais));
		
		Estado estado = new Estado();
		if(idEstado != null && !idEstado.trim().isEmpty())	
			estado.setId(Integer.parseInt(idEstado));
		
		Cidade cidade = new Cidade();
		if(idCidade != null && !idCidade.trim().isEmpty())	
			cidade.setId(Integer.parseInt(idCidade));
		
		TipoResidencia tipoResidencia = new TipoResidencia();
		if(idTipoResidencia != null && !idTipoResidencia.trim().isEmpty())	
			tipoResidencia.setId(Integer.parseInt(idTipoResidencia));
		
		endereco.setLogradouro(logradouro);
		endereco.setPais(pais);
		endereco.setCidade(cidade);
		endereco.setTipoResidencia(tipoResidencia);
		endereco.setPrimario(true);
		
		List<Endereco> enderecos = new ArrayList<Endereco>();
		enderecos.add(endereco);
		cliente.setEnderecos(enderecos);
		
		CartaoCredito cartaoCredito = new CartaoCredito();
		
		if(idCartaoCredito != null && !idCartaoCredito.trim().isEmpty())	
			cartaoCredito.setId(Integer.parseInt(idCartaoCredito));
		
		cartaoCredito.setNumero(numeroCartao);
		cartaoCredito.setNome(nomeCartao);
		cartaoCredito.setCodigoSeguranca(codSeguranca);
		cartaoCredito.setPrimario(true);
		sdf = new SimpleDateFormat("yyyy-MM-dd");
		
		try {
			if(!dtVencimento.isEmpty())
				cartaoCredito.setDtVencimento(sdf.parse(dtVencimento));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		List<CartaoCredito> cartaoCreditos = new ArrayList<CartaoCredito>();
		cartaoCreditos.add(cartaoCredito);
		cliente.setCartoesCredito(cartaoCreditos);
		
		return cliente;
	}

	public void setView(HttpServletRequest request, HttpServletResponse response, Resultado resultado)
			throws Exception {
		RequestDispatcher d = null;
		String operacao = request.getParameter("operacao");
		if(operacao != null){
			if (operacao.equals("salvar"))
				operacao = "cadastrado";
			if(operacao.equals("alterar"))
				operacao = "alterado";
		}
		if( resultado != null && resultado.getMensagem() == null){
			request.setAttribute("mensagem", "Cliente "+operacao+" com sucesso!");
			d = request.getRequestDispatcher("LojaIndex?operacao=consultar");
		}
		else if (resultado.getMensagem() != null) {
			request.setAttribute("mensagem", resultado.getMensagem());
			d = request.getRequestDispatcher("/pages/FormCliente.jsp");
		}
		
		d.forward(request, response);
	}

}
