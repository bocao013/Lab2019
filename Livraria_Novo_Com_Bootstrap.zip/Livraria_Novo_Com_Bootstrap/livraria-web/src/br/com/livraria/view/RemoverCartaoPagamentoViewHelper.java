package br.com.livraria.view;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.livraria.core.aplicacao.Resultado;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.venda.Pedido;
import br.com.livraria.dominio.venda.RemoverCartaoPagamento;

public class RemoverCartaoPagamentoViewHelper implements IViewHelper {

	@Override
	public EntidadeDominio getEntidade(HttpServletRequest request) {
		RemoverCartaoPagamento removerCartaoPagamento = new RemoverCartaoPagamento();
		removerCartaoPagamento.setCarrinho((Pedido) request.getSession().getAttribute("carrinho"));
		removerCartaoPagamento.setIdCartaoRemover(Integer.parseInt(request.getParameter("idCartao")));
		
		return removerCartaoPagamento;
	}

	@Override
	public void setView(HttpServletRequest request, HttpServletResponse response, Resultado resultado)
			throws Exception {
		RemoverCartaoPagamento removerCartaoPagamento = (RemoverCartaoPagamento) resultado.getEntidades().get(0);
		request.getSession().setAttribute("carrinho", removerCartaoPagamento.getCarrinho());
		resultado.setMensagem("Pagamento removido com sucesso!");
		request.getRequestDispatcher("/pages/ContinuarComprando.jsp").forward(request, response);

	}

}
