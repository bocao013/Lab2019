package br.com.livraria.view;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.livraria.core.aplicacao.Resultado;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.venda.Pedido;
import br.com.livraria.dominio.venda.StatusPedido;

public class ListarPedidosViewHelper implements IViewHelper {
	
	public EntidadeDominio getEntidade(HttpServletRequest request) {
		Pedido pedido = new Pedido();
		String statusFiltro = request.getParameter("statusFiltro");
		if(statusFiltro != null) {
			StatusPedido statusPedido = new StatusPedido();
			statusPedido.setId(Integer.parseInt(statusFiltro));
			pedido.setStatusPedido(statusPedido);
		}
		return pedido;
	}

	public void setView(HttpServletRequest request, HttpServletResponse response, Resultado resultado)
			throws Exception {
		/*String mensagem = (String) request.getAttribute("mensagem");
		if(mensagem != null && ! mensagem.isEmpty()) {
			request.setAttribute("mensagem", mensagem);
		}*/
		request.setAttribute("pedidos", resultado.getEntidades());
		RequestDispatcher d = request.getRequestDispatcher("/pages/TelaPedidos.jsp");
		d.forward(request, response);
	}

}
