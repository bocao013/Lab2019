package br.com.livraria.view;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.livraria.core.aplicacao.Resultado;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.Usuario;

public class PortalAdminViewHelper implements IViewHelper {

	public EntidadeDominio getEntidade(HttpServletRequest request) {			
		return null;
	}

	public void setView(HttpServletRequest request, HttpServletResponse response, Resultado resultado)
			throws Exception {
	
			request.getRequestDispatcher("/pages/Login.jsp").forward(request, response);
		
	}

}
