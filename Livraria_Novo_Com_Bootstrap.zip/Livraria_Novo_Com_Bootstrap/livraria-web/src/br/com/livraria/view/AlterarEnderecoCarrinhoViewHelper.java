package br.com.livraria.view;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.livraria.core.aplicacao.Resultado;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.cliente.Endereco;
import br.com.livraria.dominio.venda.AlterarEnderecoCarrinho;
import br.com.livraria.dominio.venda.Pedido;

public class AlterarEnderecoCarrinhoViewHelper implements IViewHelper {

	@Override
	public EntidadeDominio getEntidade(HttpServletRequest request) {
		String idEndereco = request.getParameter("idEndereco");
		Endereco endereco = new Endereco();
		endereco.setId(Integer.parseInt(idEndereco));
		
		
		AlterarEnderecoCarrinho alterarEnderecoCarrinho = new AlterarEnderecoCarrinho();
		Pedido carrinho = (Pedido) request.getSession().getAttribute("carrinho");
		carrinho.setEndereco(endereco);
		alterarEnderecoCarrinho.setCarrinho(carrinho);
		
		return alterarEnderecoCarrinho;
	}

	@Override
	public void setView(HttpServletRequest request, HttpServletResponse response, Resultado resultado)
			throws Exception {
		AlterarEnderecoCarrinho alterarEnderecoCarrinho = (AlterarEnderecoCarrinho) resultado.getEntidades().get(0);
		request.getSession().setAttribute("carrinho", alterarEnderecoCarrinho.getCarrinho());
		request.getRequestDispatcher("/pages/Carrinho.jsp").forward(request, response);

	}

}
