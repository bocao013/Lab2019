package br.com.livraria.view;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.livraria.core.aplicacao.Resultado;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.venda.Cupom;
import br.com.livraria.dominio.venda.CupomTroca;
import br.com.livraria.dominio.venda.Pedido;
import br.com.livraria.dominio.venda.ValidarCupom;

public class ValidarCupomViewHelper implements IViewHelper {

	@Override
	public EntidadeDominio getEntidade(HttpServletRequest request) {
		ValidarCupom validarCupom = new ValidarCupom();
		Cupom cupom = new Cupom();
		CupomTroca cupomTroca = new CupomTroca();
		cupom.setNome(request.getParameter("txtCupom"));
		cupomTroca.setNome(request.getParameter("txtCupom"));
		validarCupom.setCupom(cupom);
		validarCupom.setCupomTroca(cupomTroca);
		validarCupom.setCarrinho((Pedido) request.getSession().getAttribute("carrinho"));
		
		return validarCupom;
	}

	@Override
	public void setView(HttpServletRequest request, HttpServletResponse response, Resultado resultado)
			throws Exception {
		if(resultado.getMensagem() == null) {
			request.setAttribute("mensagem", "Cupom utilizado com sucesso!");
			ValidarCupom validarCupom = (ValidarCupom) resultado.getEntidades().get(0);
			request.getSession().setAttribute("carrinho", validarCupom.getCarrinho());
		} else {
			request.setAttribute("mensagem", "Cupom n�o encontrado");
			
		}
		request.getRequestDispatcher("/pages/ContinuarComprando.jsp").forward(request, response);
		
	}

}
