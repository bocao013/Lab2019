package br.com.livraria.view.cliente;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.livraria.core.aplicacao.Resultado;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.cliente.Cliente;
import br.com.livraria.view.IViewHelper;

public class DetalharClienteViewHelper implements IViewHelper {

	public EntidadeDominio getEntidade(HttpServletRequest request) {
		
		Cliente cliente = new Cliente();
		String idCliente = request.getParameter("id");
		if(idCliente != null)
			cliente.setId(Integer.valueOf(idCliente));
		return cliente;
	}

	public void setView(HttpServletRequest request, HttpServletResponse response, Resultado resultado)
			throws Exception {
		request.setAttribute("cliente", resultado.getEntidades().get(0));
		RequestDispatcher d = request.getRequestDispatcher("/pages/DetalharCliente.jsp");
		d.forward(request, response);

	}

}
