package br.com.livraria.view.command;

import br.com.livraria.core.aplicacao.Resultado;
import br.com.livraria.dominio.EntidadeDominio;

public class ConsultarCommand extends AbstractCommand {

	public Resultado execute(EntidadeDominio entidade) {
		// TODO Auto-generated method stub
		return fachada.listar(entidade);
	}

}
