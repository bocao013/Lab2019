package br.com.livraria.view.web;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.livraria.core.aplicacao.Resultado;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.cliente.Cidade;
import br.com.livraria.dominio.cliente.Estado;
import br.com.livraria.dominio.cliente.Pais;
import br.com.livraria.dominio.cliente.TipoLogradouro;
import br.com.livraria.dominio.cliente.TipoResidencia;
import br.com.livraria.dominio.cliente.TipoTelefone;
import br.com.livraria.dominio.livro.Categoria;
import br.com.livraria.dominio.livro.GrupoLivro;
import br.com.livraria.dominio.livro.SubCategoria;
import br.com.livraria.dominio.venda.StatusPedido;
import br.com.livraria.view.AddPagamentoCartaoViewHelper;
import br.com.livraria.view.AddValorCartaoViewHelper;
import br.com.livraria.view.AlterarEnderecoCarrinhoViewHelper;
import br.com.livraria.view.AlterarQuantidadeCarrinhoViewHelper;
import br.com.livraria.view.AnalisarViewHelper;
import br.com.livraria.view.CMViewHelper;
import br.com.livraria.view.CarregarTelaTrocaViewHelper;
import br.com.livraria.view.CarrinhoViewHelper;
import br.com.livraria.view.ContinuarComprandoViewHelper;
import br.com.livraria.view.FinalizarPedidoViewHelper;
import br.com.livraria.view.IViewHelper;
import br.com.livraria.view.IndexViewHelper;
import br.com.livraria.view.ListarPedidosViewHelper;
import br.com.livraria.view.LoginViewHelper;
import br.com.livraria.view.MudarStatusPedidoViewHelper;
import br.com.livraria.view.PortalAdminViewHelper;
import br.com.livraria.view.RealizarTrocaViewHelper;
import br.com.livraria.view.RemoverCartaoPagamentoViewHelper;
import br.com.livraria.view.SalvarCartaoCreditoFinalizarPedidoViewHelper;
import br.com.livraria.view.SalvarEnderecoCarrinhoViewHelper;
import br.com.livraria.view.SolicitarTrocaViewHelper;
import br.com.livraria.view.ValidarCupomViewHelper;
import br.com.livraria.view.VisualizarCarrinhoViewHelper;
import br.com.livraria.view.VisualizarLivroPedidoViewHelper;
import br.com.livraria.view.VisualizarPedidoClienteViewHelper;
import br.com.livraria.view.cartao.SalvarCartaoCreditoViewHelper;
import br.com.livraria.view.cartao.VisualizarCartaoCreditoViewHelper;
import br.com.livraria.view.cliente.AtualizarClienteViewHelper;
import br.com.livraria.view.cliente.CadastroClienteViewHelper;
import br.com.livraria.view.cliente.ConsultarClienteViewHelper;
import br.com.livraria.view.cliente.DetalharClienteViewHelper;
import br.com.livraria.view.cliente.ListarClientesViewHelper;
import br.com.livraria.view.cliente.LoginClienteViewHelper;
import br.com.livraria.view.cliente.LogoutClienteViewHelper;
import br.com.livraria.view.cliente.VisualizarClienteViewHelper;
import br.com.livraria.view.command.AlterarCommand;
import br.com.livraria.view.command.ConsultarCommand;
import br.com.livraria.view.command.ICommand;
import br.com.livraria.view.command.ProcessarCommand;
import br.com.livraria.view.command.SalvarCommand;
import br.com.livraria.view.endereco.SalvarEnderecoViewHelper;
import br.com.livraria.view.endereco.VisualizarEnderecoViewHelper;
import br.com.livraria.view.livro.CadastroLivroViewHelper;
import br.com.livraria.view.livro.ConsultarLivroLojaViewHelper;
import br.com.livraria.view.livro.ConsultarLivroViewHelper;
import br.com.livraria.view.livro.DetalharLivroViewHelper;
import br.com.livraria.view.livro.ListarLivrosViewHelper;
import br.com.livraria.view.livro.VisualizarLivroViewHelper;

// Recebe todas as requisi��es (CONTROLLER)
public class Servlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	private static Map<String, ICommand> commands;
	private static Map<String, IViewHelper> vhs;

	public Servlet() {
		// chave = String que representa uma opera��o
		// valor = uma inst�ncia de command referente a aquela opera��o
		commands = new HashMap<String, ICommand>();
		commands.put("salvar", new SalvarCommand());
		commands.put("consultar", new ConsultarCommand());
		commands.put("alterar", new AlterarCommand());
		commands.put("processar", new ProcessarCommand());

		// chave = String referente a uri que chega
		// valor = uma inst�ncia do viewhelper que vai realizar a montagem do objeto e
		// redirecionamento de p�gina
		
		vhs = new HashMap<String, IViewHelper>();
		
		// outros	

		vhs.put("/livraria/LojaIndex", new IndexViewHelper());
		vhs.put("/livraria/", new CMViewHelper());
		vhs.put("/livraria/AdicionarCarrinho", new CarrinhoViewHelper());
		vhs.put("/livraria/AlterarCarrinho", new AlterarQuantidadeCarrinhoViewHelper());
		vhs.put("/livraria/VisualizarCarrinho", new VisualizarCarrinhoViewHelper());
		vhs.put("/livraria/CadastrarEnderecoCarrinho", new SalvarEnderecoCarrinhoViewHelper());
		vhs.put("/livraria/ContinuarComprando", new ContinuarComprandoViewHelper());
		vhs.put("/livraria/CadastrarCartaoCreditoFinalizarPedido", new SalvarCartaoCreditoFinalizarPedidoViewHelper());
		vhs.put("/livraria/AddPagamentoCartaoCredito", new AddPagamentoCartaoViewHelper());
		vhs.put("/livraria/AddValorCartaoCredito", new AddValorCartaoViewHelper());
		vhs.put("/livraria/FinalizarPedido", new FinalizarPedidoViewHelper());
		vhs.put("/livraria/AlterarEnderecoCarrinho", new AlterarEnderecoCarrinhoViewHelper());
		vhs.put("/livraria/ValidarCupom", new ValidarCupomViewHelper());
		vhs.put("/livraria/RemoverCartaoCredito", new RemoverCartaoPagamentoViewHelper());
		vhs.put("/livraria/VisualizarLivroPedido", new VisualizarLivroPedidoViewHelper());
		vhs.put("/livraria/ListarPedido", new ListarPedidosViewHelper());
		vhs.put("/livraria/DetalharPedido", new VisualizarPedidoClienteViewHelper());
		vhs.put("/livraria/MudarStatusPedido", new MudarStatusPedidoViewHelper());
		vhs.put("/livraria/CarregarTelaTroca", new CarregarTelaTrocaViewHelper());
		vhs.put("/livraria/SolicitarTroca", new SolicitarTrocaViewHelper());
		vhs.put("/livraria/RealizarTroca", new RealizarTrocaViewHelper());
		vhs.put("/livraria/Analisar", new AnalisarViewHelper());
		
			
		// livro
		vhs.put("/livraria/CadastroLivro", new CadastroLivroViewHelper());
		vhs.put("/livraria/ListarLivro", new ListarLivrosViewHelper());
		vhs.put("/livraria/VisualizarLivro", new VisualizarLivroViewHelper());
		vhs.put("/livraria/AlterarLivro", new CadastroLivroViewHelper());
		vhs.put("/livraria/ConsultarLivro", new ConsultarLivroViewHelper());
		vhs.put("/livraria/ConsultarLivroLoja", new ConsultarLivroLojaViewHelper());
		vhs.put("/livraria/DetalharLivro", new DetalharLivroViewHelper());

		// cliente
		vhs.put("/livraria/CadastroCliente", new CadastroClienteViewHelper());
		vhs.put("/livraria/ListarCliente", new ListarClientesViewHelper());
		vhs.put("/livraria/VisualizarCliente", new VisualizarClienteViewHelper());
		vhs.put("/livraria/ConsultarCliente", new ConsultarClienteViewHelper());
		vhs.put("/livraria/DetalharCliente", new DetalharClienteViewHelper());
		vhs.put("/livraria/AlterarCliente", new AtualizarClienteViewHelper());
		vhs.put("/livraria/LoginCliente", new LoginClienteViewHelper());
		vhs.put("/livraria/LogoutCliente", new LogoutClienteViewHelper());
		
		
		// endereco
		vhs.put("/livraria/VisualizarEndereco", new VisualizarEnderecoViewHelper());
		vhs.put("/livraria/AlterarEndereco", new SalvarEnderecoViewHelper());
		vhs.put("/livraria/CadastrarEndereco", new SalvarEnderecoViewHelper());
		
		// cart�o de cr�dito
		vhs.put("/livraria/VisualizarCartaoCredito", new VisualizarCartaoCreditoViewHelper());
		vhs.put("/livraria/AlterarCartaoCredito", new SalvarCartaoCreditoViewHelper());
		vhs.put("/livraria/CadastrarCartaoCredito", new SalvarCartaoCreditoViewHelper());
		
		//admin
		vhs.put("/livraria/admin", new PortalAdminViewHelper());
		vhs.put("/livraria/Login", new LoginViewHelper());

	}

	@Override
	// links = get
	// passa na propria url os atributos
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
			doProcessRequest(request, response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	// encapsula dentro da requisi��o os atributos
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
			doProcessRequest(request, response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	protected void doProcessRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub

		// Obtem a uri que invocou esta servlet(O que foi definido no action do form
		// html)
		String uri = request.getRequestURI();

		// Obtem a opera��o que ser� executada
		String operacao = request.getParameter("operacao");

		// Obtem um viewhelper indexado pela uri que invocou esta servlet
		IViewHelper vh = vhs.get(uri);

		// O View Helper retorna a entidade especifica para a tela que chamou esta
		// servlet
		EntidadeDominio entidade = null;
		if(vh != null)
			entidade = vh.getEntidade(request);

		// Obtem o command para executar a respectiva opera��o
		ICommand command = commands.get(operacao);

		/*
		 * Executa o commando que chamar� a fachada para executar a opera��o requisitada
		 * o retorno � uma inst�ncia da classe resultado que pode conter mensagens de
		 * erro ou entidades de retorno
		 */
		Resultado resultado = null;
		if (entidade != null) // evita erro quando as opera��es n�o ir�o para a fachada
			resultado = command.execute(entidade);

		/*
		 * Executa o m�todo setView do view helper espec�fico para definir como dever�
		 * ser apresentado o resultado para o usu�rio
		 * 
		 */
		vh.setView(request, response, resultado);

	}

	@Override
	public void init() throws ServletException {
	// TODO Auto-generated method stub
		super.init();
		
		//consultar estados e cidades e botar no contexto da aplica��o (similar � session) salvar o map de Estados e cidades
		 
		ICommand command = new ConsultarCommand();

		Resultado resultado = command.execute(new Categoria());
		List<EntidadeDominio> categorias = resultado.getEntidades();
		getServletContext().setAttribute("categorias", categorias);

		resultado = command.execute(new SubCategoria());
		List<EntidadeDominio> subCategorias = resultado.getEntidades();
		getServletContext().setAttribute("subCategorias", subCategorias);

		resultado = command.execute(new GrupoLivro());
		List<EntidadeDominio> grupoLivros = resultado.getEntidades();
		getServletContext().setAttribute("grupoLivros", grupoLivros);

		resultado = command.execute(new Cidade());
		List<EntidadeDominio> cidades = resultado.getEntidades();
		getServletContext().setAttribute("cidades", cidades);

		resultado = command.execute(new Estado());
		List<EntidadeDominio> estados = resultado.getEntidades();
		getServletContext().setAttribute("estados", estados);

		resultado = command.execute(new Pais());
		List<EntidadeDominio> paises = resultado.getEntidades();
		getServletContext().setAttribute("paises", paises);

		resultado = command.execute(new TipoLogradouro());
		List<EntidadeDominio> tipoLogradouros = resultado.getEntidades();
		getServletContext().setAttribute("tipoLogradouros", tipoLogradouros);
		
		resultado = command.execute(new TipoResidencia());
		List<EntidadeDominio> tipoResidencias = resultado.getEntidades();
		getServletContext().setAttribute("tipoResidencias", tipoResidencias);
		
		resultado = command.execute(new TipoTelefone());
		List<EntidadeDominio> tipoTelefones = resultado.getEntidades();
		getServletContext().setAttribute("tipoTelefones", tipoTelefones);
		
		Map<Integer, Integer> mapaProximoStatus = new HashMap<>();
		mapaProximoStatus.put(StatusPedido.APROVADO, StatusPedido.EM_PROGRESSO);
		mapaProximoStatus.put(StatusPedido.EM_PROGRESSO, StatusPedido.EM_TRANSPORTE);
		mapaProximoStatus.put(StatusPedido.EM_TRANSPORTE, StatusPedido.ENTREGUE);
		mapaProximoStatus.put(StatusPedido.ENTREGUE, StatusPedido.EM_TROCA);
		mapaProximoStatus.put(StatusPedido.EM_TROCA, StatusPedido.TROCADO);
		
		Map<Integer, StatusPedido> mapaStatus = new HashMap<>();
		
		List<EntidadeDominio> resultadoStatusPedidos = command.execute(new StatusPedido()).getEntidades();
		List<StatusPedido> listaStatusPedido = new ArrayList<>();
		
		for(EntidadeDominio ed : resultadoStatusPedidos) {
			StatusPedido statusPedido = (StatusPedido) ed;
			listaStatusPedido.add(statusPedido);
		}
		
		for(StatusPedido statusPedido : listaStatusPedido) {
			for(StatusPedido proximoStatus : listaStatusPedido) {
				if(proximoStatus.getId().equals(mapaProximoStatus.get(statusPedido.getId()))) {
					statusPedido.setProximoStatus(proximoStatus);
					mapaStatus.put(statusPedido.getId(), proximoStatus);
					break;
				}
			}
		}
		
		getServletContext().setAttribute("listaStatusPedido", listaStatusPedido);
		getServletContext().setAttribute("mapaStatus", mapaStatus);
		
		// BLOCO PARA COMBO DINAMICA ESTADO/CIDADE
		/*Map<Integer, List<Cidade>> mapaEstadosCidades = new HashMap<>();
		for (EntidadeDominio estadoEd : estados) {
			Estado estado = (Estado) estadoEd;
			mapaEstadosCidades.put(estado.getId(), estado.getCidades());

		}
		getServletContext().setAttribute("mapaEstadosCidades", mapaEstadosCidades);*/
	}

}
