package br.com.livraria.view;

import java.text.SimpleDateFormat;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.livraria.core.aplicacao.Resultado;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.analise.AnaliseCategoriaMaisVendida;

public class AnalisarViewHelper implements IViewHelper {

	@Override
	public EntidadeDominio getEntidade(HttpServletRequest request) {
		AnaliseCategoriaMaisVendida analise = new AnaliseCategoriaMaisVendida();
		String dtInicio = request.getParameter("txtDtInicio");
		String dtFim = request.getParameter("txtDtFim");
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		
		try {
			if(!dtInicio.isEmpty())
				analise.setDtInicio(sdf.parse(dtInicio));
			
			if(!dtFim.isEmpty())
				analise.setDtFim(sdf.parse(dtFim));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return analise;
	}

	@Override
	public void setView(HttpServletRequest request, HttpServletResponse response, Resultado resultado)
			throws Exception {	
		if(resultado != null && resultado.getMensagem()!= null) {
			request.setAttribute("mensagem", resultado.getMensagem());
		} else {
			request.setAttribute("analise", resultado.getEntidades().get(0));
		}
		
		request.getRequestDispatcher("/pages/Analises.jsp").forward(request, response);
	}

}
