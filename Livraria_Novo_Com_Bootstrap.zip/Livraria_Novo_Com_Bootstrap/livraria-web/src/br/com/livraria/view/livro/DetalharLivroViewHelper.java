package br.com.livraria.view.livro;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.livraria.core.aplicacao.Resultado;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.livro.Livro;
import br.com.livraria.dominio.venda.ItemEstoque;
import br.com.livraria.view.IViewHelper;

public class DetalharLivroViewHelper implements IViewHelper {

	public EntidadeDominio getEntidade(HttpServletRequest request) {
		
		ItemEstoque itemEstoque = new ItemEstoque();
		String idItemEstoque = request.getParameter("id");
		if(idItemEstoque != null)
			itemEstoque.setId(Integer.valueOf(idItemEstoque));
		
		return itemEstoque;
	}

	public void setView(HttpServletRequest request, HttpServletResponse response, Resultado resultado)
			throws Exception {
		request.setAttribute("itemEstoque", resultado.getEntidades().get(0));
		RequestDispatcher d = request.getRequestDispatcher("/pages/DetalharLivro.jsp");
		d.forward(request, response);

	}

}
