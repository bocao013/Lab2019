package br.com.livraria.view.cliente;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.livraria.core.aplicacao.Resultado;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.cliente.Cliente;
import br.com.livraria.view.IViewHelper;

public class ConsultarClienteViewHelper implements IViewHelper {

	@Override
	public EntidadeDominio getEntidade(HttpServletRequest request) {
		Cliente cliente = new Cliente();
		String txtConsulta = request.getParameter("txtConsulta");
		cliente.setCodigo(txtConsulta);

		return cliente;
	}

	@Override
	public void setView(HttpServletRequest request, HttpServletResponse response, Resultado resultado)
			throws Exception {
		
		request.setAttribute("clientes", resultado.getEntidades());
	
		request.getRequestDispatcher("/pages/TelaClientes.jsp").forward(request, response);
	}

}