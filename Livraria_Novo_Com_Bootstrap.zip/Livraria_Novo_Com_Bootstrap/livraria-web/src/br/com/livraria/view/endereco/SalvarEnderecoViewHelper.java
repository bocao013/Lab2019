package br.com.livraria.view.endereco;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.livraria.core.aplicacao.Resultado;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.cliente.Cidade;
import br.com.livraria.dominio.cliente.Cliente;
import br.com.livraria.dominio.cliente.Endereco;
import br.com.livraria.dominio.cliente.Estado;
import br.com.livraria.dominio.cliente.Logradouro;
import br.com.livraria.dominio.cliente.Pais;
import br.com.livraria.dominio.cliente.TipoLogradouro;
import br.com.livraria.dominio.cliente.TipoResidencia;
import br.com.livraria.view.IViewHelper;

public class SalvarEnderecoViewHelper implements IViewHelper {

	public EntidadeDominio getEntidade(HttpServletRequest request) {
		Endereco endereco = new Endereco();
		String idCliente = request.getParameter("txtIdCliente");
		String idLogradouro = request.getParameter("txtIdLogradouro");
		String idTipoLogradouro = request.getParameter("tipoLogradouro");
		String idEndereco = request.getParameter("txtIdEndereco");
		String nomeLogradouro = request.getParameter("txtLogradouro");
		String numero = request.getParameter("txtNumero");
		String bairro = request.getParameter("txtBairro");
		String cep = request.getParameter("txtCep");
		String observacao = request.getParameter("txtObservacao");
		String idPais = request.getParameter("pais");
		String idEstado = request.getParameter("estado");
		String idCidade = request.getParameter("cidade");
		String idTipoResidencia = request.getParameter("tipoResidencia");
		String primario = request.getParameter("checkPrimario");

		if(primario!= null && primario.equals("primario"))
			endereco.setPrimario(true);
		else
			endereco.setPrimario(false);
		
		TipoLogradouro tipoLogradouro = new TipoLogradouro();
		if(idTipoLogradouro != null && !idTipoLogradouro.trim().isEmpty())	
			tipoLogradouro.setId(Integer.parseInt(idTipoLogradouro));
		
		if(idEndereco != null && !idEndereco.trim().isEmpty())	
			endereco.setId(Integer.parseInt(idEndereco));
		
		Cliente cliente = new Cliente();
		if(idCliente != null && !idCliente.trim().isEmpty())
			cliente.setId(Integer.parseInt(idCliente));
		
		  
		endereco.setCliente(cliente);
		 
		endereco.setNumero(numero);
		endereco.setBairro(bairro);
		endereco.setCep(cep);
		endereco.setObservacao(observacao);
		
		Logradouro logradouro = new Logradouro();
		logradouro.setLogradouro(nomeLogradouro);
		logradouro.setTipoLogradouro(tipoLogradouro);
		
		if(idLogradouro != null && !idLogradouro.trim().isEmpty())	
			logradouro.setId(Integer.parseInt(idLogradouro));
		
		endereco.setLogradouro(logradouro);
		
		
		Pais pais = new Pais();
		if(idPais != null && !idPais.trim().isEmpty())	
			pais.setId(Integer.parseInt(idPais));
		
		Estado estado = new Estado();
		if(idEstado != null && !idEstado.trim().isEmpty())	
			estado.setId(Integer.parseInt(idEstado));
		
		Cidade cidade = new Cidade();
		if(idCidade != null && !idCidade.trim().isEmpty())	
			cidade.setId(Integer.parseInt(idCidade));
		
		TipoResidencia tipoResidencia = new TipoResidencia();
		if(idTipoResidencia != null && !idTipoResidencia.trim().isEmpty())	
			tipoResidencia.setId(Integer.parseInt(idTipoResidencia));
		
		endereco.setLogradouro(logradouro);
		endereco.setPais(pais);
		endereco.setCidade(cidade);
		endereco.setTipoResidencia(tipoResidencia);
			
		return endereco;
	}

	public void setView(HttpServletRequest request, HttpServletResponse response, Resultado resultado)
			throws Exception {
		RequestDispatcher d = null;
		String msg = "";
		String operacao = request.getParameter("operacao");
		if(operacao != null){
			if (operacao.equals("salvar"))
				 msg = "cadastrado";
			if(operacao.equals("alterar"))
				msg = "alterado";
		}
		if( resultado != null && resultado.getMensagem() == null){
			Endereco endereco = (Endereco)resultado.getEntidades().get(0);
			request.setAttribute("mensagem", "Endereco "+msg+" com sucesso!");
			
			Cliente cliente = (Cliente) request.getSession().getAttribute("cliente");
			cliente.getEnderecos().add(endereco);
			request.getSession().setAttribute("cliente", cliente);
			
			d = request.getRequestDispatcher("DetalharCliente?operacao=consultar&id="+endereco.getCliente().getId());
		}
		else if (resultado.getMensagem() != null) {
			
			Endereco endereco = (Endereco)resultado.getEntidades().get(0);
			request.setAttribute("mensagem", resultado.getMensagem());
			request.setAttribute("idCliente", endereco.getCliente().getId().toString());
			if(operacao.equals("alterar")) {
				request.setAttribute("endereco", endereco);
				d = request.getRequestDispatcher("/pages/FormEndereco.jsp");
			}
			if(operacao.equalsIgnoreCase("salvar")) {
				
				d = request.getRequestDispatcher("/pages/FormEndereco.jsp");
			}
			
		}
		
		d.forward(request, response);
	}

}
