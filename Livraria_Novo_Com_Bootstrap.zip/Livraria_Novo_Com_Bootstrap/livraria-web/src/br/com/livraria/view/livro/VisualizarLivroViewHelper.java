package br.com.livraria.view.livro;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.livraria.core.aplicacao.Resultado;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.livro.Livro;
import br.com.livraria.view.IViewHelper;

public class VisualizarLivroViewHelper implements IViewHelper {

	public EntidadeDominio getEntidade(HttpServletRequest request) {
		
		Livro livro = new Livro();
		String idLivro = request.getParameter("id");
		if(idLivro != null)
			livro.setId(Integer.valueOf(idLivro));
		return livro;
	}

	public void setView(HttpServletRequest request, HttpServletResponse response, Resultado resultado)
			throws Exception {
		request.setAttribute("livro", resultado.getEntidades().get(0));
		RequestDispatcher d = request.getRequestDispatcher("/pages/FormLivro.jsp");
		d.forward(request, response);

	}

}
