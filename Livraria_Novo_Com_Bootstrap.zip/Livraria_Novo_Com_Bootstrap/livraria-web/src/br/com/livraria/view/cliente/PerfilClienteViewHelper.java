package br.com.livraria.view.cliente;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.livraria.core.aplicacao.Resultado;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.view.IViewHelper;

public class PerfilClienteViewHelper implements IViewHelper {

	@Override
	public EntidadeDominio getEntidade(HttpServletRequest request) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setView(HttpServletRequest request, HttpServletResponse response, Resultado resultado)
			throws Exception {
		RequestDispatcher d = null;
		request.setAttribute("mensagem", resultado.getMensagem());
		d = request.getRequestDispatcher("/pages/LoginCliente.jsp");
	
		d.forward(request, response);
	}
}
