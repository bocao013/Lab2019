package br.com.livraria.view;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.livraria.core.aplicacao.Resultado;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.cliente.CartaoCredito;
import br.com.livraria.dominio.cliente.Cliente;
import br.com.livraria.dominio.venda.PagamentoCartaoCredito;
import br.com.livraria.dominio.venda.Pedido;

public class AddPagamentoCartaoViewHelper implements IViewHelper {

	@Override
	public EntidadeDominio getEntidade(HttpServletRequest request) {
		PagamentoCartaoCredito pagamentoCartaoCredito = new PagamentoCartaoCredito();
		Cliente clienteLogado = (Cliente) request.getSession().getAttribute("cliente");
		String idCartaoCredito = request.getParameter("idCartaoCredito");
		
		String valorPedido = request.getParameter("valorPedido");
		String valorFrete = request.getParameter("valorFrete");
		
		for(CartaoCredito cartao: clienteLogado.getCartoesCredito()) {
			if(cartao.getId() == Integer.parseInt(idCartaoCredito)) {
				pagamentoCartaoCredito.setCartaoCredito(cartao);
				pagamentoCartaoCredito.setValor(0.0);
				request.getSession().setAttribute("pagamentoCartaoCredito", pagamentoCartaoCredito);
			}
		}
		
		request.setAttribute("valorPedido", Double.valueOf(valorPedido));
		request.setAttribute("valorFrete", Double.valueOf(valorFrete));
		
		return null;
	}

	@Override
	public void setView(HttpServletRequest request, HttpServletResponse response, Resultado resultado)
			throws Exception {
		request.getRequestDispatcher("/pages/FormAddPagamentoCartao.jsp").forward(request, response);

	}

}
