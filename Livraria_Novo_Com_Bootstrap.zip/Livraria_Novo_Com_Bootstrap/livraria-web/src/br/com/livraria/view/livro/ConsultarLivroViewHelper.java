package br.com.livraria.view.livro;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.livraria.core.aplicacao.Resultado;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.livro.Livro;
import br.com.livraria.view.IViewHelper;

public class ConsultarLivroViewHelper implements IViewHelper {

	@Override
	public EntidadeDominio getEntidade(HttpServletRequest request) {
		Livro livro = new Livro();
		String txtConsulta = request.getParameter("txtConsulta");
		livro.setCodigo(txtConsulta);

		return livro;
	}

	@Override
	public void setView(HttpServletRequest request, HttpServletResponse response, Resultado resultado)
			throws Exception {
		
		request.setAttribute("livros", resultado.getEntidades());
	
		request.getRequestDispatcher("/pages/TelaLivros.jsp").forward(request, response);
	}

}