package br.com.livraria.view;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.livraria.core.aplicacao.Resultado;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.venda.MudarStatusPedido;
import br.com.livraria.dominio.venda.Pedido;

public class MudarStatusPedidoViewHelper implements IViewHelper{

	@Override
	public EntidadeDominio getEntidade(HttpServletRequest request) {
		MudarStatusPedido mudarStatusPedido = new MudarStatusPedido();
		Pedido pedido = new Pedido();
		pedido.setId(Integer.parseInt(request.getParameter("idPedido")));
		mudarStatusPedido.setId(Integer.parseInt(request.getParameter("idStatusPedido")));
		mudarStatusPedido.setPedido(pedido);
		return mudarStatusPedido;
	}

	@Override
	public void setView(HttpServletRequest request, HttpServletResponse response, Resultado resultado)
			throws Exception {
		request.getRequestDispatcher("ListarPedido?operacao=consultar").forward(request, response);
		
	}

}
