package br.com.livraria.view;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.livraria.core.aplicacao.Resultado;
import br.com.livraria.dominio.EntidadeDominio;

public class CMViewHelper implements IViewHelper {

	// S� para navega��o entre as p�ginas, onde a opera��o � a p�gina
	public EntidadeDominio getEntidade(HttpServletRequest request) {
		// TODO Auto-generated method stub
		return null;
	}

	public void setView(HttpServletRequest request, HttpServletResponse response, Resultado resultado) throws Exception {
		// TODO Auto-generated method stub
		String operacao = request.getParameter("operacao");
		RequestDispatcher d = null;
		if(operacao == null)
			d = request.getRequestDispatcher("/LojaIndex?operacao=consultar");
		else {
			d = request.getRequestDispatcher("/pages/"+operacao+".jsp");	
		}	
		
		d.forward(request, response);
	}

}
