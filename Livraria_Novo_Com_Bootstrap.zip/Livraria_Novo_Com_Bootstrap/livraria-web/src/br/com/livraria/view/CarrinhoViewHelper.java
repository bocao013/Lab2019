package br.com.livraria.view;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.livraria.core.aplicacao.Resultado;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.cliente.Cliente;
import br.com.livraria.dominio.livro.Livro;
import br.com.livraria.dominio.venda.ItemPedido;
import br.com.livraria.dominio.venda.NovoItemPedido;
import br.com.livraria.dominio.venda.Pedido;

public class CarrinhoViewHelper implements IViewHelper {

	@Override
	public EntidadeDominio getEntidade(HttpServletRequest request) {
	
		String id = request.getParameter("id");
		String quantidade = request.getParameter("qtde");
		
		Pedido carrinho = (Pedido)request.getSession().getAttribute("carrinho");
		if(carrinho == null) {
			List<ItemPedido> itensPedido = new ArrayList<>();
			carrinho = new Pedido();
			carrinho.setItems(itensPedido);
			Cliente clienteLogado = (Cliente)request.getSession().getAttribute("cliente");
			carrinho.setCliente(clienteLogado);
			carrinho.setEndereco(clienteLogado.getEnderecoPrincipal());
		}
		
		Livro livro = new Livro();
		livro.setId(Integer.parseInt(id));
		ItemPedido itemPedido = new ItemPedido();
		itemPedido.setLivro(livro);	
		itemPedido.setQuantidade(Integer.parseInt(quantidade));
		
		NovoItemPedido novoItemPedido = new NovoItemPedido();
		novoItemPedido.setCarrinho(carrinho);
		novoItemPedido.setNovoItem(itemPedido);
		
		return novoItemPedido;
		
	}

	@Override
	public void setView(HttpServletRequest request, HttpServletResponse response, Resultado resultado)
			throws Exception {
		if(resultado != null && resultado.getMensagem() != null) {
			request.setAttribute("mensagem", resultado.getMensagem());
		} else {
			request.setAttribute("mensagem", "Produto adicionado ao carrinho!");
			NovoItemPedido novoItemPedido = (NovoItemPedido) resultado.getEntidades().get(0);
			request.getSession().setAttribute("carrinho", novoItemPedido.getCarrinho());
		}
		
		request.getRequestDispatcher("/LojaIndex?operacao=consultar").forward(request, response);

	}

}
