package br.com.livraria.view.endereco;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.livraria.core.aplicacao.Resultado;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.cliente.Cliente;
import br.com.livraria.dominio.cliente.Endereco;
import br.com.livraria.view.IViewHelper;

public class VisualizarEnderecoViewHelper implements IViewHelper {

	public EntidadeDominio getEntidade(HttpServletRequest request) {
		Endereco endereco = new Endereco();
		Cliente cliente = new Cliente();
		
		String idCliente = request.getParameter("idCliente");
		if(idCliente != null)
			cliente.setId(Integer.valueOf(idCliente));
		
		String idEndereco = request.getParameter("idEndereco");
		if(idEndereco != null)
			endereco.setId(Integer.valueOf(idEndereco));
		
		endereco.setCliente(cliente);
		return endereco;
	}

	public void setView(HttpServletRequest request, HttpServletResponse response, Resultado resultado)
			throws Exception {
		request.setAttribute("endereco", resultado.getEntidades().get(0));
		RequestDispatcher d = request.getRequestDispatcher("/pages/FormEndereco.jsp");
		d.forward(request, response);

	}

}
