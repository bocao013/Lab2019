package br.com.livraria.view;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.livraria.core.aplicacao.Resultado;
import br.com.livraria.core.util.PedidoUtils;
import br.com.livraria.dominio.EntidadeDominio;
import br.com.livraria.dominio.cliente.Cliente;
import br.com.livraria.dominio.venda.Pedido;

public class FinalizarPedidoViewHelper implements IViewHelper {

	@Override
	public EntidadeDominio getEntidade(HttpServletRequest request) {
		
		Pedido pedido = (Pedido) request.getSession().getAttribute("carrinho");
		pedido.getPagamento().setValorTotal(PedidoUtils.getValorTotal(pedido));
		return pedido;
	}

	@Override
	public void setView(HttpServletRequest request, HttpServletResponse response, Resultado resultado)
			throws Exception {
		RequestDispatcher d = null;
		if(resultado != null && resultado.getMensagem() != null) {
			request.setAttribute("mensagem", resultado.getMensagem());
			d = request.getRequestDispatcher("/pages/ContinuarComprando.jsp");
		} else {
			request.setAttribute("mensagme", "Pedido realizado com sucesso!");
			Pedido pedido = (Pedido) resultado.getEntidades().get(0);
			request.setAttribute("pedido", pedido);
			request.getSession().setAttribute("carrinho", null); // tirar o carrinho da sess�o pois o pedido foi finalizado
			
			// ATUALIZA O CLIENTE NA SESS�O
			Cliente cliente = (Cliente) request.getSession().getAttribute("cliente");
			cliente.getPedidos().add(pedido);
			request.getSession().setAttribute("cliente", cliente);
			
			d = request.getRequestDispatcher("/pages/PedidoFinalizado.jsp");
		}
		d.forward(request, response);
		

	}

}
