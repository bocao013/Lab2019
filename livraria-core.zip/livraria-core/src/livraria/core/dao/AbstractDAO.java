package livraria.core.dao;

import livraria.core.IDAO;
import livraria.core.aplicacao.Resultado;

public abstract class AbstractDAO implements IDAO{
    protected Resultado resultado = new Resultado();
    
}
