package livraria.core.util;

public class ExcecaoLimiteTentativas extends Exception {
    
}
